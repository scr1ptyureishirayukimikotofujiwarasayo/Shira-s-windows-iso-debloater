@echo off
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0WindowsUltraDebloater.ps1"
pause
