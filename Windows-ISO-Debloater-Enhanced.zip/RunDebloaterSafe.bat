@echo off
:: Windows ISO Debloater - Safe Mode Launcher
:: Runs with BakuretsuClean-style non-aggressive settings

echo ========================================
echo  Windows ISO Debloater - SAFE MODE
echo  AppX bloat removal only. Safe for any edition.
echo ========================================
echo.

set "SCRIPT=%~dp0isoDebloaterScript.ps1"

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -SafeMode

pause
