#Requires -Version 5.1
#This function finds any AppX/AppXProvisioned package and uninstalls it, except for Freshpaint, Windows Calculator, Windows Store, and Windows Photos.
#Also, to note - This does NOT remove essential system services/software/etc such as .NET framework installations, Cortana, Edge, etc.

param([switch]$Silent)

#This will self elevate the script so with a UAC prompt since this script needs to be run as an Administrator in order to function properly.
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')) {
    if (-not $Silent) {
        Write-Host "You didn't run this script as an Administrator. This script will self elevate to run as an Administrator and continue."
        Start-Sleep 1
        Write-Host "                                               3"
        Start-Sleep 1
        Write-Host "                                               2"
        Start-Sleep 1
        Write-Host "                                               1"
        Start-Sleep 1
    }

    $scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
    $elevateArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $scriptPath)
    if ($Silent) { $elevateArgs += '-Silent' }
    Start-Process powershell.exe -ArgumentList $elevateArgs -Verb RunAs
    Exit
}

#no errors throughout
$ErrorActionPreference = 'SilentlyContinue'

$DebloatFolder = "C:\Temp\Windows10Debloater"
If (Test-Path $DebloatFolder) {
    Write-Output "$DebloatFolder exists. Skipping."
}
Else {
    Write-Output "The folder '$DebloatFolder' doesn't exist. This folder will be used for storing logs created after the script runs. Creating now."
    Start-Sleep 1
    New-Item -Path "$DebloatFolder" -ItemType Directory
    Write-Output "The folder $DebloatFolder was successfully created."
}

## Initialize local script log in script directory, with fallback to TEMP if unwritable
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$LogPath = Join-Path $ScriptDir "WindowsUltraDebloater.log"
if (-not (Test-Path $LogPath)) {
    $logDir = $env:TEMP
    if (-not (Test-Path $logDir)) { New-Item -Path $logDir -ItemType Directory | Out-Null }
    $LogPath = Join-Path $logDir "WindowsUltraDebloater.log"
}
try {
    Start-Transcript -Path $LogPath -Append
    Write-Output "WindowsUltraDebloater started. Log: $LogPath"
} catch {
    # Fallback: If transcript cannot start (permissions, in-use, etc.) write to a temp log instead
    $fallbackLog = Join-Path $env:TEMP "WindowsUltraDebloater_fallback.log"
    Add-Content -Path $fallbackLog -Value "Failed to start transcript: $($_.Exception.Message)"
    Write-Output "Transcript failed to start. See fallback log: $fallbackLog"
}


Function DebloatAll {
    #Removes AppxPackages
    #Credit to /u/GavinEke for a modified version of my whitelist code
    $WhitelistedApps = 'Microsoft.ScreenSketch|Microsoft.Paint3D|Microsoft.WindowsCalculator|Microsoft.WindowsStore|Microsoft.Windows.Photos|CanonicalGroupLimited.UbuntuonWindows|Microsoft.XboxGameCallableUI|Microsoft.XboxGamingOverlay|Microsoft.Xbox.TCUI|Microsoft.XboxIdentityProvider|Microsoft.MicrosoftStickyNotes|Microsoft.MSPaint|Microsoft.WindowsCamera|\.NET|Framework|Microsoft.HEIFImageExtension|Microsoft.StorePurchaseApp|Microsoft.VP9VideoExtensions|Microsoft.WebMediaExtensions|Microsoft.WebpImageExtension|Microsoft.DesktopAppInstaller|WindSynthBerry|MIDIBerry|Slack'
    #NonRemovable Apps that where getting attempted and the system would reject the uninstall, speeds up debloat and prevents 'initalizing' overlay when removing apps
    $NonRemovable = '1527c705-839a-4832-9118-54d4Bd6a0c89|c5e2524a-ea46-4f67-841f-6a9465d9d515|E2A4F912-2574-4A75-9BB0-0D023378592B|F46D4000-FD22-4DB4-AC8E-4E1DDDE828FE|InputApp|Microsoft.AAD.BrokerPlugin|Microsoft.AccountsControl|Microsoft.BioEnrollment|Microsoft.CredDialogHost|Microsoft.ECApp|Microsoft.LockApp|Microsoft.MicrosoftEdgeDevToolsClient|Microsoft.MicrosoftEdge|Microsoft.PPIProjection|Microsoft.Win32WebViewHost|Microsoft.Windows.Apprep.ChxApp|Microsoft.Windows.AssignedAccessLockApp|Microsoft.Windows.CapturePicker|Microsoft.Windows.CloudExperienceHost|Microsoft.Windows.ContentDeliveryManager|Microsoft.Windows.Cortana|Microsoft.Windows.NarratorQuickStart|Microsoft.Windows.ParentalControls|Microsoft.Windows.PeopleExperienceHost|Microsoft.Windows.PinningConfirmationDialog|Microsoft.Windows.SecHealthUI|Microsoft.Windows.SecureAssessmentBrowser|Microsoft.Windows.ShellExperienceHost|Microsoft.Windows.XGpuEjectDialog|Microsoft.XboxGameCallableUI|Windows.CBSPreview|windows.immersivecontrolpanel|Windows.PrintDialog|Microsoft.VCLibs.140.00|Microsoft.Services.Store.Engagement|Microsoft.UI.Xaml.2.0|Nvidia'
    Get-AppxPackage -AllUsers | Where-Object {$_.Name -NotMatch $WhitelistedApps -and $_.Name -NotMatch $NonRemovable} | Remove-AppxPackage -AllUsers
    Get-AppxPackage | Where-Object {$_.Name -NotMatch $WhitelistedApps -and $_.Name -NotMatch $NonRemovable} | Remove-AppxPackage
    Get-AppxProvisionedPackage -Online | Where-Object {$_.PackageName -NotMatch $WhitelistedApps -and $_.PackageName -NotMatch $NonRemovable} | Remove-AppxProvisionedPackage -Online
}

Function DebloatBlacklist {

    $Bloatware = @(

        #Unnecessary Windows 10 AppX Apps
        "Microsoft.BingNews"
        "Microsoft.GetHelp"
        "Microsoft.Getstarted"
        "Microsoft.Messaging"
        "Microsoft.Microsoft3DViewer"
        "Microsoft.MicrosoftOfficeHub"
        "Microsoft.MicrosoftSolitaireCollection"
        "Microsoft.NetworkSpeedTest"
        "Microsoft.News"
        "Microsoft.Office.Lens"
        "Microsoft.Office.OneNote"
        "Microsoft.Office.Sway"
        "Microsoft.OneConnect"
        "Microsoft.People"
        "Microsoft.Print3D"
        "Microsoft.RemoteDesktop"
        "Microsoft.SkypeApp"
        "Microsoft.Office.Todo.List"
        "Microsoft.Whiteboard"
        "Microsoft.WindowsAlarms"
        #"Microsoft.WindowsCamera"
        "microsoft.windowscommunicationsapps"
        "Microsoft.WindowsFeedbackHub"
        "Microsoft.WindowsMaps"
        "Microsoft.WindowsSoundRecorder"
        "Microsoft.XboxApp"
        "Microsoft.XboxGameOverlay"
        "Microsoft.XboxSpeechToTextOverlay"
        "Microsoft.ZuneMusic"
        "Microsoft.ZuneVideo"

        #Sponsored Windows 10 AppX Apps
        #Add sponsored/featured apps to remove in the "*AppName*" format
        "*EclipseManager*"
        "*ActiproSoftwareLLC*"
        "*AdobeSystemsIncorporated.AdobePhotoshopExpress*"
        "*Duolingo-LearnLanguagesforFree*"
        "*PandoraMediaInc*"
        "*CandyCrush*"
        "*BubbleWitch3Saga*"
        "*Wunderlist*"
        "*Flipboard*"
        "*Twitter*"
        "*Facebook*"
        "*Spotify*"
        "*Minecraft*"
        "*Royal Revolt*"
        "*Sway*"
        "*Speed Test*"
        "*Dolby*"
        "Microsoft.Todos"
        "Microsoft.PowerAutomateDesktop"
        "Microsoft.Teams"
        "MicrosoftTeams"
        "Microsoft.YourPhone"
        "Microsoft.WindowsFeedback"
        "Microsoft.MixedReality.Portal"
        "Microsoft.3DBuilder"
        "Microsoft.BingWeather"
        "Microsoft.BingFinance"
        "Microsoft.BingSports"
        "Microsoft.BingTravel"
        "Microsoft.BingFoodAndDrink"
        "Microsoft.BingHealthAndFitness"
        "Microsoft.Wallet"
        "Microsoft.549981C3F5F10"
        "*ClipChamp*"
        "*Microsoft.Windows.NarratorQuickStart*"
             
        #Optional: Typically not removed but you can if you need to for some reason
        #"*Microsoft.Advertising.Xaml_10.1712.5.0_x64__8wekyb3d8bbwe*"
        #"*Microsoft.Advertising.Xaml_10.1712.5.0_x86__8wekyb3d8bbwe*"
        #"*Microsoft.BingWeather*"
        #"*Microsoft.MSPaint*"
        #"*Microsoft.MicrosoftStickyNotes*"
        #"*Microsoft.Windows.Photos*"
        #"*Microsoft.WindowsCalculator*"
        #"*Microsoft.WindowsStore*"
    )
    foreach ($Bloat in $Bloatware) {
        Get-AppxPackage -AllUsers -Name $Bloat | Remove-AppxPackage -AllUsers
        Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like $Bloat | Remove-AppxProvisionedPackage -Online
        Write-Output "Trying to remove $Bloat."
        }
}

Function Remove-DISMFeatures {
    $OptionalFeatures = @(
        'WindowsMediaPlayer'
        'Internet-Explorer-Optional-amd64'
        'WorkFolders-Client'
        'Printing-PrintToPDFServices-Features'
        'Printing-XPSServices-Features'
        'FaxServicesClientPackage'
        'MicrosoftWindowsPowerShellV2Root'
        'MicrosoftWindowsPowerShellV2'
        'SMB1Protocol'
    )
    foreach ($FeatureName in $OptionalFeatures) {
        Write-Output "Disabling optional Windows feature: $FeatureName"
        Disable-WindowsOptionalFeature -Online -FeatureName $FeatureName -NoRestart -ErrorAction SilentlyContinue
    }
}

Function Disable-UnnecessaryServices {
    $serviceNames = @(
        'DiagTrack'
        'dmwappushservice'
        'WSearch'
        'SysMain'
        'TabletInputService'
        'Fax'
        'RetailDemo'
        'MapsBroker'
        'lfsvc'
        'SharedAccess'
        'RemoteRegistry'
        'XblAuthManager'
        'XblGameSave'
        'XboxNetApiSvc'
        'XboxGipSvc'
        'wisvc'
        'WerSvc'
        'wercplsupport'
        'PcaSvc'
        'TrkWks'
        'AJRouter'
        'ALG'
        'AppReadiness'
        'AppVClient'
        'AssignedAccessManagerSvc'
        'autotimesvc'
        'AxInstSV'
        'BDESVC'
        'Browser'
        'bthserv'
        'CDPSvc'
        'CDPUserSvc'
        'CertPropSvc'
        'ClipSVC'
        'cloudidsvc'
        'CscService'
        'defragsvc'
        'DeviceAssociationService'
        'DevQueryBroker'
        'diagnosticshub.standardcollector.service'
        'DoSvc'
        'DPS'
        'EapHost'
        'EntAppSvc'
        'fdPHost'
        'FDResPub'
        'fhsvc'
        'FrameServerMonitor'
        'icssvc'
        'IKEEXT'
        'InstallService'
        # iphlpsvc provides IPv6 / Teredo / ISATAP; do not disable to preserve network functionality
        'lltdsvc'
        'LmHosts'
        'MSiSCSI'
        'NaturalAuthentication'
        'NetTcpPortSharing'
        'NfsClnt'
        'OneSyncSvc'
        'PhoneSvc'
        'PNRPAutoReg'
        'PNRPsvc'
        'PrintNotify'
        'RasAuto'
        'RasMan'
        'RemoteAccess'
        'RPSS'
        'SCardSvr'
        'SCPolicySvc'
        'SDRSVC'
        'SEMgrSvc'
        'SensorDataService'
        'SensorService'
        'SensrSvc'
        'SessionEnv'
        'shpamsvc'
        'SmsRouter'
        'SNMPTRAP'
        'spectrum'
        'SSDPSRV'
        'SstpSvc'
        'stisvc'
        # 'StorSvc'  # Breaks Settings > Storage and Store install pipeline
        'svsvc'
        'swprv'
        'TapiSrv'
        'TermService'
        'UevAgentService'
        'upnphost'
        'VacSvc'
        'vmicguestinterface'
        'vmicheartbeat'
        'vmickvpexchange'
        'vmicrdv'
        'vmicshutdown'
        'vmictimesync'
        'vmicvmsession'
        'vmicvss'
        'VSS'
        'W32Time'
        'wbengine'
        'WbioSrvc'
        'wcncsvc'
        'WcsPlugInService'
        'WdNisSvc'
        'WdiServiceHost'
        'WdiSystemHost'
        'WebClient'
        'WinHttpAutoProxySvc'
        'WinRM'
        'WMPNetworkSvc'
        'WpnService'
        'WpnUserService'
        'wudfsvc'
    )
    if ((Get-CimInstance -ClassName Win32_Printer -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0) {
        $serviceNames += 'Spooler'
    }
    $serviceNames | ForEach-Object {
        Write-Output "Disabling service: $_"
        if (Get-Service -Name $_ -ErrorAction SilentlyContinue) {
            Set-Service -Name $_ -StartupType Disabled -ErrorAction SilentlyContinue
            Stop-Service -Name $_ -Force -ErrorAction SilentlyContinue
        }
        $svcReg = "HKLM:\SYSTEM\CurrentControlSet\Services\$_"
        if (Test-Path -LiteralPath $svcReg) {
            Set-ItemProperty -LiteralPath $svcReg -Name Start -Value 4 -Type DWord -ErrorAction SilentlyContinue
        }
    }
}

Function Remove-ScheduledTasks {
    @(
        '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser'
        '\Microsoft\Windows\Application Experience\ProgramDataUpdater'
        '\Microsoft\Windows\Autochk\Proxy'
        '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator'
        '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip'
        '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector'
        '\Microsoft\Windows\Feedback\Siuf\DmClient'
        '\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload'
        '\Microsoft\Windows\Windows Error Reporting\QueueReporting'
        '\Microsoft\Windows\Tips\Tips'
        '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask'
        '\Microsoft\XblGameSave\XblGameSaveTask'
    ) | ForEach-Object {
        $taskFull = $_
        $taskName = Split-Path $taskFull -Leaf
        $taskParent = Split-Path $taskFull -Parent
        $taskPath = if ($taskParent -eq '\') { '\' } else { "$taskParent\" }
        Write-Output "Disabling scheduled task: $taskName"
        Disable-ScheduledTask -TaskName $taskName -TaskPath $taskPath -ErrorAction SilentlyContinue
    }
}

Function Set-PerformanceTweaks {
    $memMgmt = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
    if (-not (Test-Path $memMgmt)) { New-Item -Path $memMgmt -Force | Out-Null }
    Set-ItemProperty -Path $memMgmt -Name ClearPageFileAtShutdown -Value 0 -Type DWord

    $prio = 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl'
    if (-not (Test-Path $prio)) { New-Item -Path $prio -Force | Out-Null }
    Set-ItemProperty -Path $prio -Name Win32PrioritySeparation -Value 38 -Type DWord

    $visualFx = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'
    New-Item -Path $visualFx -Force | Out-Null
    Set-ItemProperty -Path $visualFx -Name VisualFXSetting -Value 2 -Type DWord

    $desktop = 'HKCU:\Control Panel\Desktop'
    New-Item -Path $desktop -Force | Out-Null
    Set-ItemProperty -Path $desktop -Name MenuShowDelay -Value '0' -Type String
    Set-ItemProperty -Path $desktop -Name AutoEndTasks -Value '1' -Type String
    Set-ItemProperty -Path $desktop -Name HungAppTimeout -Value '1000' -Type String
    Set-ItemProperty -Path $desktop -Name WaitToKillAppTimeout -Value '2000' -Type String

    $control = 'HKLM:\SYSTEM\CurrentControlSet\Control'
    if (-not (Test-Path $control)) { New-Item -Path $control -Force | Out-Null }
    Set-ItemProperty -Path $control -Name WaitToKillServiceTimeout -Value '2000' -Type String

    $adv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    New-Item -Path $adv -Force | Out-Null
    Set-ItemProperty -Path $adv -Name TaskbarAnimations -Value 0 -Type DWord
}

Function Set-ExtendedPrivacy {
    $dataCollection = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'
    New-Item -Path $dataCollection -Force | Out-Null
    Set-ItemProperty -Path $dataCollection -Name AllowTelemetry -Value 0 -Type DWord

    $cloudContent = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'
    New-Item -Path $cloudContent -Force | Out-Null
    Set-ItemProperty -Path $cloudContent -Name DisableWindowsConsumerFeatures -Value 1 -Type DWord

    $adInfo = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo'
    New-Item -Path $adInfo -Force | Out-Null
    Set-ItemProperty -Path $adInfo -Name DisabledByGroupPolicy -Value 1 -Type DWord

    $cdm = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
    New-Item -Path $cdm -Force | Out-Null
    Set-ItemProperty -Path $cdm -Name ContentDeliveryAllowed -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name OemPreInstalledAppsEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name PreInstalledAppsEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name SilentInstalledAppsEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name SystemPaneSuggestionsEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name 'SubscribedContent-338387Enabled' -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name 'SubscribedContent-338388Enabled' -Value 0 -Type DWord
    Set-ItemProperty -Path $cdm -Name 'SubscribedContent-338389Enabled' -Value 0 -Type DWord

    $siuf = 'HKCU:\SOFTWARE\Microsoft\Siuf\Rules'
    New-Item -Path $siuf -Force | Out-Null
    Set-ItemProperty -Path $siuf -Name NumberOfSIUFInPeriod -Value 0 -Type DWord

    $sysPol = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'
    New-Item -Path $sysPol -Force | Out-Null
    Set-ItemProperty -Path $sysPol -Name EnableActivityFeed -Value 0 -Type DWord
    Set-ItemProperty -Path $sysPol -Name PublishUserActivities -Value 0 -Type DWord
}

Function Clear-JunkFiles {
    $measureTracked = {
        $total = [long]0
        foreach ($dir in @($env:TEMP, 'C:\Windows\Temp')) {
            if (Test-Path -LiteralPath $dir) {
                $m = Get-ChildItem -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum
                if ($null -ne $m.Sum) { $total += $m.Sum }
            }
        }
        $total
    }
    $bytesBefore = & $measureTracked

    foreach ($root in @(
            $env:TEMP
            'C:\Windows\Temp'
            'C:\Windows\Prefetch'
            'C:\Windows\SoftwareDistribution\Download'
        )) {
        if (Test-Path -LiteralPath $root) {
            Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    # Pre-configure Clean Manager categories silently via registry (no UI) before applying routines (sagerun)
    $sagePath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches'
    @('Temporary Files','Temporary Internet Files','Recycle Bin','Downloaded Program Files','Old ChkDsk Files','Thumbnails','Windows Error Reporting Files') | ForEach-Object {
        $p = Join-Path $sagePath $_
        if (Test-Path $p) { Set-ItemProperty -Path $p -Name StateFlags0001 -Value 2 -Type DWord -ErrorAction SilentlyContinue }
    }
    Start-Process -FilePath cleanmgr.exe -ArgumentList '/sagerun:1' -Wait -WindowStyle Hidden

    $bytesAfter = & $measureTracked
    $freedMB = [math]::Round(($bytesBefore - $bytesAfter) / 1MB, 2)
    Write-Output "Total MB freed (user Temp + C:\Windows\Temp): $freedMB"
}

Function Set-NetworkAndPower {
    try {
        Write-Output "Set-NetworkAndPower: netsh interface tcp set global autotuninglevel=normal"
        $p = Start-Process -FilePath netsh.exe -ArgumentList 'interface', 'tcp', 'set', 'global', 'autotuninglevel=normal' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: netsh autotuninglevel finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: netsh autotuninglevel failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: netsh interface tcp set global chimney=disabled"
        $p = Start-Process -FilePath netsh.exe -ArgumentList 'interface', 'tcp', 'set', 'global', 'chimney=disabled' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: netsh chimney finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: netsh chimney failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: netsh interface tcp set global dca=enabled"
        $p = Start-Process -FilePath netsh.exe -ArgumentList 'interface', 'tcp', 'set', 'global', 'dca=enabled' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: netsh dca finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: netsh dca failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: netsh interface tcp set global netdma=enabled"
        $p = Start-Process -FilePath netsh.exe -ArgumentList 'interface', 'tcp', 'set', 'global', 'netdma=enabled' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: netsh netdma finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: netsh netdma failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: netsh interface tcp set heuristics disabled"
        $p = Start-Process -FilePath netsh.exe -ArgumentList 'interface', 'tcp', 'set', 'heuristics', 'disabled' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: netsh heuristics finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: netsh heuristics failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
        $p = Start-Process -FilePath powercfg.exe -ArgumentList '-setactive', '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: powercfg setactive finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: powercfg setactive failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: powercfg -h off"
        $p = Start-Process -FilePath powercfg.exe -ArgumentList '-h', 'off' -Wait -PassThru -WindowStyle Hidden
        Write-Output "Set-NetworkAndPower: powercfg hibernate off finished (exit $($p.ExitCode))"
    } catch {
        Write-Output "Set-NetworkAndPower: powercfg -h off failed: $($_.Exception.Message)"
    }
    try {
        Write-Output "Set-NetworkAndPower: registry HKLM\...\Tcpip\Parameters TcpAckFrequency=1, TCPNoDelay=1"
        $tcpParams = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
        New-Item -Path $tcpParams -Force | Out-Null
        Set-ItemProperty -Path $tcpParams -Name TcpAckFrequency -Value 1 -Type DWord
        Set-ItemProperty -Path $tcpParams -Name TCPNoDelay -Value 1 -Type DWord
        Write-Output "Set-NetworkAndPower: Tcpip Parameters registry values set"
    } catch {
        Write-Output "Set-NetworkAndPower: registry Tcpip Parameters failed: $($_.Exception.Message)"
    }
}

Function Set-TimerResolution {
    Write-Output "Set-TimerResolution: bcdedit /set useplatformtick yes"
    Start-Process -FilePath bcdedit.exe -ArgumentList '/set', 'useplatformtick', 'yes' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue

    Write-Output "Set-TimerResolution: bcdedit /set disabledynamictick yes"
    Start-Process -FilePath bcdedit.exe -ArgumentList '/set', 'disabledynamictick', 'yes' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue

    Write-Output "Set-TimerResolution: bcdedit /deletevalue useplatformclock (disable HPET platform clock)"
    Start-Process -FilePath bcdedit.exe -ArgumentList '/deletevalue', 'useplatformclock' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue

    Write-Output "Set-TimerResolution: registry Session Manager\kernel GlobalTimerResolutionRequests=1"
    $kernelKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel'
    New-Item -Path $kernelKey -Force | Out-Null
    Set-ItemProperty -Path $kernelKey -Name GlobalTimerResolutionRequests -Value 1 -Type DWord

    # On client Windows 10, valid values are Default or Legacy. Use 'Default' to avoid errors.
    Write-Output "Set-TimerResolution: bcdedit /set tscsyncpolicy default"
    Start-Process -FilePath bcdedit.exe -ArgumentList '/set', 'tscsyncpolicy', 'default' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
}

Function Set-VisualStrip {
    $adv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    New-Item -Path $adv -Force | Out-Null
    Set-ItemProperty -Path $adv -Name ListviewAlphaSelect -Value 0 -Type DWord
    Set-ItemProperty -Path $adv -Name ListviewShadow -Value 0 -Type DWord
    Set-ItemProperty -Path $adv -Name TaskbarAnimations -Value 0 -Type DWord

    $dwm = 'HKCU:\Software\Microsoft\Windows\DWM'
    New-Item -Path $dwm -Force | Out-Null
    Set-ItemProperty -Path $dwm -Name EnableAeroPeek -Value 0 -Type DWord
    Set-ItemProperty -Path $dwm -Name AlwaysHibernateThumbnails -Value 0 -Type DWord

    $metrics = 'HKCU:\Control Panel\Desktop\WindowMetrics'
    New-Item -Path $metrics -Force | Out-Null
    Set-ItemProperty -Path $metrics -Name MinAnimate -Value '0' -Type String

    $desktop = 'HKCU:\Control Panel\Desktop'
    New-Item -Path $desktop -Force | Out-Null
    Set-ItemProperty -Path $desktop -Name DragFullWindows -Value '0' -Type String
    Set-ItemProperty -Path $desktop -Name FontSmoothing -Value '2' -Type String

    $visualFx = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'
    New-Item -Path $visualFx -Force | Out-Null
    Set-ItemProperty -Path $visualFx -Name VisualFXSetting -Value 2 -Type DWord

    $personalize = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'
    New-Item -Path $personalize -Force | Out-Null
    Set-ItemProperty -Path $personalize -Name EnableTransparency -Value 0 -Type DWord
}

Function Set-MemoryCPUTweaks {
    $memMgmt = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
    if (-not (Test-Path $memMgmt)) { New-Item -Path $memMgmt -Force | Out-Null }
    Set-ItemProperty -Path $memMgmt -Name DisablePagingExecutive -Value 1 -Type DWord
    Set-ItemProperty -Path $memMgmt -Name IoPageLockLimit -Value 983040 -Type DWord

    $prefetch = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'
    if (-not (Test-Path $prefetch)) { New-Item -Path $prefetch -Force | Out-Null }
    Set-ItemProperty -Path $prefetch -Name EnablePrefetcher -Value 0 -Type DWord
    Set-ItemProperty -Path $prefetch -Name EnableSuperfetch -Value 0 -Type DWord

    $sysProf = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
    if (-not (Test-Path $sysProf)) { New-Item -Path $sysProf -Force | Out-Null }
    Set-ItemProperty -Path $sysProf -Name SystemResponsiveness -Value 0 -Type DWord
    # Use hex literal to represent 0xFFFFFFFF; avoid [uint32] cast which maps to signed Int32 for -Type DWord
    Set-ItemProperty -Path $sysProf -Name NetworkThrottlingIndex -Value 0xFFFFFFFF -Type DWord

    $games = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
    New-Item -Path $games -Force | Out-Null
    Set-ItemProperty -Path $games -Name 'GPU Priority' -Value 8 -Type DWord
    Set-ItemProperty -Path $games -Name 'Priority' -Value 6 -Type DWord
    Set-ItemProperty -Path $games -Name 'Scheduling Category' -Value 'High' -Type String
    Set-ItemProperty -Path $games -Name 'SFIO Priority' -Value 'High' -Type String

    Start-Process -FilePath powercfg.exe -ArgumentList '-setacvalueindex', 'scheme_current', 'sub_processor', 'CPMINCORES', '100' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
    Start-Process -FilePath powercfg.exe -ArgumentList '-setactive', 'scheme_current' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
}

Function Clean-ShellContext {
    if (-not (Get-PSDrive -Name HKCR -ErrorAction SilentlyContinue)) {
        New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
    }

    $hkcrRemovals = @(
        'HKCR:\*\shellex\ContextMenuHandlers\EPP'
        'HKCR:\*\shellex\ContextMenuHandlers\Sharing'
        'HKCR:\Directory\Background\shellex\ContextMenuHandlers\WorkFolders'
        'HKCR:\Directory\shellex\ContextMenuHandlers\Sharing'
        'HKCR:\Drive\shellex\ContextMenuHandlers\Sharing'
        'HKCR:\*\shellex\ContextMenuHandlers\ModernSharing'
    )
    foreach ($p in $hkcrRemovals) {
        Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue
    }

    $adv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    New-Item -Path $adv -Force | Out-Null
    Set-ItemProperty -Path $adv -Name HideFileExt -Value 0 -Type DWord
    Set-ItemProperty -Path $adv -Name Hidden -Value 1 -Type DWord
    Set-ItemProperty -Path $adv -Name ShowSuperHidden -Value 1 -Type DWord

    $nsGuids = @(
        '{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}'
        '{1CF1260C-4DD0-4ebb-811F-33C572699FDE}'
        '{A0953C92-50DC-43bf-BE83-3742FED03C9C}'
    )
    foreach ($g in $nsGuids) {
        foreach ($base in @(
                'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace'
                'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace'
            )) {
            $nsPath = Join-Path $base $g
            Remove-Item -LiteralPath $nsPath -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

Function Remove-EdgeBing {
    $search = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search'
    New-Item -Path $search -Force | Out-Null
    Set-ItemProperty -Path $search -Name BingSearchEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $search -Name CortanaConsent -Value 0 -Type DWord

    $edgePol = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'
    New-Item -Path $edgePol -Force | Out-Null
    Set-ItemProperty -Path $edgePol -Name WebWidgetAllowed -Value 0 -Type DWord
    Set-ItemProperty -Path $edgePol -Name BackgroundModeEnabled -Value 0 -Type DWord
    Set-ItemProperty -Path $edgePol -Name StartupBoostEnabled -Value 0 -Type DWord

    $edgeLegacyMain = 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main'
    New-Item -Path $edgeLegacyMain -Force | Out-Null
    Set-ItemProperty -Path $edgeLegacyMain -Name AllowPrelaunch -Value 0 -Type DWord

    $edgeCu = 'HKCU:\SOFTWARE\Microsoft\Edge'
    New-Item -Path $edgeCu -Force | Out-Null
    Set-ItemProperty -Path $edgeCu -Name StartupBoostEnabled -Value 0 -Type DWord
}

Function Disable-DefenderOptional {
    $defPol = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'
    New-Item -Path $defPol -Force | Out-Null
    Set-ItemProperty -Path $defPol -Name DisableAntiSpyware -Value 1 -Type DWord

    try {
        Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction Stop
    } catch {
        Write-Output "MpPreference skipped: $($_.Exception.Message)"
    }

    foreach ($svcName in @('WdNisSvc', 'WdFilter', 'WdBoot', 'SecurityHealthService')) {
        $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$svcName"
        if (Test-Path -LiteralPath $svcKey) {
            Set-ItemProperty -LiteralPath $svcKey -Name Start -Value 4 -Type DWord -ErrorAction SilentlyContinue
        }
    }

    $sysPol = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'
    New-Item -Path $sysPol -Force | Out-Null
    Set-ItemProperty -Path $sysPol -Name EnableSmartScreen -Value 0 -Type DWord

    $explorer = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer'
    New-Item -Path $explorer -Force | Out-Null
    Set-ItemProperty -Path $explorer -Name SmartScreenEnabled -Value 'Off' -Type String
}

Function Set-UpdatePolicy {
    $wuAu = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
    New-Item -Path $wuAu -Force | Out-Null
    Set-ItemProperty -Path $wuAu -Name NoAutoUpdate -Value 1 -Type DWord
    Set-ItemProperty -Path $wuAu -Name AUOptions -Value 2 -Type DWord
    Set-ItemProperty -Path $wuAu -Name ScheduledInstallDay -Value 0 -Type DWord
    Set-ItemProperty -Path $wuAu -Name ScheduledInstallTime -Value 3 -Type DWord

    $wu = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
    New-Item -Path $wu -Force | Out-Null
    Set-ItemProperty -Path $wu -Name DisableWindowsUpdateAccess -Value 1 -Type DWord
    Set-ItemProperty -Path $wu -Name ExcludeWUDriversInQualityUpdate -Value 1 -Type DWord

    foreach ($svcName in @('wuauserv', 'UsoSvc', 'WaaSMedicSvc')) {
        $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$svcName"
        if (Test-Path -LiteralPath $svcKey) {
            Set-ItemProperty -LiteralPath $svcKey -Name Start -Value 4 -Type DWord
        }
    }

    Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -like '*UpdateOrchestrator*' } | Disable-ScheduledTask -ErrorAction SilentlyContinue
    Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -like '*WaaSMedic*' } | Disable-ScheduledTask -ErrorAction SilentlyContinue
}

Function Remove-Keys {
        
    #These are the registry keys that it will delete.
            
    $Keys = @(
            
        #Remove Background Tasks
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\46928bounde.EclipseManager_2.2.4.51_neutral__a5h4egax66k6y"
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.MicrosoftOfficeHub_17.7909.7600.0_x64__8wekyb3d8bbwe"
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy"
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy"
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy"
            
        #Windows File
        "HKCR:\Extensions\ContractId\Windows.File\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
            
        #Registry keys to delete if they aren't uninstalled by RemoveAppXPackage/RemoveAppXProvisionedPackage
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\46928bounde.EclipseManager_2.2.4.51_neutral__a5h4egax66k6y"
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy"
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy"
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy"
            
        #Scheduled Tasks to delete
        "HKCR:\Extensions\ContractId\Windows.PreInstalledConfigTask\PackageId\Microsoft.MicrosoftOfficeHub_17.7909.7600.0_x64__8wekyb3d8bbwe"
            
        #Windows Protocol Keys
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy"
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy"
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy"
               
        #Windows Share Target
        "HKCR:\Extensions\ContractId\Windows.ShareTarget\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
    )
        
    #This writes the output of each key it is removing and also removes the keys listed above.
    ForEach ($Key in $Keys) {
        Write-Output "Removing $Key from registry"
        Remove-Item -LiteralPath $Key -Recurse -Force -ErrorAction SilentlyContinue
    }
}
            
Function Protect-Privacy {
            
    #Disables Windows Feedback Experience
    Write-Output "Disabling Windows Feedback Experience program"
    $Advertising = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo"
    If (Test-Path $Advertising) {
        Set-ItemProperty -Path $Advertising -Name Enabled -Value 0
    }
            
    #Stops Cortana from being used as part of your Windows Search Function
    Write-Output "Stopping Cortana from being used as part of your Windows Search Function"
    $Search = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
    If (Test-Path $Search) {
        Set-ItemProperty -Path $Search -Name AllowCortana -Value 0
    }

    #Disables Web Search in Start Menu
    Write-Output "Disabling Bing Search in Start Menu"
    $WebSearch = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" -Name BingSearchEnabled -Value 0 
    If (!(Test-Path $WebSearch)) {
        New-Item $WebSearch
    }
    Set-ItemProperty -Path $WebSearch -Name DisableWebSearch -Value 1 
            
    #Stops the Windows Feedback Experience from sending anonymous data
    Write-Output "Stopping the Windows Feedback Experience program"
    $Period = "HKCU:\Software\Microsoft\Siuf\Rules"
    If (!(Test-Path $Period)) { 
        New-Item $Period
    }
    Set-ItemProperty -Path $Period -Name PeriodInNanoSeconds -Value 0 

    #Prevents bloatware applications from returning and removes Start Menu suggestions               
    Write-Output "Adding Registry key to prevent bloatware apps from returning"
    $registryPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent"
    $registryOEM = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
    If (!(Test-Path $registryPath)) { 
        New-Item $registryPath
    }
    Set-ItemProperty -Path $registryPath -Name DisableWindowsConsumerFeatures -Value 1 

    If (!(Test-Path $registryOEM)) {
        New-Item $registryOEM
    }
    Set-ItemProperty -Path $registryOEM -Name ContentDeliveryAllowed -Value 0 
    Set-ItemProperty -Path $registryOEM -Name OemPreInstalledAppsEnabled -Value 0 
    Set-ItemProperty -Path $registryOEM -Name PreInstalledAppsEnabled -Value 0 
    Set-ItemProperty -Path $registryOEM -Name PreInstalledAppsEverEnabled -Value 0 
    Set-ItemProperty -Path $registryOEM -Name SilentInstalledAppsEnabled -Value 0 
    Set-ItemProperty -Path $registryOEM -Name SystemPaneSuggestionsEnabled -Value 0          
    
    #Preping mixed Reality Portal for removal    
    Write-Output "Setting Mixed Reality Portal value to 0 so that you can uninstall it in Settings"
    $Holo = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Holographic"    
    If (Test-Path $Holo) {
        Set-ItemProperty $Holo  FirstRunSucceeded -Value 0 
    }

    #Disables Wi-fi Sense
    Write-Output "Disabling Wi-Fi Sense"
    $WifiSense1 = "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting"
    $WifiSense2 = "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots"
    $WifiSense3 = "HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config"
    If (!(Test-Path $WifiSense1)) {
        New-Item $WifiSense1
    }
    Set-ItemProperty $WifiSense1  Value -Value 0 
    If (!(Test-Path $WifiSense2)) {
        New-Item $WifiSense2
    }
    Set-ItemProperty $WifiSense2  Value -Value 0 
    Set-ItemProperty $WifiSense3  AutoConnectAllowedOEM -Value 0 
        
    #Disables live tiles
    Write-Output "Disabling live tiles"
    $Live = "HKCU:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications"    
    If (!(Test-Path $Live)) {      
        New-Item $Live
    }
    Set-ItemProperty $Live  NoTileApplicationNotification -Value 1 
        
    #Turns off Data Collection via the AllowTelemtry key by changing it to 0
    Write-Output "Turning off Data Collection"
    $DataCollection1 = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"
    $DataCollection2 = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
    $DataCollection3 = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Policies\DataCollection"    
    If (Test-Path $DataCollection1) {
        Set-ItemProperty $DataCollection1  AllowTelemetry -Value 0 
    }
    If (Test-Path $DataCollection2) {
        Set-ItemProperty $DataCollection2  AllowTelemetry -Value 0 
    }
    If (Test-Path $DataCollection3) {
        Set-ItemProperty $DataCollection3  AllowTelemetry -Value 0 
    }
    
    #Disabling Location Tracking
    Write-Output "Disabling Location Tracking"
    $SensorState = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}"
    $LocationConfig = "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration"
    If (!(Test-Path $SensorState)) {
        New-Item $SensorState
    }
    Set-ItemProperty $SensorState SensorPermissionState -Value 0 
    If (!(Test-Path $LocationConfig)) {
        New-Item $LocationConfig
    }
    Set-ItemProperty $LocationConfig Status -Value 0 
        
    #Disables People icon on Taskbar
    Write-Output "Disabling People icon on Taskbar"
    $People = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People'
    If (Test-Path $People) {
        Set-ItemProperty $People -Name PeopleBand -Value 0
    }
        
    #Disables scheduled tasks that are considered unnecessary 
    Write-Output "Disabling scheduled tasks"
    @('XblGameSaveTaskLogon','XblGameSaveTask','Consolidator','UsbCeip','DmClient','DmClientOnScenarioDownload') | ForEach-Object {
        Get-ScheduledTask -TaskName $_ -ErrorAction SilentlyContinue | Disable-ScheduledTask -ErrorAction SilentlyContinue
    }

    Write-Output "Stopping and disabling Diagnostics Tracking Service"
    #Disabling the Diagnostics Tracking Service
    Stop-Service "DiagTrack"
    Set-Service "DiagTrack" -StartupType Disabled

    
    Write-Output "Removing CloudStore from registry if it exists"
    $CloudStore = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore'
    If (Test-Path $CloudStore) {
        Stop-Process Explorer.exe -Force
        Remove-Item $CloudStore -Recurse -Force
        Start-Process Explorer.exe -Wait
    }
}

Function DisableCortana {
    Write-Host "Disabling Cortana"
    $Cortana1 = "HKCU:\SOFTWARE\Microsoft\Personalization\Settings"
    $Cortana2 = "HKCU:\SOFTWARE\Microsoft\InputPersonalization"
    $Cortana3 = "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore"
    If (!(Test-Path $Cortana1)) {
        New-Item $Cortana1
    }
    Set-ItemProperty $Cortana1 AcceptedPrivacyPolicy -Value 0 
    If (!(Test-Path $Cortana2)) {
        New-Item $Cortana2
    }
    Set-ItemProperty $Cortana2 RestrictImplicitTextCollection -Value 1 
    Set-ItemProperty $Cortana2 RestrictImplicitInkCollection -Value 1 
    If (!(Test-Path $Cortana3)) {
        New-Item $Cortana3
    }
    Set-ItemProperty $Cortana3 HarvestContacts -Value 0
    
}

Function EnableCortana {
    Write-Host "Re-enabling Cortana"
    $Cortana1 = "HKCU:\SOFTWARE\Microsoft\Personalization\Settings"
    $Cortana2 = "HKCU:\SOFTWARE\Microsoft\InputPersonalization"
    $Cortana3 = "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore"
    If (!(Test-Path $Cortana1)) {
        New-Item $Cortana1
    }
    Set-ItemProperty $Cortana1 AcceptedPrivacyPolicy -Value 1 
    If (!(Test-Path $Cortana2)) {
        New-Item $Cortana2
    }
    Set-ItemProperty $Cortana2 RestrictImplicitTextCollection -Value 0 
    Set-ItemProperty $Cortana2 RestrictImplicitInkCollection -Value 0 
    If (!(Test-Path $Cortana3)) {
        New-Item $Cortana3
    }
    Set-ItemProperty $Cortana3 HarvestContacts -Value 1 
}
        
Function Stop-EdgePDF {
    
    #Stops edge from taking over as the default .PDF viewer    
    Write-Output "Stopping Edge from taking over as the default .PDF viewer"
    $NoPDF = "HKCR:\.pdf"
    $NoProgids = "HKCR:\.pdf\OpenWithProgids"
    $NoWithList = "HKCR:\.pdf\OpenWithList" 
    If (!(Get-ItemProperty $NoPDF  NoOpenWith)) {
        New-ItemProperty $NoPDF NoOpenWith 
    }        
    If (!(Get-ItemProperty $NoPDF  NoStaticDefaultVerb)) {
        New-ItemProperty $NoPDF  NoStaticDefaultVerb 
    }        
    If (!(Get-ItemProperty $NoProgids  NoOpenWith)) {
        New-ItemProperty $NoProgids  NoOpenWith 
    }        
    If (!(Get-ItemProperty $NoProgids  NoStaticDefaultVerb)) {
        New-ItemProperty $NoProgids  NoStaticDefaultVerb 
    }        
    If (!(Get-ItemProperty $NoWithList  NoOpenWith)) {
        New-ItemProperty $NoWithList  NoOpenWith
    }        
    If (!(Get-ItemProperty $NoWithList  NoStaticDefaultVerb)) {
        New-ItemProperty $NoWithList  NoStaticDefaultVerb 
    }
            
    #Appends an underscore '_' to the Registry key for Edge
    $Edge = "HKCR:\AppXd4nrz8ff68srnhf9t5a8sbjyar1cr723_"
    If (Test-Path $Edge) {
        Set-Item $Edge AppXd4nrz8ff68srnhf9t5a8sbjyar1cr723_ 
    }
}

Function Revert-Changes {   
        
    #This function will revert the changes you made when running the Start-Debloat function.
        
    #This line reinstalls all of the bloatware that was removed
    Get-AppxPackage -AllUsers | ForEach-Object {Add-AppxPackage -Verbose -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"} 
    
    #Tells Windows to enable your advertising information.    
    Write-Output "Re-enabling key to show advertisement information"
    $Advertising = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo"
    If (Test-Path $Advertising) {
        Set-ItemProperty $Advertising  Enabled -Value 1
    }
            
    #Enables Cortana to be used as part of your Windows Search Function
    Write-Output "Re-enabling Cortana to be used in your Windows Search"
    $Search = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
    If (Test-Path $Search) {
        Set-ItemProperty $Search  AllowCortana -Value 1 
    }
            
    #Re-enables the Windows Feedback Experience for sending anonymous data
    Write-Output "Re-enabling Windows Feedback Experience"
    $Period = "HKCU:\Software\Microsoft\Siuf\Rules"
    If (!(Test-Path $Period)) { 
        New-Item $Period
    }
    Set-ItemProperty $Period PeriodInNanoSeconds -Value 1 
    
    #Enables bloatware applications               
    Write-Output "Adding Registry key to allow bloatware apps to return"
    $registryPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent"
    If (!(Test-Path $registryPath)) {
        New-Item $registryPath 
    }
    Set-ItemProperty $registryPath  DisableWindowsConsumerFeatures -Value 0 
        
    #Changes Mixed Reality Portal Key 'FirstRunSucceeded' to 1
    Write-Output "Setting Mixed Reality Portal value to 1"
    $Holo = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Holographic"
    If (Test-Path $Holo) {
        Set-ItemProperty $Holo  FirstRunSucceeded -Value 1 
    }
        
    #Re-enables live tiles
    Write-Output "Enabling live tiles"
    $Live = "HKCU:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications"
    If (!(Test-Path $Live)) {
        New-Item $Live 
    }
    Set-ItemProperty $Live  NoTileApplicationNotification -Value 0 
       
    #Re-enables data collection
    Write-Output "Re-enabling data collection"
    $DataCollection = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"
    If (!(Test-Path $DataCollection)) {
        New-Item $DataCollection
    }
    Set-ItemProperty $DataCollection  AllowTelemetry -Value 1
        
    #Re-enables People Icon on Taskbar
    Write-Output "Enabling People icon on Taskbar"
    $People = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People"
    If (!(Test-Path $People)) {
        New-Item $People 
    }
    Set-ItemProperty $People  PeopleBand -Value 1 
    
    #Re-enables suggestions on start menu
    Write-Output "Enabling suggestions on the Start Menu"
    $Suggestions = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
    If (!(Test-Path $Suggestions)) {
        New-Item $Suggestions
    }
    Set-ItemProperty $Suggestions  SystemPaneSuggestionsEnabled -Value 1 
        
    #Re-enables scheduled tasks that were disabled when running the Debloat switch
    Write-Output "Enabling scheduled tasks that were disabled"
    Get-ScheduledTask XblGameSaveTaskLogon | Enable-ScheduledTask 
    Get-ScheduledTask  XblGameSaveTask | Enable-ScheduledTask 
    Get-ScheduledTask  Consolidator | Enable-ScheduledTask 
    Get-ScheduledTask  UsbCeip | Enable-ScheduledTask 
    Get-ScheduledTask  DmClient | Enable-ScheduledTask 
    Get-ScheduledTask  DmClientOnScenarioDownload | Enable-ScheduledTask 

    Write-Output "Re-enabling and starting WAP Push Service"
    #Enable and start WAP Push Service
    Set-Service "dmwappushservice" -StartupType Automatic
    Start-Service "dmwappushservice"
    
    Write-Output "Re-enabling and starting the Diagnostics Tracking Service"
    #Enabling the Diagnostics Tracking Service
    Set-Service "DiagTrack" -StartupType Automatic
    Start-Service "DiagTrack"
    
    Write-Output "Restoring 3D Objects in the 'My Computer' submenu in explorer"
    #Restoring 3D Objects in the 'My Computer' submenu in explorer
    Restore3dObjects
}

Function CheckDMWService {

    Param([switch]$Debloat)
  
    If (Get-Service -Name dmwappushservice | Where-Object {$_.StartType -eq "Disabled"}) {
        Set-Service -Name dmwappushservice -StartupType Automatic
    }

    If (Get-Service -Name dmwappushservice | Where-Object {$_.Status -eq "Stopped"}) {
        Start-Service -Name dmwappushservice
    } 
}

Function DisableDiagTrack {
    Write-Output "Stopping and disabling Diagnostics Tracking Service"
    Stop-Service "DiagTrack" -Force -ErrorAction SilentlyContinue
    Set-Service "DiagTrack" -StartupType Disabled -ErrorAction SilentlyContinue
}

Function DisableWAPPush {
    Write-Output "Stopping and disabling WAP Push Service"
    Stop-Service "dmwappushservice" -Force -ErrorAction SilentlyContinue
    Set-Service "dmwappushservice" -StartupType Disabled -ErrorAction SilentlyContinue
}
    
Function Enable-EdgePDF {
    Write-Output "Setting Edge back to default"
    $NoPDF = "HKCR:\.pdf"
    $NoProgids = "HKCR:\.pdf\OpenWithProgids"
    $NoWithList = "HKCR:\.pdf\OpenWithList"
    #Sets edge back to default
    If (Get-ItemProperty $NoPDF  NoOpenWith) {
        Remove-ItemProperty $NoPDF  NoOpenWith
    } 
    If (Get-ItemProperty $NoPDF  NoStaticDefaultVerb) {
        Remove-ItemProperty $NoPDF  NoStaticDefaultVerb 
    }       
    If (Get-ItemProperty $NoProgids  NoOpenWith) {
        Remove-ItemProperty $NoProgids  NoOpenWith 
    }        
    If (Get-ItemProperty $NoProgids  NoStaticDefaultVerb) {
        Remove-ItemProperty $NoProgids  NoStaticDefaultVerb 
    }        
    If (Get-ItemProperty $NoWithList  NoOpenWith) {
        Remove-ItemProperty $NoWithList  NoOpenWith
    }    
    If (Get-ItemProperty $NoWithList  NoStaticDefaultVerb) {
        Remove-ItemProperty $NoWithList  NoStaticDefaultVerb
    }
        
    #Removes an underscore '_' from the Registry key for Edge
    $Edge2 = "HKCR:\AppXd4nrz8ff68srnhf9t5a8sbjyar1cr723_"
    If (Test-Path $Edge2) {
        Set-Item $Edge2 AppXd4nrz8ff68srnhf9t5a8sbjyar1cr723
    }
}

Function FixWhitelistedApps {
    
    If (!(Get-AppxPackage -AllUsers | Select Microsoft.Paint3D, Microsoft.WindowsCalculator, Microsoft.WindowsStore, Microsoft.Windows.Photos)) {
    
        #Credit to abulgatz for these 4 lines of code
        Get-AppxPackage -allusers Microsoft.Paint3D | ForEach-Object {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
        Get-AppxPackage -allusers Microsoft.WindowsCalculator | ForEach-Object {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
        Get-AppxPackage -allusers Microsoft.WindowsStore | ForEach-Object {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
        Get-AppxPackage -allusers Microsoft.Windows.Photos | ForEach-Object {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml"}
    } 
}

Function UninstallOneDrive {

    Write-Host "Checking for pre-existing files and folders located in the OneDrive folders..."
    Start-Sleep 1
    If (Test-Path "$env:USERPROFILE\OneDrive\*") {
        Write-Host "Files found within the OneDrive folder! Checking to see if a folder named OneDriveBackupFiles exists."
        Start-Sleep 1

        If (!(Test-Path "$env:USERPROFILE\Desktop\OneDriveBackupFiles")) {
            Write-Host "A folder named OneDriveBackupFiles will be created and will be located on your desktop. All files from your OneDrive location will be located in that folder."
            New-Item -Path "$env:USERPROFILE\Desktop" -Name "OneDriveBackupFiles" -ItemType Directory -Force
            Write-Host "Successfully created the folder 'OneDriveBackupFiles' on your desktop."
        } Else {
            Write-Host "A folder named OneDriveBackupFiles already exists on your desktop. All files from your OneDrive location will be moved to that folder." 
        }
        Start-Sleep 1
        Move-Item -Path "$env:USERPROFILE\OneDrive\*" -Destination "$env:USERPROFILE\Desktop\OneDriveBackupFiles" -Force
        Write-Host "Successfully moved all files/folders from your OneDrive folder to the folder 'OneDriveBackupFiles' on your desktop."
        Start-Sleep 1
        Write-Host "Proceeding with the removal of OneDrive."
        Start-Sleep 1
    }
    Else {
        Write-Host "Either the OneDrive folder does not exist or there are no files to be found in the folder. Proceeding with removal of OneDrive."
        Start-Sleep 1
    }

    Write-Host "Uninstalling OneDrive. Please wait..."
    New-PSDrive  HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
    $ExplorerReg1 = "HKCR:\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}"
    $ExplorerReg2 = "HKCR:\Wow6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}"
    Stop-Process -Name "OneDrive*" -Force -ErrorAction SilentlyContinue
    Start-Sleep 2

    $onedrive = "$env:SYSTEMROOT\SysWOW64\OneDriveSetup.exe"
    If (!(Test-Path $onedrive)) {
        $onedrive = "$env:SYSTEMROOT\System32\OneDriveSetup.exe"
    }
    Start-Process $onedrive "/uninstall" -NoNewWindow -Wait -ErrorAction SilentlyContinue
    Start-Sleep 2

    Write-Output "Stopping explorer"
    Start-Sleep 1
    taskkill.exe /F /IM explorer.exe
    Start-Sleep 3
    Write-Output "Removing leftover files"
    If (Test-Path "$env:USERPROFILE\OneDrive") {
        Remove-Item "$env:USERPROFILE\OneDrive" -Force -Recurse -ErrorAction SilentlyContinue
    }
    If (Test-Path "$env:LOCALAPPDATA\Microsoft\OneDrive") {
        Remove-Item "$env:LOCALAPPDATA\Microsoft\OneDrive" -Force -Recurse -ErrorAction SilentlyContinue
    }
    If (Test-Path "$env:PROGRAMDATA\Microsoft OneDrive") {
        Remove-Item "$env:PROGRAMDATA\Microsoft OneDrive" -Force -Recurse -ErrorAction SilentlyContinue
    }
    If (Test-Path "$env:SYSTEMDRIVE\OneDriveTemp") {
        Remove-Item "$env:SYSTEMDRIVE\OneDriveTemp" -Force -Recurse -ErrorAction SilentlyContinue
    }
    Write-Output "Removing OneDrive from windows explorer"
    If (!(Test-Path $ExplorerReg1)) {
        New-Item $ExplorerReg1
    }
    Set-ItemProperty $ExplorerReg1 System.IsPinnedToNameSpaceTree -Value 0 
    If (!(Test-Path $ExplorerReg2)) {
        New-Item $ExplorerReg2
    }
    Set-ItemProperty $ExplorerReg2 System.IsPinnedToNameSpaceTree -Value 0
    Write-Output "Restarting Explorer that was shut down before."
    Start-Process explorer.exe -NoNewWindow

    Write-Host "Enabling the Group Policy 'Prevent the usage of OneDrive for File Storage'."
    $OneDriveKey = 'HKLM:Software\Policies\Microsoft\Windows\OneDrive'
    If (!(Test-Path $OneDriveKey)) {
        Mkdir $OneDriveKey
    }
    Set-ItemProperty $OneDriveKey -Name OneDrive -Value DisableFileSyncNGSC
    Remove-Item env:OneDrive -ErrorAction SilentlyContinue
    Write-Host "OneDrive has been successfully uninstalled!"
}

Function UnpinStart {
    # https://superuser.com/a/1442733
    #Requires -RunAsAdministrator

$START_MENU_LAYOUT = @"
<LayoutModificationTemplate xmlns:defaultlayout="http://schemas.microsoft.com/Start/2014/FullDefaultLayout" xmlns:start="http://schemas.microsoft.com/Start/2014/StartLayout" Version="1" xmlns:taskbar="http://schemas.microsoft.com/Start/2014/TaskbarLayout" xmlns="http://schemas.microsoft.com/Start/2014/LayoutModification">
    <LayoutOptions StartTileGroupCellWidth="6" />
    <DefaultLayoutOverride>
        <StartLayoutCollection>
            <defaultlayout:StartLayout GroupCellWidth="6" />
        </StartLayoutCollection>
    </DefaultLayoutOverride>
</LayoutModificationTemplate>
"@

    $layoutFile="C:\Windows\StartMenuLayout.xml"

    #Delete layout file if it already exists
    If(Test-Path $layoutFile)
    {
        Remove-Item $layoutFile
    }

    #Creates the blank layout file
    $START_MENU_LAYOUT | Out-File $layoutFile -Encoding ASCII

    $regAliases = @("HKLM", "HKCU")

    #Assign the start layout and force it to apply with "LockedStartLayout" at both the machine and user level
    foreach ($regAlias in $regAliases){
        $basePath = $regAlias + ":\SOFTWARE\Policies\Microsoft\Windows"
        $keyPath = $basePath + "\Explorer" 
        IF(!(Test-Path -Path $keyPath)) { 
            New-Item -Path $basePath -Name "Explorer"
        }
        Set-ItemProperty -Path $keyPath -Name "LockedStartLayout" -Value 1
        Set-ItemProperty -Path $keyPath -Name "StartLayoutFile" -Value $layoutFile
    }

    #Restart Explorer, open the start menu (necessary to load the new layout), and give it a few seconds to process
    Stop-Process -name explorer
    Start-Sleep -s 5
    $wshell = New-Object -ComObject wscript.shell; $wshell.SendKeys('^{ESCAPE}')
    Start-Sleep -s 5

    #Enable the ability to pin items again by disabling "LockedStartLayout"
    foreach ($regAlias in $regAliases){
        $basePath = $regAlias + ":\SOFTWARE\Policies\Microsoft\Windows"
        $keyPath = $basePath + "\Explorer" 
        Set-ItemProperty -Path $keyPath -Name "LockedStartLayout" -Value 0
    }

    #Restart Explorer and delete the layout file
    Stop-Process -name explorer

    # Uncomment the next line to make clean start menu default for all new users
    #Import-StartLayout -LayoutPath $layoutFile -MountPath $env:SystemDrive\

    Remove-Item $layoutFile
}

Function Remove3dObjects {
    #Removes 3D Objects from the 'My Computer' submenu in explorer
    Write-Host "Removing 3D Objects from explorer 'My Computer' submenu"
    $Objects32 = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}"
    $Objects64 = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}"
    If (Test-Path $Objects32) {
        Remove-Item $Objects32 -Recurse 
    }
    If (Test-Path $Objects64) {
        Remove-Item $Objects64 -Recurse 
    }
}

Function Restore3dObjects {
    #Restores 3D Objects from the 'My Computer' submenu in explorer
    Write-Host "Restoring 3D Objects from explorer 'My Computer' submenu"
    $Objects32 = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}"
    $Objects64 = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}"
    If (!(Test-Path $Objects32)) {
        New-Item $Objects32
    }
    If (!(Test-Path $Objects64)) {
        New-Item $Objects64
    }
}

#Function DisableLastUsedFilesAndFolders {
#	Write-Host = "Disable Explorer to show last used files and folders."
#	Invoke-Item (start powershell ((Split-Path $MyInvocation.InvocationName) + "\Individual Scripts\Disable Last Used Files and Folders View.ps1"))
#}

#Interactive prompt Debloat/Revert options
if (-not $Silent) {
Add-Type -AssemblyName PresentationCore, PresentationFramework
$Button = [Windows.MessageBoxButton]::YesNoCancel
$ErrorIco = [Windows.MessageBoxImage]::Error
$Warn = [Windows.MessageBoxImage]::Warning
$Ask = 'The following will allow you to either Debloat Windows 10 or to revert changes made after Debloating Windows 10.

        Select "Yes" to Debloat Windows 10

        Select "No" to Revert changes made by this script
        
        Select "Cancel" to stop the script.'

$EverythingorSpecific = "Would you like to remove everything that was preinstalled on your Windows Machine? Select Yes to remove everything, or select No to remove apps via a blacklist."
$EdgePdf = "Do you want to stop edge from taking over as the default PDF viewer?"
$EdgePdf2 = "Do you want to revert changes that disabled Edge as the default PDF viewer?"
$Reboot = "For some of the changes to properly take effect it is recommended to reboot your machine. Would you like to restart?"
$OneDriveDelete = "Do you want to uninstall One Drive?"
$Unpin = "Do you want to unpin all items from the Start menu?"
$InstallNET = "Do you want to install .NET 3.5?"
$CleanJunkFiles = "Clean junk files?"
$DisableAutoUpdates = "Disable automatic Windows Updates?"
$DefenderDisableWarn = "⚠️ OPTIONAL: Disable Windows Defender? (NOT recommended unless you have a replacement AV)"
$EdgeBingWarn = "Disable Edge background services and Bing in search?"
$LastUsedFilesFolders = "Do you want to hide last used files and folders in Explorer?"
$LastUsedFilesFolders2 = "Do you want to show last used files and folders in Explorer?"
$ClearLastUsedFilesFolders = "Do you want to clear last used files and folders?"
$AeroShake = "Do you want to disable AeroShake?"
$AeroShake2 = "Do you want to re-enable AeroShake?"
$Prompt1 = [Windows.MessageBox]::Show($Ask, "Debloat or Revert", $Button, $ErrorIco) 
Switch ($Prompt1) {
    #This will debloat Windows 10
    Yes {
        #Everything is specific prompt
        $Prompt2 = [Windows.MessageBox]::Show($EverythingorSpecific, "Everything or Specific", $Button, $Warn)
        switch ($Prompt2) {
            Yes { 
                #Creates a "drive" to access the HKCR (HKEY_CLASSES_ROOT)
                Write-Host "Creating PSDrive 'HKCR' (HKEY_CLASSES_ROOT). This will be used for the duration of the script as it is necessary for the removal and modification of specific registry keys."
                New-PSDrive  HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
                Start-Sleep 1
                Write-Host "Uninstalling bloatware, please wait."
                DebloatAll
                Remove-DISMFeatures
                Disable-UnnecessaryServices
                Remove-ScheduledTasks
                Set-PerformanceTweaks
                Set-ExtendedPrivacy
                Clear-JunkFiles
                Set-NetworkAndPower
                Set-TimerResolution
                Set-VisualStrip
                Set-MemoryCPUTweaks
                Clean-ShellContext
                Write-Host "Bloatware removed."
                Start-Sleep 1
                Write-Host "Removing specific registry keys."
                Remove-Keys
                Write-Host "Leftover bloatware registry keys removed."
                Start-Sleep 1
                Write-Host "Checking to see if any Whitelisted Apps were removed, and if so re-adding them."
                Start-Sleep 1
                FixWhitelistedApps
                Start-Sleep 1
                Write-Host "Disabling Cortana from search, disabling feedback to Microsoft, and disabling scheduled tasks that are considered to be telemetry or unnecessary."
                Protect-Privacy
                Start-Sleep 1
                DisableCortana
                Write-Host "Cortana disabled and removed from search, feedback to Microsoft has been disabled, and scheduled tasks are disabled."
                Start-Sleep 1
                Write-Host "Stopping and disabling Diagnostics Tracking Service"
                DisableDiagTrack
                Write-Host "Diagnostics Tracking Service disabled"
                Start-Sleep 1
                Write-Host "Disabling WAP push service"
                DisableWAPPush
                Start-Sleep 1
                Write-Host "Re-enabling DMWAppushservice if it was disabled"
                CheckDMWService
                Start-Sleep 1
                Write-Host "Removing 3D Objects from the 'My Computer' submenu in explorer"
                Remove3dObjects
                Start-Sleep 1
            }
            No {
                #Creates a "drive" to access the HKCR (HKEY_CLASSES_ROOT)
                Write-Host "Creating PSDrive 'HKCR' (HKEY_CLASSES_ROOT). This will be used for the duration of the script as it is necessary for the removal and modification of specific registry keys."
                New-PSDrive  HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
                Start-Sleep 1
                Write-Host "Uninstalling bloatware, please wait."
                DebloatBlacklist
                Remove-DISMFeatures
                Write-Host "Bloatware removed."
                Start-Sleep 1
                Write-Host "Removing specific registry keys."
                Remove-Keys
                Write-Host "Leftover bloatware registry keys removed."
                Start-Sleep 1
                Write-Host "Checking to see if any Whitelisted Apps were removed, and if so re-adding them."
                Start-Sleep 1
                FixWhitelistedApps
                Start-Sleep 1
                Write-Host "Disabling Cortana from search, disabling feedback to Microsoft, and disabling scheduled tasks that are considered to be telemetry or unnecessary."
                Protect-Privacy
                Start-Sleep 1
                DisableCortana
                Write-Host "Cortana disabled and removed from search, feedback to Microsoft has been disabled, and scheduled tasks are disabled."
                Start-Sleep 1
                Write-Host "Stopping and disabling Diagnostics Tracking Service"
                DisableDiagTrack
                Write-Host "Diagnostics Tracking Service disabled"
                Start-Sleep 1
                Write-Host "Disabling WAP push service"
                Start-Sleep 1
                DisableWAPPush
                Write-Host "Re-enabling DMWAppushservice if it was disabled"
                CheckDMWService
                Start-Sleep 1
            }
        }

        $Prompt3 = [Windows.MessageBox]::Show($EdgePdf, 'Edge PDF', [Windows.MessageBoxButton]::YesNo, [Windows.MessageBoxImage]::Warning)
        if ($Prompt3 -eq [Windows.MessageBoxResult]::Yes) {
            Stop-EdgePDF
            Write-Host "Edge will no longer take over as the default PDF viewer."
        } elseif ($Prompt3 -eq [Windows.MessageBoxResult]::No) {
            Write-Host "You chose not to stop Edge from taking over as the default PDF viewer."
        } else {
            Write-Host "Edge PDF prompt returned unexpected value: $Prompt3"
        }
        #Prompt asking to delete OneDrive
        $Prompt4 = [Windows.MessageBox]::Show($OneDriveDelete, "Delete OneDrive", $Button, $ErrorIco) 
        if ($Prompt4 -eq [Windows.MessageBoxResult]::Yes) {
            UninstallOneDrive
            Write-Host "OneDrive is now removed from the computer."
        } elseif ($Prompt4 -eq [Windows.MessageBoxResult]::No) {
            Write-Host "You have chosen to skip removing OneDrive from your machine."
        } else {
            Write-Host "OneDrive delete prompt returned unexpected value: $Prompt4"
        }
        #Prompt asking if you'd like to unpin all start items
        $Prompt5 = [Windows.MessageBox]::Show($Unpin, "Unpin", $Button, $ErrorIco) 
        if ($Prompt5 -eq [Windows.MessageBoxResult]::Yes) {
            UnpinStart
            Write-Host "Start Apps unpined."
        } elseif ($Prompt5 -eq [Windows.MessageBoxResult]::No) {
            Write-Host "Apps will remain pinned to the start menu."
        } else {
            Write-Host "Unpin prompt returned unexpected value: $Prompt5"
        }
        $PromptUpdate = [Windows.MessageBox]::Show($DisableAutoUpdates, "Windows Update", $Button, $Warn)
        if ($PromptUpdate -eq [Windows.MessageBoxResult]::Yes) {
            Set-UpdatePolicy
            Write-Host "Automatic Windows Update policy and related tasks have been restricted."
        } elseif ($PromptUpdate -eq [Windows.MessageBoxResult]::No) {
            Write-Host "Skipping Windows Update policy changes."
        } else {
            Write-Host "Windows Update prompt returned unexpected value: $PromptUpdate"
        }
        $PromptDefender = [Windows.MessageBox]::Show($DefenderDisableWarn, "Windows Defender", [Windows.MessageBoxButton]::YesNo, $Warn)
        if ($PromptDefender -eq [Windows.MessageBoxResult]::Yes) {
            Disable-DefenderOptional
            Write-Host "Optional Windows Defender / SmartScreen mitigations were applied."
        } elseif ($PromptDefender -eq [Windows.MessageBoxResult]::No) {
            Write-Host "Keeping Windows Defender and SmartScreen defaults (skipped optional disable)."
        } else {
            Write-Host "Defender prompt returned unexpected value: $PromptDefender"
        }
        $PromptEdgeBing = [Windows.MessageBox]::Show($EdgeBingWarn, "Edge and search", [Windows.MessageBoxButton]::YesNo, $Warn)
        if ($PromptEdgeBing -eq [Windows.MessageBoxResult]::Yes) {
            Remove-EdgeBing
            Write-Host "Edge background policies and Bing search restrictions were applied."
        } elseif ($PromptEdgeBing -eq [Windows.MessageBoxResult]::No) {
            Write-Host "Skipping Edge background and Bing search tweaks."
        } else {
            Write-Host "Edge Bing prompt returned unexpected value: $PromptEdgeBing"
        }
        #Prompt asking if you want to install .NET
        $Prompt6 = [Windows.MessageBox]::Show($InstallNET, "Install .Net", $Button, $Warn)
        if ($Prompt6 -eq [Windows.MessageBoxResult]::Yes) {
            Write-Host "Initializing the installation of .NET 3.5..."
            DISM /Online /Enable-Feature /FeatureName:NetFx3 /All
            Write-Host ".NET 3.5 has been successfully installed!"
        } elseif ($Prompt6 -eq [Windows.MessageBoxResult]::No) {
            Write-Host "Skipping .NET install."
        } else {
            Write-Host "Install .NET prompt returned unexpected value: $Prompt6"
        }
        $PromptJunk = [Windows.MessageBox]::Show($CleanJunkFiles, "Clean junk files", $Button, $Warn)
        if ($PromptJunk -eq [Windows.MessageBoxResult]::Yes) {
            Clear-JunkFiles
            Write-Host "Junk file cleanup finished."
        } elseif ($PromptJunk -eq [Windows.MessageBoxResult]::No) {
            Write-Host "Skipping junk file cleanup."
        } else {
            Write-Host "Junk cleanup prompt returned unexpected value: $PromptJunk"
        }
#		#Prompt asking if you want to deactivate Last Used Files and Folders
#        $Prompt7 = [Windows.MessageBox]::Show($LastUsedFilesFolders, "Deactivate Last Used Files and Folders", $Button, $Warn)
#        Switch ($Prompt7) {
#            Yes {
#                DisableLastUsedFilesAndFolders
#                Write-Host "Last Used Files and Folders will no longer been shown!"
#            }
#            No {
#                Write-Host "Skipping Hiding Last used Files and Folders."
#            }
#        }
		
        #Prompt asking if you'd like to reboot your machine
        $Prompt0 = [Windows.MessageBox]::Show($Reboot, "Reboot", $Button, $Warn)
        Switch ($Prompt0) {
            'Yes' {
                Write-Host "Unloading the HKCR drive..."
                Remove-PSDrive HKCR 
                Start-Sleep 1
                Write-Host "Initiating reboot."
                Stop-Transcript
                Start-Sleep 2
                Restart-Computer
            }
            'No' {
                Write-Host "Unloading the HKCR drive..."
                Remove-PSDrive HKCR 
                Start-Sleep 1
                Write-Host "Script has finished. Exiting."
                Stop-Transcript
                Start-Sleep 2
                Exit
            }
        }
    }
    'No' {
        Write-Host "Reverting changes..."
        Write-Host "Creating PSDrive 'HKCR' (HKEY_CLASSES_ROOT). This will be used for the duration of the script as it is necessary for the modification of specific registry keys."
        New-PSDrive  HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
        Revert-Changes
        #Prompt asking to revert edge changes as well
        $Prompt6 = [Windows.MessageBox]::Show($EdgePdf2, "Revert Edge", $Button, $ErrorIco)
        Switch ($Prompt6) {
            'Yes' {
                Enable-EdgePDF
                Write-Host "Edge will no longer be disabled from being used as the default Edge PDF viewer."
            }
            'No' {
                Write-Host "You have chosen to keep the setting that disallows Edge to be the default PDF viewer."
            }
        }
        #Prompt asking if you'd like to reboot your machine
        $Prompt0 = [Windows.MessageBox]::Show($Reboot, "Reboot", $Button, $Warn)
        Switch ($Prompt0) {
            'Yes' {
                Write-Host "Unloading the HKCR drive..."
                Remove-PSDrive HKCR 
                Start-Sleep 1
                Write-Host "Initiating reboot."
                Stop-Transcript
                Start-Sleep 2
                Restart-Computer
            }
            'No' {
                Write-Host "Unloading the HKCR drive..."
                Remove-PSDrive HKCR 
                Start-Sleep 1
                Write-Host "Script has finished. Exiting."
                Stop-Transcript
                Start-Sleep 2
                Exit
            }
        }
    }
}
} else {
    # Create registry backup before destructive changes (silent)
    $backupPath = "$DebloatFolder\reg_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').reg"
    Write-Output "Creating HKLM registry backup at $backupPath"
    Start-Process -FilePath reg.exe -ArgumentList "export HKLM `"$backupPath`" /y" -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
    Write-Output 'Silent mode: executing debloat sequence (no prompts).'
    DebloatAll
    DebloatBlacklist
    Remove-DISMFeatures
    Disable-UnnecessaryServices
    Remove-ScheduledTasks
    Set-PerformanceTweaks
    Set-ExtendedPrivacy
    Clear-JunkFiles
    Set-NetworkAndPower
    Set-UpdatePolicy
    Set-TimerResolution
    Set-VisualStrip
    Set-MemoryCPUTweaks
    Clean-ShellContext
    Remove-EdgeBing
    # Defender intentionally excluded from silent auto-run
    Stop-Transcript
}
