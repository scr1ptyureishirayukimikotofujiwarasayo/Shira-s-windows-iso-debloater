# BakuretsuClean

A comprehensive Windows 10/11 debloater script that removes bloatware, disables telemetry, and optimises performance.

## Features

- Remove pre-installed Windows AppX bloatware
- Disable unnecessary Windows services
- Disable telemetry and data collection
- Remove OneDrive integration
- Performance and network tweaks
- Privacy-focused registry modifications
- Interactive GUI prompts for granular control
- Silent mode for automated deployment
- Revert option to undo changes

## How to Use

1. **Right-click** `RunDebloater.bat` and select **Run as Administrator**
2. Follow the interactive prompts to choose what to debloat
3. Reboot when prompted for all changes to take effect

### Silent Mode

Run the PowerShell script directly with the `-Silent` flag:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File WindowsUltraDebloater.ps1 -Silent
```

This skips all prompts and runs the full debloat sequence (excluding Windows Defender).

## Important

- Always create a system restore point before running
- Some tweaks (like disabling Windows Update) may need to be reversed for certain software
- The script requires Administrator privileges

## License

MIT License - see [LICENSE](LICENSE) file
