# Windows ISO Debloater (Enhanced)
# Author: shirayukimikoto
# Date: 2023-11-21 (Enhanced 2026-06-01)
# Description: Advanced PSscript to create stripped Windows ISOs comparable to Windows X-Lite / KernelOS.
# Now includes: Service disabling, Deep WinSxS cleanup, Defender removal, Hyper-V removal,
#               Widgets removal, Performance tweaks, Expanded package lists, and more.

param(
    [switch]$noPrompt,
    [string]$isoPath = "",
    [string]$winEdition = "",
    [string]$outputISO = "",
    [ValidateSet("yes", "no")]$useDISM = "",
    [ValidateSet("yes", "no")]$AppxRemove = "",
    [ValidateSet("yes", "no")]$CapabilitiesRemove = "",
    [ValidateSet("yes", "no")]$OnedriveRemove = "",
    [ValidateSet("yes", "no")]$EDGERemove = "",
    [ValidateSet("yes", "no")]$AIRemove = "",
    [ValidateSet("yes", "no")]$TPMBypass = "",
    [ValidateSet("yes", "no")]$UserFoldersEnable = "",
    [ValidateSet("yes", "no")]$DriverIntegrate = "",
    [ValidateSet("yes", "no")]$ESDConvert = "",
    [ValidateSet("yes", "no")]$useOscdimg = "",
    [ValidateSet("yes", "no")]$DefenderRemove = "",
    [ValidateSet("yes", "no")]$WidgetsRemove = "",
    [ValidateSet("yes", "no")]$WinUpdateDisable = "",
    [ValidateSet("yes", "no")]$HyperVRemove = "",
    [ValidateSet("yes", "no")]$ExtremeDebloat = "",
    [ValidateSet("yes", "no")]$ServicesDisable = "",
    [ValidateSet("yes", "no")]$PerformanceTweaks = "",
    [ValidateSet("yes", "no")]$TaskCleanup = "",
    [ValidateSet("yes", "no")]$WinSxSCleanup = "",
    [switch]$SafeMode
)

# If -noPrompt is used, ensure required parameters are provided
if ($noPrompt) {
    $missing = @("isoPath","winEdition","outputISO") | Where-Object { [string]::IsNullOrWhiteSpace((Get-Variable $_).Value) }
    if ($missing) { Write-Error "When using -noPrompt, these parameters are required: $($missing -join ', ')"; Exit 1 }
}

# Disable Pause if -noprompt is used
if ($noPrompt) { function Pause { } }

# Administrator Privileges
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "This script must be run as Administrator. Re-launching with elevated privileges..." -ForegroundColor Yellow

    # Resolve relative paths before relaunching
    if ($isoPath -and -not [System.IO.Path]::IsPathRooted($isoPath)) {
        $isoPath = Join-Path -Path $PSScriptRoot -ChildPath $isoPath | Resolve-Path -ErrorAction SilentlyContinue
        if (-not $isoPath) {
            $isoPath = Join-Path -Path (Get-Location).Path -ChildPath $PSBoundParameters['isoPath']
            if (Test-Path $isoPath) {
                $isoPath = (Get-Item $isoPath).FullName
            }
        }
    }
    if ($outputISO -and -not [System.IO.Path]::IsPathRooted($outputISO)) {
        $outputISO = Join-Path -Path (Get-Location).Path -ChildPath $outputISO
        $outputISO = [System.IO.Path]::GetFullPath($outputISO)
    }

    $params = @()
    $PSBoundParameters.GetEnumerator() | ForEach-Object {
        if ($_.Value -is [switch] -and $_.Value) { $params += "-$($_.Key)" }
        elseif ($_.Value -is [string] -and $_.Value) {
            # Use resolved paths for isoPath and outputISO
            if ($_.Key -eq 'isoPath' -and $isoPath) { $params += "-$($_.Key)", "`"$isoPath`"" }
            elseif ($_.Key -eq 'outputISO' -and $outputISO) { $params += "-$($_.Key)", "`"$outputISO`"" }
            else { $params += "-$($_.Key)", "`"$($_.Value)`"" }
        }
    }
    $argss = "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`" $($params -join ' ')"
    if (Get-Command wt -ErrorAction SilentlyContinue) { Start-Process wt "PowerShell $argss" -Verb RunAs }
    else { Start-Process PowerShell $argss -Verb RunAs }
    Exit
}
Clear-Host
$asciiArt = @"
 _       ___           __                      _________ ____     ____       __    __            __
| |     / (_)___  ____/ /___ _      _______   /  _/ ___// __ \   / __ \___  / /_  / /___  ____ _/ /____  _____
| | /| / / / __ \/ __  / __ \ | /| / / ___/   / / \__ \/ / / /  / / / / _ \/ __ \/ / __ \/ __ `/ __/ _ \/ ___/
| |/ |/ / / / / / /_/ / /_/ / |/ |/ (__  )  _/ / ___/ / /_/ /  / /_/ /  __/ /_/ / / /_/ / /_/ / /_/  __/ /
|__/|__/_/_/ /_/\__,_/\____/|__/|__/____/  /___//____/\____/  /_____/\___/_.___/_/\____/\__,_/\__/\___/_/
                                                                               -By shirayukimikoto
"@

Write-Host $asciiArt -ForegroundColor Cyan
Start-Sleep -Milliseconds 1000
Write-Host "Starting Windows ISO Debloater Script..." -ForegroundColor Green
Start-Sleep -Milliseconds 800
Write-Host "`n*Important Notes: " -ForegroundColor Yellow
Write-Host "  1. Some prompts will appear during the process."
Write-Host "  2. Administrative privileges are required to run this script."
Write-Host "  3. Review the script beforehand to understand its actions."
Write-Host "  4. To whitelist a package, open the script and comment out the corresponding Packagename."
Write-Host "  5. Select the ISO to proceed."
Write-Host "  6. Press [S] during long operations to skip to the next step." -ForegroundColor Green
Start-Sleep -Milliseconds 800

$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'
$PSDefaultParameterValues['*:Encoding'] = 'utf8'
$scriptDirectory = "$PSScriptRoot"
$logFilePath = Join-Path -Path $scriptDirectory -ChildPath 'script_log.txt'         # Log File Path
$errorLogDir = Join-Path -Path $scriptDirectory -ChildPath 'ErrorLogs'               # Error Log Directory
$runTimestamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
$errorLogPath = Join-Path -Path $errorLogDir -ChildPath "errors_$runTimestamp.log"   # Error Log File for this run
$errorSummaryPath = Join-Path -Path $errorLogDir -ChildPath "summary_$runTimestamp.txt" # Summary file
$script:ErrorCount = 0
$script:WarnCount = 0
$script:ErrorItems = [System.Collections.ArrayList]::new()
$script:WarnItems = [System.Collections.ArrayList]::new()
$script:SkipItems = [System.Collections.ArrayList]::new()

# Ensure error log directory exists
if (-not (Test-Path $errorLogDir)) { New-Item -ItemType Directory -Path $errorLogDir -Force | Out-Null }
$transcript = "$env:TEMP\transcript_$(Get-Random).txt"                              # Start Transcript
Start-Transcript $transcript -Append -ErrorAction SilentlyContinue 2>&1 | Out-Null

# Get system information
$osInfo = Get-WmiObject -Class Win32_OperatingSystem
$logEntry = @"
$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Script started
- Launched As: $((Get-CimInstance Win32_Process -Filter "ProcessId = $PID").CommandLine)
- Windows Version: $($osInfo.Caption) $($osInfo.Version) (Build $($osInfo.BuildNumber))
- System Architecture: $($osInfo.OSArchitecture)
- Install Date: $([Management.ManagementDateTimeConverter]::ToDateTime($osInfo.InstallDate).ToString())
- System Language: $((Get-Culture).DisplayName)
- Default Language: $((Get-UICulture).DisplayName)
- Windows Directory: $($env:windir)`n
"@

# Initialize log file
$logEntry | Out-File -FilePath $logFilePath -Append

# Function to write logs
function Write-Log {
    [CmdletBinding()]
    param ([Parameter(ValueFromPipeline=$true)][object]$InputObj, [string]$msg, [switch]$Raw, [string]$Sep = " || ")
    process {
        $content = if ($msg) { $msg } elseif ($null -ne $InputObj) { if ($InputObj -is [string]) { $InputObj } else { $InputObj | Out-String } } else { return }
        if (-not $Raw -and ($content = $content.Trim())) {
            $lines = @($content -split '\n' | Where-Object { $_.Trim() })
            $cut = $lines | Where-Object { $_ -match '^\s*\+\s*(CategoryInfo|FullyQualifiedErrorId)\s*:' } | Select-Object -First 1
            if ($cut) { $lines = $lines[0..($lines.IndexOf($cut) - 1)] }
            if ($lines.Count -gt 1) {
                $processedLines = foreach ($line in $lines) {
                    $trimmed = $line.Trim()
                    if ($trimmed -match '^At\s+(.+)') { "At $($matches[1])" }
                    elseif ($trimmed -match '^\s*\+\s*~+') { continue }  # Skip underline line
                    elseif ($trimmed -match '^\s*\+\s*(.+)') { "+ " + ($matches[1] -replace '\s{2,}', ' ') }
                    elseif ($trimmed -match '^\s*\+?\s*(\w+\w+)\s*:\s*(.+)') { "$($matches[1]): $($matches[2])" }
                    elseif ($trimmed -notmatch '^-{4,}' -and $trimmed) { $trimmed -replace '\s{2,}', ' ' }
                }
                $content = $processedLines -join $Sep
            } else { $content = $content -replace '\s{2,}', ' ' }
        }
        if ($content) { Add-Content -Path "$logFilePath" -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $content" }
    }
}

# Function to write errors to dedicated error log
function Write-ErrorLog {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet("ERROR","WARN","SKIP","INFO")][string]$Level = "ERROR",
        [string]$Source = ""
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $sourceStr = if ($Source) { "[$Source] " } else { "" }
    $line = "$timestamp [$Level] ${sourceStr}$Message"

    # Write to error log file
    Add-Content -Path $errorLogPath -Value $line -ErrorAction SilentlyContinue

    # Track counts
    switch ($Level) {
        "ERROR"  { $script:ErrorCount++; [void]$script:ErrorItems.Add($line) }
        "WARN"   { $script:WarnCount++;  [void]$script:WarnItems.Add($line) }
        "SKIP"   { [void]$script:SkipItems.Add($line) }
    }
}

# Function to write error summary at end of script
function Write-ErrorSummary {
    $summary = @"
================================================================
ERROR LOG SUMMARY
================================================================
Run: $runTimestamp
Errors:   $($script:ErrorCount)
Warnings: $($script:WarnCount)
Skips:    $($script:SkipItems.Count)

"@
    if ($script:ErrorItems.Count -gt 0) {
        $summary += "`n--- ERRORS ($($script:ErrorItems.Count)) ---`n"
        $summary += ($script:ErrorItems -join "`n") + "`n"
    }
    if ($script:WarnItems.Count -gt 0) {
        $summary += "`n--- WARNINGS ($($script:WarnItems.Count)) ---`n"
        $summary += ($script:WarnItems -join "`n") + "`n"
    }
    if ($script:SkipItems.Count -gt 0) {
        $summary += "`n--- SKIPPED ($($script:SkipItems.Count)) ---`n"
        $summary += ($script:SkipItems -join "`n") + "`n"
    }
    $summary += "`n================================================================`nFull error log: $errorLogPath`nScript log: $logFilePath`n================================================================`n"

    Add-Content -Path $errorSummaryPath -Value $summary -ErrorAction SilentlyContinue
    Write-Log -msg "Error summary written to $errorSummaryPath"
    Write-Log -msg "Run stats: $($script:ErrorCount) errors, $($script:WarnCount) warnings, $($script:SkipItems.Count) skips"

    # Also copy to main log for visibility
    Add-Content -Path $logFilePath -Value "`n$summary"
}

# Function to invoke DISM commands if powershell fails
function Invoke-DismFailsafe {
    param([scriptblock]$PS, [scriptblock]$Dism)
    if ($useDISM -ieq "yes") {
        & $Dism 2>&1 | Write-Log
    } else {
        try { & $PS 2>&1 | Write-Log } catch { & $Dism 2>&1 | Write-Log }
    }
}

# Confirmation Function
function Get-Confirmation {
    param([string]$Question, [bool]$DefaultValue = $true, [string]$Description = "")
    $defaultText = if ($DefaultValue) { "Y" } else { "N" }
    $optionsText = if ($DefaultValue) { "Y/n" } else { "y/N" }
    do {
        Write-Host "$Question" -ForegroundColor Cyan -NoNewline
        if ($Description) { Write-Host " - $Description" -ForegroundColor DarkGray -NoNewline }
        Write-Host " ($optionsText): " -ForegroundColor White -NoNewline
        $answer = Read-Host
        if ([string]::IsNullOrWhiteSpace($answer)) {
            Write-Host "Using default: $defaultText" -ForegroundColor Yellow
            return $DefaultValue
        }
        $answer = $answer.ToUpper()
        if ($answer -eq 'Y') { return $true }
        if ($answer -eq 'N') { return $false }
        Write-Warning "Invalid input. Enter 'Y' for Yes, 'N' for No, or Enter for default ($defaultText)."
    } while ($true)
}

# Parameter Value Validation Function
function Get-ParameterValue {
    param( [string]$ParameterValue, [bool]$DefaultValue, [string]$Question, [string]$Description )
    if ($ParameterValue -ne "") { return $ParameterValue -eq "yes" }
    if ($noPrompt) { return $DefaultValue }
    # If neither noPrompt nor param was provided, prompt the user
    return Get-Confirmation -Question $Question -DefaultValue $DefaultValue -Description $Description
}

# Cleanup Function
function Remove-TempFiles {
    # Dismount any leftover WIM mounts first
    $mountDirs = @($installMountDir, "$env:SystemDrive\WIDTemp\mountdir\bootWIM")
    foreach ($md in $mountDirs) {
        if (Test-Path "$md\Windows") {
            try { dism /unmount-image /mountdir:$md /discard 2>&1 | Out-Null } catch {}
        }
    }
    Remove-Item -Path $destinationPath -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path $installMountDir -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$env:SystemDrive\WIDTemp" -Recurse -Force 2>&1 | Write-Log
    Stop-Transcript 2>&1 | Write-Log
    $content = Get-Content $transcript | Where-Object { $_ -notmatch "^(Windows PowerShell transcript|Start time:|Username:|RunAs User:|Configuration|Host Application:|Process ID:|PS[A-Z]|BuildVersion:|CLRVersion:|WSManStackVersion:|SerializationVersion:|Transcript started|PS C:\\|^\*{10,}|End time:)" -and $_.Trim() }
    Add-Content $logFilePath -Value ("`n" + "="*50 + "`nTerminal Snapshot - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" + "`n" + "="*50 + "`n" + ($content -join "`n"))
    Remove-Item $transcript  -Force 2>&1 | Write-Log
}

# Set Ownership Permissions
function Set-Ownership {
    param([string]$Path, [string[]]$Registry)
    if ($Path) {
        try {
            $FullPath = [System.IO.Path]::GetFullPath($Path)
            if (-not (Test-Path -Path $FullPath)) { return $true }
            $IsFolder = (Get-Item $FullPath).PSIsContainer

            # Try ACL method
            try {
                $Acl = Get-Acl $FullPath
                $Acl.SetOwner([System.Security.Principal.NTAccount]"Administrators")
                $CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($CurrentUser, "FullControl", $(if ($IsFolder) {"ContainerInherit,ObjectInherit"} else {"None"}), "None", "Allow")
                $Acl.SetAccessRule($AccessRule)
                Set-Acl -Path $FullPath -AclObject $Acl

                if ($IsFolder) { Get-ChildItem -Path $FullPath -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
                        try { $ChildAcl = Get-Acl $_.FullName
                            $ChildAcl.SetOwner([System.Security.Principal.NTAccount]"Administrators")
                            $ChildAcl.SetAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($CurrentUser, "FullControl", "Allow")))
                            Set-Acl -Path $_.FullName -AclObject $ChildAcl
                        }
                        catch {}
                    }
                }
                Write-Log -msg "[ACL] Set ownership for: $FullPath"
                return $true
            }

            # Fallback to icals
            catch { Write-Log -msg "ACL method failed for: $FullPath"
                try {
                    & icacls.exe "$FullPath" /setowner "Administrators" /T /C 2>&1 | Out-Null
                    & icacls.exe "$FullPath" /grant "${CurrentUser}:(F)" /T /C 2>&1 | Out-Null
                    & icacls.exe "$FullPath" /grant "Administrators:(F)" /T /C 2>&1 | Out-Null
                    Write-Log -msg "[icacls] Set ownership for: $FullPath"
                    return $true
                }
                catch { Write-Log -msg "icacls fallback failed for: $FullPath - $($_.Exception.Message)"; return $false }
            }
        }
        catch { Write-Log -msg "Failed to own path: $Path - $($_.Exception.Message)"; return $false }
    }
    if ($Registry) {
        try {
            $sid = (New-Object System.Security.Principal.NTAccount("BUILTIN\Administrators")).Translate([System.Security.Principal.SecurityIdentifier])
            $rule = New-Object System.Security.AccessControl.RegistryAccessRule("Administrators", "FullControl", "ContainerInherit", "None", "Allow")
            foreach ($keyPath in $Registry) {
                try {
                    $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($keyPath, [Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree, [System.Security.AccessControl.RegistryRights]::TakeOwnership)
                    if ($key) { $acl = $key.GetAccessControl()
                        $acl.SetOwner($sid)
                        $key.SetAccessControl($acl)
                        $key.Close()
                        $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($keyPath, [Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree, [System.Security.AccessControl.RegistryRights]::ChangePermissions)
                        if ($key) { $acl = $key.GetAccessControl()
                            $acl.SetAccessRule($rule)
                            $key.SetAccessControl($acl)
                            $key.Close()
                            Write-Log -msg "Set ownership for registry: $keyPath"
                        }
                    } else { Write-Log -msg "Unable to open reg-key: $keyPath" }
                } catch {}
            }
            return $true
        } catch { Write-Log -msg "Failed to own reg-key: $($_.Exception.Message)"; return $false }
    }
    return $false
}

# Force Remove Function
function Set-OwnAndRemove {
    param([Parameter(Mandatory=$true)][string]$Path)
    try {
        $FullPath = [System.IO.Path]::GetFullPath($Path)
        if (-not (Test-Path -Path $FullPath)) { return $true }
        try {
            $ownershipResult = Set-Ownership -Path $Path
            if (-not $ownershipResult) { throw "ACL method failed" }
            Remove-Item -Path $FullPath -Force -Recurse -ErrorAction Stop
            Write-Log -msg "Removed with ACL: $FullPath"
            return $true
        } catch {
            Write-Log -msg "ACL method failed for: $FullPath"
            try {
                $IsFolder = (Get-Item $FullPath -ErrorAction Stop).PSIsContainer
                $CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                if($IsFolder) { takeown /F "$FullPath" /R /D Y 2>&1 | Write-Log }
                else { takeown /F "$FullPath" /A 2>&1 | Write-Log }
                foreach ($Perm in @("*S-1-5-32-544:F", "System:F", "Administrators:F", "$CurrentUser`:F")) {
                    try {
                        if($IsFolder) { icacls "$FullPath" /grant:R "$Perm" /T /C 2>&1 | Write-Log }
                        else { icacls "$FullPath" /grant:R "$Perm" 2>&1 | Write-Log }
                        if ($LASTEXITCODE -eq 0) { break }
                    } catch { continue }
                }
                Remove-Item -Path $FullPath -Force -Recurse -ErrorAction Stop
                Write-Log -msg "Removed with icacls: $FullPath"
                return $true
            } catch { Write-Log -msg "Failed to remove: $FullPath - $($_.Exception.Message)"; return $false }
        }
    } catch { Write-Log -msg "Error processing path: $Path - $($_.Exception.Message)"; return $false }
}

# ============================================================
# PROGRESS & SKIP HELPERS
# ============================================================
$script:SkipRequested = $false
$script:CurrentPhase = ""

function Watch-SkipKey {
    param([int]$TimeoutSeconds = 0)
    $endTime = if ($TimeoutSeconds -gt 0) { (Get-Date).AddSeconds($TimeoutSeconds) } else { [datetime]::MaxValue }
    $caption = if ($script:CurrentPhase) { "Phase: $($script:CurrentPhase)" } else { "Windows ISO Debloater" }
    while ((Get-Date) -lt $endTime) {
        if ([Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true)
            if ($key.KeyChar -eq 's' -or $key.KeyChar -eq 'S') {
                $script:SkipRequested = $true
                Write-Host "`n[S] Skip requested - finishing current operation..." -ForegroundColor Yellow
                return $true
            }
        }
        Start-Sleep -Milliseconds 200
    }
    return $false
}

function Start-SkipWatcher {
    $script:SkipRequested = $false
    $script:CurrentPhase = $args[0]
    $code = {
        param($phase)
        while ($true) {
            if ([Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.KeyChar -eq 's' -or $key.KeyChar -eq 'S') {
                    Write-Host "`n  [S] Skip requested..." -ForegroundColor Yellow
                    break
                }
            }
            Start-Sleep -Milliseconds 250
        }
    }
    $script:_skipJob = Start-Job -ScriptBlock $code -ArgumentList $script:CurrentPhase
}

function Stop-SkipWatcher {
    if ($script:_skipJob) {
        Stop-Job $script:_skipJob -ErrorAction SilentlyContinue
        Remove-Job $script:_skipJob -Force -ErrorAction SilentlyContinue
        $script:_skipJob = $null
    }
    if ([Console]::KeyAvailable) { [void][Console]::ReadKey($true) }
}

function Should-Skip {
    if ($script:SkipRequested) { return $true }
    if ($script:_skipJob -and $script:_skipJob.State -eq 'Completed') {
        $script:SkipRequested = $true
        Stop-SkipWatcher
        return $true
    }
    return $false
}

function Invoke-WithProgress {
    param(
        [string]$Activity,
        [string]$Status,
        [int]$PercentComplete,
        [scriptblock]$ScriptBlock,
        [string]$SkipKey = $null
    )
    Write-Progress -Activity $Activity -Status $Status -PercentComplete $PercentComplete
    try { & $ScriptBlock }
    catch { Write-Log -msg "$Activity failed: $_"; throw }
}

function Invoke-DismWithTimeout {
    param(
        [string]$Description,
        [scriptblock]$PowerShellCmd,
        [scriptblock]$DismCmd,
        [int]$TimeoutSeconds = 600,
        [bool]$AllowSkip = $true
    )
    $script:CurrentPhase = $Description
    $script:SkipRequested = $false

    if ($AllowSkip) {
        Write-Host "  [S=skip] $Description..." -ForegroundColor DarkGray
        Start-SkipWatcher $Description
    } else {
        Write-Host "  $Description..." -ForegroundColor DarkGray
    }

    $result = $null
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $maxRetries = 2
    $retry = 0

    while ($retry -le $maxRetries) {
        if ($AllowSkip -and (Should-Skip)) {
            Write-Host "  [SKIPPED] $Description" -ForegroundColor Yellow
            Write-Log -msg "SKIPPED: $Description (user requested skip)"
            Write-ErrorLog -Message "$Description - skipped by user" -Level "SKIP" -Source "DISM"
            Stop-SkipWatcher
            return $false
        }
        try {
            # Build command string from scriptblock, expanding variables
            $cmdString = if ($useDISM -ieq "yes") {
                $DismCmd.ToString()
            } else {
                $PowerShellCmd.ToString()
            }
            # Clean up scriptblock wrapper braces
            $cmdString = $cmdString -replace '^\s*\{\s*', '' -replace '\s*\}\s*$', ''
            # Expand PowerShell variables to their current values
            $cmdString = $ExecutionContext.InvokeCommand.ExpandString($cmdString)

            Write-Log -msg "Executing: $cmdString"

            if ($useDISM -ieq "yes") {
                # DISM is a native command, run via cmd
                $proc = Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$cmdString 2>&1`"" -PassThru -NoNewWindow -Wait:$false
            } else {
                # PowerShell cmdlet
                $proc = Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile -Command `"$cmdString 2>&1`"" -PassThru -NoNewWindow -Wait:$false
            }

            $timedOut = $false
            while (-not $proc.HasExited) {
                if ($proc.WaitForExit(500)) { break }
                if ($sw.Elapsed.TotalSeconds -gt $TimeoutSeconds) {
                    $timedOut = $true
                    break
                }
                if ($AllowSkip -and (Should-Skip)) {
                    $proc.Kill()
                    $timedOut = $true
                    Write-Host "  [SKIPPED] $Description by user" -ForegroundColor Yellow
                    Write-Log -msg "SKIPPED (user): $Description"
                    Write-ErrorLog -Message "$Description - user skip during execution" -Level "SKIP" -Source "DISM"
                    Stop-SkipWatcher
                    return $false
                }
            }

            if ($timedOut) {
                if (-not $proc.HasExited) { $proc.Kill() }
                Write-Host "  [TIMEOUT] $Description - took > ${TimeoutSeconds}s" -ForegroundColor Red
                Write-Log -msg "TIMEOUT: $Description (>${TimeoutSeconds}s)"
                Write-ErrorLog -Message "$Description timed out after ${TimeoutSeconds}s" -Level "ERROR" -Source "DISM"
                $retry++
                if ($retry -le $maxRetries) {
                    Write-Host "  Retrying ($retry/$maxRetries)..." -ForegroundColor Yellow
                    Start-Sleep -Seconds 3
                }
            } else {
                if ($proc.ExitCode -ne 0) {
                    Write-Log -msg "DISM exit code $($proc.ExitCode) for '$Description'"
                }
                break
            }
        } catch {
            Write-Log -msg "DISM error for '$Description': $_"
            Write-ErrorLog -Message "DISM error: $Description - $_" -Level "ERROR" -Source "DISM"
            $retry++
            if ($retry -le $maxRetries) {
                Write-Host "  Retrying ($retry/$maxRetries)..." -ForegroundColor Yellow
                Start-Sleep -Seconds 3
            }
        }
    }

    if ($retry -gt $maxRetries) {
        if ($AllowSkip) {
            Write-Host "  [FAILED] $Description (skipping after $maxRetries retries)" -ForegroundColor Red
            Write-Log -msg "FAILED (SKIPPED): $Description"
            Write-ErrorLog -Message "$Description - failed after retries, auto-skipped" -Level "ERROR" -Source "DISM"
            Stop-SkipWatcher
            return $false
        } else {
            Stop-SkipWatcher
            throw "Failed after $maxRetries retries: $Description"
        }
    }

    $sw.Stop()
    Write-Log -msg "Completed: $Description ($([math]::Round($sw.Elapsed.TotalSeconds,1))s)"
    Stop-SkipWatcher
    return $true
}

# Retry wrapper for DISM Get- cmdlets that fail with "file in use"
function Invoke-DismRetryGet {
    param(
        [scriptblock]$ScriptBlock,
        [int]$MaxRetries = 2,
        [int]$DelaySeconds = 1
    )
    for ($a = 0; $a -lt $MaxRetries; $a++) {
        try {
            $result = & $ScriptBlock
            return $result
        } catch {
            if ($_.Exception.Message -match 'being used by another process|access is denied|busy|locked') {
                if ($a -lt $MaxRetries - 1) {
                    Write-Log -msg "DISM busy, retrying ($($a+1)/$MaxRetries)..."
                    Start-Sleep -Seconds $DelaySeconds
                } else {
                    Write-Log -msg "DISM still busy after $MaxRetries retries, skipping"
                    return $null
                }
            } else {
                Write-Log -msg "DISM error: $_"
                return $null
            }
        }
    }
    return $null
}

# Function to check internet connection
function Test-InternetConnection {
    param (
        [int]$maxAttempts = 3,
        [int]$retryDelay = 5,
        [string]$hostname = "1.1.1.1", # Cloudflare DNS
        [int]$port = 53,
        [int]$timeout = 5000
    )
    for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
        try {
            $client = [Net.Sockets.TcpClient]::new()
            if ($client.ConnectAsync($hostname, $port).Wait($timeout)) {
                $client.Close(); return $true
            }
            $client.Close()
        } catch {}
        Write-Host "Internet connection not available, Trying in $retryDelay seconds..."
        Start-Sleep -Seconds $retryDelay
    }
    Write-Host "`nInternet connection not available after $maxAttempts attempts." -ForegroundColor Red
    Write-Host "A working internet connection is required to download oscdimg.exe."
    Write-Host "Check your connection and try again."

    while ($true) {
        $internetChoice = Read-Host -Prompt "`nPress 't' to try again or 'q' to quit"
        switch ($internetChoice.ToLower()) {
            't' { return Test-InternetConnection @PSBoundParameters }
            'q' {
                Remove-TempFiles
                Exit
            }
            default { Write-Host "Invalid input. Enter 't' or 'q'." }
        }
    }
}

# Image Info Function
function Get-WimDetails {
    param ( [Parameter(Mandatory = $true)][string]$MountPath )
    try {
        $out = dism /Image:$MountPath /Get-Intl /English | Out-String
        Write-Log -msg "DISM Output for Get-WimDetails:`n$out"
        $buildMatch = [regex]::Match($out, "Image Version: \d+\.\d+\.(\d+)\.\d+")
        $langMatch = [regex]::Match($out, "(?i)Default\s+system\s+UI\s+language\s*:\s*([a-z]{2}-[A-Z]{2})")
        [PSCustomObject]@{
            BuildNumber = if ($buildMatch.Success) { $buildMatch.Groups[1].Value } else { $null }
            Language = if ($langMatch.Success) { $langMatch.Groups[1].Value } else { $null }
        }
    }
    catch {
        Write-Host "Failed to get WIM info: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# Get Image Index Function
function Get-ImageIndex {
    param ( [Parameter(Mandatory = $true)][string]$ImagePath )
    try {
        $out = & dism.exe /get-wiminfo /wimfile:$ImagePath /english 2>$null
        Write-Log -msg "DISM Output for Get-ImageIndex:`n$out"
        if ($LASTEXITCODE -ne 0) { throw "DISM failed to read image file: $ImagePath" }
        $images = @()
        $indexPattern = "Index\s*:\s*(\d+)"
        $namePattern = "Name\s*:\s*(.+)"
        for ($i = 0; $i -lt $out.Count; $i++) {
            if ($out[$i] -match $indexPattern) {
                $index = $matches[1]
                for ($j = $i + 1; $j -lt [Math]::Min($i + 5, $out.Count); $j++) {
                    if ($out[$j] -match $namePattern) {
                        $name = $matches[1].Trim()
                        $images += [PSCustomObject]@{
                            Index = [int]$index
                            ImageName = $name
                        }
                        break
                    }
                }
            }
        }
        return $images
    }
    catch {
        Write-Log -msg "Failed to get image information: $($_.Exception.Message)"
        return $null
    }
}

# Oscdimg Path
$OscdimgPath = "$env:SystemDrive\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg"
$Oscdimg = Join-Path -Path $OscdimgPath -ChildPath 'oscdimg.exe'

# Autounattend.xml Path
$autounattendXmlPath = Join-Path -Path $scriptDirectory -ChildPath "Autounattend.xml"

# Download Autounattend.xml if not exists
if (-not (Test-Path $autounattendXmlPath)) {
    $ProgressPreference = 'SilentlyContinue'
    try { Invoke-WebRequest "https://itsnileshhere.github.io/Windows-ISO-Debloater/autounattend.xml" -OutFile $autounattendXmlPath -UseBasicParsing }
    catch { Write-Log -msg "Warning: Unable to download Autounattend.xml" }
    finally { $ProgressPreference = 'Continue' }
}

# Mount ISO Dialog
function Select-ISOFile {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.InitialDirectory = [Environment]::GetFolderPath("Desktop")
    $dialog.Filter = "ISO files (*.iso)|*.iso"
    $dialog.Title = "Select Windows ISO File"

    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.FileName
    } else {
        return $null
    }
}

if ($isoPath) {$isoFilePath = $isoPath}     # If ISO path is provided as parameter
else {$isoFilePath = Select-ISOFile}        # Prompt user to select ISO file
if ($null -eq $isoFilePath) {
    Write-Host "No file selected. Exiting Script" -ForegroundColor Red
    Write-Log -msg "No file selected"
    Pause
    Exit
}

Write-Host "`nSelected ISO file: " -NoNewline -ForegroundColor Cyan; Write-Host "$isoFilePath"
Write-Log -msg "ISO Path: $isoFilePath"

# Create backup of original ISO for repair purposes
$isoBackupDir = Join-Path -Path $scriptDirectory -ChildPath 'ISOBackup'
$isoBackupPath = Join-Path -Path $isoBackupDir -ChildPath 'original_backup.iso'
if (-not (Test-Path $isoBackupDir)) { New-Item -ItemType Directory -Path $isoBackupDir -Force | Out-Null }
if (-not (Test-Path $isoBackupPath) -or (Get-Item $isoFilePath).LastWriteTime -ne (Get-Item $isoBackupPath -ErrorAction SilentlyContinue).LastWriteTime) {
    Write-Host "Backing up ISO to $isoBackupDir ..." -ForegroundColor DarkGray
    try {
        Copy-Item -Path $isoFilePath -Destination $isoBackupPath -Force
        Write-Log -msg "ISO backed up to $isoBackupPath"
    } catch {
        Write-Log -msg "Warning: Could not backup ISO: $_"
        $isoBackupPath = $null
    }
} else {
    Write-Log -msg "ISO backup already exists, skipping"
}

# Mounting ISO File
$mountResult = Mount-DiskImage -ImagePath "$isoFilePath" -PassThru
if ($mountResult) {
    $sourceDriveLetter = ($mountResult | Get-Volume).DriveLetter
    if ($sourceDriveLetter) {
        Write-Log -msg "Mounted ISO file to drive: $sourceDriveLetter`:"
    }
}
else {
    Write-Host "Failed to mount the ISO file." -ForegroundColor Red
    Write-Log -msg "Failed to mount the ISO file."
    Pause
    Exit
}

$sourceDrive = "${sourceDriveLetter}:\"                             # Source Drive of ISO
$destinationPath = "$env:SystemDrive\WIDTemp\winlite"               # Destination Path
$installMountDir = "$env:SystemDrive\WIDTemp\mountdir\installWIM"   # Mount Directory

# Copy Files
Write-Host "`nCopying files from " -NoNewline; Write-Host "`"$sourceDrive`"" -ForegroundColor Yellow -NoNewline; Write-Host " to " -NoNewline; Write-Host "`"$destinationPath`"" -ForegroundColor Yellow; Write-Log -msg "Copying files from $sourceDrive to $destinationPath"
try {
    if (-not (Test-Path $destinationPath)) { New-Item -ItemType Directory -Path $destinationPath -Force -EA Stop | Out-Null }
    Write-Log -msg "Starting file copy operation..."

    # Using Robocopy to copy files
    $robocopyOutput = & robocopy.exe $sourceDrive $destinationPath /E /COPY:DAT /R:3 /W:5 /MT:8 /NFL /NDL /NP 2>&1
    $robocopyExitCode = $LASTEXITCODE
    $robocopyOutput | Write-Log
    if ($robocopyExitCode -le 7) {
        Write-Host "Copy completed successfully." -ForegroundColor Green
        Write-Log -msg "Copy completed (Exit: $robocopyExitCode)"
        Write-Log -msg "Removing read-only attributes..."
        Get-ChildItem -Path $destinationPath -Recurse | ForEach-Object { $_.Attributes = $_.Attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly) } | Out-Null
    }
    else { throw "Robocopy failed: $robocopyExitCode" }
} catch { Write-Log -msg "Copy failed: $($_.Exception.Message)"; throw }

try { Dismount-DiskImage -ImagePath $isoFilePath -EA Stop | Out-Null}
catch { Write-Log -msg "Dismount failed: $($_.Exception.Message)" }

# Check files availability
$installWimPath = Join-Path $destinationPath "sources\install.wim"
$installEsdPath = Join-Path $destinationPath "sources\install.esd"

# Clean up any leftover mounts from previous failed runs
Write-Log -msg "Checking for leftover mounts at $installMountDir"
if (Test-Path "$installMountDir\Windows") {
    Write-Host "Leftover mount detected - cleaning up..." -ForegroundColor Yellow
    Write-Log -msg "Leftover mount found at $installMountDir, attempting cleanup"
    try {
        dism /unmount-image /mountdir:$installMountDir /discard 2>&1 | Write-Log
        Write-Log -msg "Leftover mount discarded"
    } catch {
        Write-Log -msg "Could not discard leftover mount: $_"
    }
    try { Remove-Item -Path $installMountDir -Recurse -Force -ErrorAction SilentlyContinue } catch {}
    Start-Sleep -Seconds 2
}
New-Item -ItemType Directory -Path $installMountDir -Force 2>&1 | Write-Log

# Handling install.wim and install.esd
if (-not (Test-Path $installWimPath)) {
    Write-Host "`ninstall.wim not found. Searching for install.esd..."
    if (Test-Path $installEsdPath) {
        Write-Host "`ninstall.esd found at " -NoNewline -ForegroundColor Cyan; Write-Host "$installEsdPath"
        Write-Log -msg "install.esd found. Converting..."
        Write-Host "Details for image: " -NoNewline -ForegroundColor Cyan; Write-Host "$installEsdPath"
        try {
            # Get image info from install.esd
            $esdInfo = Get-ImageIndex -ImagePath $installEsdPath
            if (-not $esdInfo) {
                Write-Host "Error: Could not retrieve image info from WIM file" -ForegroundColor Red
                Remove-TempFiles
                Pause
                Exit
            }
            # Print image details from install.esd
            foreach ($image in $esdInfo) {
                Write-Host "$($image.Index). $($image.ImageName)"
            }
            # If winEdition is specified, find the index; else prompt user
            if ($winEdition) {
                $matchedImage = $esdInfo | Where-Object { $_.ImageName -ieq $winEdition }
                if ($matchedImage) { $sourceIndex = $matchedImage.Index }
                else { $sourceIndex = 1 }
            }
            else { $sourceIndex = Read-Host -Prompt "`nEnter the index to convert and mount" }
            # Check if the index is valid, print selected "ImageIndex - ImageName"
            $selectedImage = $esdInfo | Where-Object { $_.Index -eq [int]$sourceIndex }
            if ($selectedImage) {
                Write-Host "`nMounting image: " -NoNewline -ForegroundColor Cyan; Write-Host "$sourceIndex. $($selectedImage.ImageName)"
                Write-Log -msg "Converting and Mounting image: $sourceIndex. $($selectedImage.ImageName)"
            }

            # Convert ESD to WIM
            Write-Progress -Activity "Converting ESD to WIM" -Status "Export-Image (max compression)..." -PercentComplete 30
            Invoke-DismWithTimeout -Description "ESD -> WIM conversion" -PowerShellCmd {Export-WindowsImage -SourceImagePath $installEsdPath -SourceIndex $sourceIndex -DestinationImagePath $installWimPath -CompressionType Maximum -CheckIntegrity} -DismCmd {dism /Export-Image /SourceImageFile:$installEsdPath /SourceIndex:$sourceIndex /DestinationImageFile:$installWimPath /Compress:max /CheckIntegrity} -TimeoutSeconds 1800 -AllowSkip $false
            # Remove the ESD file after conversion
            Remove-Item $installEsdPath -Force
            # Mount the converted WIM with SourceIndex 1
            Write-Progress -Activity "Mounting Image" -Status "Mounting converted WIM..." -PercentComplete 70
            Invoke-DismFailsafe {Mount-WindowsImage -ImagePath $installWimPath -Index 1 -Path $installMountDir} {dism /mount-image /imagefile:$installWimPath /index:1 /mountdir:$installMountDir}
            Write-Progress -Activity "Mounting Image" -Completed
            $sourceIndex = 1  # After conversion, the new WIM will have only one image
        }
        catch {
            Write-Host "Failed to convert or mount the ESD image: $_" -ForegroundColor Red
            Write-Log -msg "Failed to mount image: $_"
            Write-ErrorLog -Message "ESD conversion/mount failed: $_" -Level "ERROR" -Source "ESD"
            Pause
            Exit
        }
    }
    else {
        Write-Host "Neither install.wim nor install.esd found. Make sure to mount the correct ISO" -ForegroundColor Red
        Write-Log -msg "Neither install.wim nor install.esd found"
        Pause
        Exit
    }
}
else {
    Write-Host "`nDetails for image: " -NoNewline -ForegroundColor Cyan; Write-Host "$installWimPath"
    Write-Log -msg "Getting image info"
    try {
        # Get image info from install.wim
        $wimInfo = Get-ImageIndex -ImagePath $installWimPath
        if (-not $wimInfo) {
            Write-Host "Error: Could not retrieve image info from WIM file" -ForegroundColor Red
            Remove-TempFiles
            Pause
            Exit
        }
        # Print image details from install.wim
        foreach ($image in $wimInfo) {
            Write-Host "$($image.Index). $($image.ImageName)"
        }
        # If winEdition is specified, find the index; else prompt user
        if ($winEdition) {
            $matchedImage = $wimInfo | Where-Object { $_.ImageName -ieq $winEdition }
            if ($matchedImage) { $sourceIndex = $matchedImage.Index }
            else { $sourceIndex = 1 }
        }
        else { $sourceIndex = Read-Host -Prompt "`nEnter the index to mount" }
        # Check if the index is valid, print selected "ImageIndex - ImageName"
        $selectedImage = $wimInfo | Where-Object { $_.Index -eq [int]$sourceIndex }
        if ($selectedImage) {
            Write-Host "`nMounting image: " -NoNewline -ForegroundColor Cyan; Write-Host "$sourceIndex. $($selectedImage.ImageName)"
            Write-Log -msg "Mounting image: $sourceIndex. $($selectedImage.ImageName)"
        }

        Write-Progress -Activity "Mounting Image" -Status "Mounting install.wim index $sourceIndex..." -PercentComplete 50
        Invoke-DismFailsafe {Mount-WindowsImage -ImagePath $installWimPath -Index $sourceIndex -Path $installMountDir} {dism /mount-image /imagefile:$installWimPath /index:$sourceIndex /mountdir:$installMountDir}
        Write-Progress -Activity "Mounting Image" -Completed
    }
    catch {
        Write-Host "Failed to mount the image: $_" -ForegroundColor Red
        Write-Log -msg "Failed to mount image: $_"
        Write-ErrorLog -Message "Failed to mount WIM image: $_" -Level "ERROR" -Source "Mount"
        Pause
        Exit
    }
}

# Check if wim-mount was successful
if (-not (Test-Path "$installMountDir\Windows")) {
    Write-Host "Error while mounting image. Try again." -ForegroundColor Red
    Write-Log -msg "Mounted image not found. Exiting"
    Remove-TempFiles
    Pause
    Exit
}

# Resolve Image Info
$WimDetails = Get-WimDetails -MountPath $installMountDir
if (-not $WimDetails -or -not $WimDetails.BuildNumber -or -not $WimDetails.Language) {
    Write-Host "Error: Could not retrieve WIM information from mounted path" -ForegroundColor Red
    Remove-TempFiles
    Pause
    Exit
}
$langCode = $WimDetails.Language; Write-Log -msg "Detected Language: $langCode"
$buildNumber = $WimDetails.BuildNumber; Write-Log -msg "Detected Build Number: $buildNumber"

Write-Host
if ($SafeMode) {
    Write-Host "[SAFE MODE] BakuretsuClean-style debloat - AppX removal only. Safe for any ISO edition." -ForegroundColor Green
    $DoAppxRemove = $true
    $DoCapabilitiesRemove = $false
    $DoOnedriveRemove = $false
    $DoEDGERemove = $false
    $DoAIRemove = $false
    $DoTPMBypass = $false
    $DoUserFoldersEnable = $true
    $DoDriverIntegrate = $false
    $DoESDConvert = $false
    $DoUseOscdimg = $true
    $DoDefenderRemove = $false
    $DoWidgetsRemove = $false
    $DoWinUpdateDisable = $false
    $DoHyperVRemove = $false
    $DoExtremeDebloat = $false
    $DoServicesDisable = $false
    $DoPerformanceTweaks = $false
    $DoTaskCleanup = $false
    $DoWinSxSCleanup = $false
} else {
$DoAppxRemove = Get-ParameterValue -ParameterValue $AppxRemove -DefaultValue $true -Question "Remove unnecessary packages?" -Description "Recommended: Removes bloatware apps"
$DoCapabilitiesRemove = Get-ParameterValue -ParameterValue $CapabilitiesRemove -DefaultValue $true -Question "Remove unnecessary features?" -Description "Recommended: Removes optional Windows features"
$DoOnedriveRemove = Get-ParameterValue -ParameterValue $OnedriveRemove -DefaultValue $true -Question "Remove OneDrive?" -Description "Optional: Completely removes OneDrive"
$DoEDGERemove = Get-ParameterValue -ParameterValue $EDGERemove -DefaultValue $true -Question "Remove Microsoft Edge?" -Description "Optional: Removes Edge components (Breaks Widgets)"
$DoAIRemove = Get-ParameterValue -ParameterValue $AIRemove -DefaultValue $true -Question "Remove AI Components?" -Description "Optional: Removes everything related to AI"
$DoTPMBypass = Get-ParameterValue -ParameterValue $TPMBypass -DefaultValue $false -Question "Bypass TPM check?" -Description "Only if needed for older hardware"
$DoUserFoldersEnable = Get-ParameterValue -ParameterValue $UserFoldersEnable -DefaultValue $true -Question "Enable user folders?" -Description "Recommended: Enables Desktop, Documents, etc."
$DoDriverIntegrate = Get-ParameterValue -ParameterValue $DriverIntegrate -DefaultValue $false -Question "Integrate Intel RST/VMD drivers?" -Description "Optional: Helps with Intel VMD storage controllers"
$DoESDConvert = Get-ParameterValue -ParameterValue $ESDConvert -DefaultValue $false -Question "Compress the ISO?" -Description "Recommended but slow: Reduces ISO file size"
$DoUseOscdimg = Get-ParameterValue -ParameterValue $useOscdimg -DefaultValue $true -Question "Use Oscdimg for ISO creation?" -Description "Recommended: Oscdimg is more reliable"
$DoDefenderRemove = Get-ParameterValue -ParameterValue $DefenderRemove -DefaultValue $false -Question "Remove Windows Defender/Security?" -Description "EXPERIMENTAL: Disables Defender via registry only (safe). Does NOT delete files."
$DoWidgetsRemove = Get-ParameterValue -ParameterValue $WidgetsRemove -DefaultValue $true -Question "Remove Widgets completely?" -Description "Recommended: Disables & removes Widget components"
$DoWinUpdateDisable = Get-ParameterValue -ParameterValue $WinUpdateDisable -DefaultValue $false -Question "Disable Windows Update?" -Description "Extreme: Prevents automatic updates (can re-enable post-install)"
$DoHyperVRemove = Get-ParameterValue -ParameterValue $HyperVRemove -DefaultValue $false -Question "Remove Hyper-V components?" -Description "Optional: Removes virtualization platform"
$DoExtremeDebloat = Get-ParameterValue -ParameterValue $ExtremeDebloat -DefaultValue $false -Question "Enable Extreme Debloat mode?" -Description "Extreme: Removes more components, disables more services"
$DoServicesDisable = Get-ParameterValue -ParameterValue $ServicesDisable -DefaultValue $true -Question "Disable unnecessary services?" -Description "Recommended: Disables 40+ telemetry/bloat services"
$DoPerformanceTweaks = Get-ParameterValue -ParameterValue $PerformanceTweaks -DefaultValue $true -Question "Apply performance tweaks?" -Description "Recommended: CPU, memory, network optimizations"
$DoTaskCleanup = Get-ParameterValue -ParameterValue $TaskCleanup -DefaultValue $false -Question "Cleanup scheduled tasks?" -Description "CAUTION: Can cause boot hangs. Disables 45+ telemetry tasks"
$DoWinSxSCleanup = Get-ParameterValue -ParameterValue $WinSxSCleanup -DefaultValue $false -Question "Cleanup WinSxS bloat components?" -Description "CAUTION: Conservative removal of bloat WinSxS dirs. May slow first boot"
}

# Comment out the package don't wanna remove
$appxPatternsToRemove = @(
    # --- Original packages ---
    "Microsoft.Microsoft3DViewer*",
    "Microsoft.WindowsAlarms*",
    "Microsoft.BingNews*",
    "Microsoft.BingSearch*",
    "Microsoft.BingWeather*",
    "Windows.CBSPreview*",
    "Clipchamp.Clipchamp*",
    "Microsoft.549981C3F5F10*",
    "MicrosoftWindows.CrossDevice*",
    "Microsoft.Windows.DevHome*",
    "MicrosoftCorporationII.MicrosoftFamily*",
    "Microsoft.WindowsFeedbackHub*",
    "Microsoft.GetHelp*",
    "Microsoft.Getstarted*",
    "Microsoft.WindowsCommunicationsapps*",
    "Microsoft.WindowsMaps*",
    "Microsoft.MixedReality.Portal*",
    "Microsoft.ZuneMusic*",
    "Microsoft.MicrosoftOfficeHub*",
    "Microsoft.Office.OneNote*",
    "Microsoft.OutlookForWindows*",
    "Microsoft.MSPaint*",
    "Microsoft.People*",
    "Microsoft.Windows.PeopleExperienceHost*",
    "Microsoft.YourPhone*",
    "Microsoft.PowerAutomateDesktop*",
    "MicrosoftCorporationII.QuickAssist*",
    "Microsoft.SkypeApp*",
    "Microsoft.MicrosoftStickyNotes*",
    "Microsoft.MicrosoftSolitaireCollection*",
    "MicrosoftTeams*",
    "MSTeams*",
    "Microsoft.Windows.Teams*",
    "Microsoft.Todos*",
    "Microsoft.ZuneVideo*",
    "Microsoft.Wallet*",
    "Microsoft.GamingApp*",
    "Microsoft.XboxApp*",
    "Microsoft.XboxGameOverlay*",
    "Microsoft.XboxGamingOverlay*",
    "Microsoft.XboxSpeechToTextOverlay*",
    "Microsoft.Xbox.TCUI*",
    # --- Additional AppX bloat ---
    "Microsoft.BingTranslator*",
    "Microsoft.DesktopAppInstaller*",
    "Microsoft.StorePurchaseApp*",
    "Microsoft.WebMediaExtensions*",
    "Microsoft.WebpImageExtension*",
    "Microsoft.Windows.Photos*",
    "Microsoft.WindowsCamera*",
    "Microsoft.ScreenSketch*",
    "Microsoft.HEIFImageExtension*",
    "Microsoft.VP9VideoExtensions*",
    "Microsoft.MPEG2VideoExtension*",
    "Microsoft.RawImageExtension*",
    "Microsoft.WebExperience*",
    "Microsoft.Windows.Search*",
    "Microsoft.Windows.AssignedAccessLockApp*",
    "Microsoft.Windows.Calling*",
    "Microsoft.Windows.CapturePicker*",
    "Microsoft.Windows.NarratorQuickStart*",
    "Microsoft.Windows.ParentalControls*",
    "Microsoft.Windows.Print3D*",
    "Microsoft.Windows.SecureAssessmentBrowser*",
    "Microsoft.Windows.XGpuEjectDialog*",
    "Microsoft.Advertising.Xaml*",
    "Microsoft.Services.Store.Engagement*",
    "Microsoft.MicrosoftJournal*",
    "Microsoft.Windows.OOBENetworkCaptivePortal*",
    "Microsoft.Windows.OOBENetworkConnectionFlow*",
    "Microsoft.Windows.SetupFlow*",
    "Microsoft.Windows.CloudExperienceHost*",
    "Microsoft.PPIProjection*",
    "Microsoft.MicrosoftEdge.Stable*",
    "Microsoft.MicrosoftEdgeDevToolsClient*",
    "Microsoft.Win32WebViewHost*",
    "Microsoft.Windows.Apprep.ChxApp*",
    "Microsoft.ECApp*",
    "Microsoft.AV1VideoExtension*",
    "Microsoft.AVCEncoderVideoExtension*",
    "Microsoft.HEVCVideoExtension*",
    "Microsoft.DolbyAudioExtensions*"
)

$capabilitiesToRemove = @(
    "Browser.InternetExplorer*",
    "Internet-Explorer*",
    "App.StepsRecorder*",
    "App.Support.QuickAssist*",
    "Language.Handwriting~~~$langCode*",
    "Language.OCR~~~$langCode*",
    "Language.Speech~~~$langCode*",
    "Language.TextToSpeech~~~$langCode*",
    "Microsoft.Windows.WordPad*",
    "MathRecognizer*",
    "Microsoft.Windows.PowerShell.ISE*",
    "Media.WindowsMediaPlayer*",
    "App.WirelessDisplay.Connect*",
    "Hello.Face*",
    "OneCoreUAP.OneSync*",
    "OpenSSH.Client*",
    "Language.Handwriting*",
    "Language.OCR*",
    "Language.Speech*",
    "Language.TextToSpeech*",
    "Print.Fax.Scan*",
    "Print.Management.Console*",
    "Microsoft.Windows.Notepad.System*",
    "Xps.Viewer*",
    "App.Print3D*",
    "Media.WindowsMediaPlayer*"
)

$windowsPackagesToRemove = @(
    "Microsoft-Windows-InternetExplorer-Optional-Package*",
    "Microsoft-Windows-LanguageFeatures-Handwriting-$langCode-Package*",
    "Microsoft-Windows-LanguageFeatures-OCR-$langCode-Package*",
    "Microsoft-Windows-LanguageFeatures-Speech-$langCode-Package*",
    "Microsoft-Windows-LanguageFeatures-TextToSpeech-$langCode-Package*",
    "Microsoft-Windows-Wallpaper-Content-Extended-FoD-Package*",
    "Microsoft-Windows-WordPad-FoD-Package*",
    "Microsoft-Windows-MediaPlayer-Package*",
    "Microsoft-Windows-TabletPCMath-Package*",
    "Microsoft-Windows-StepsRecorder-Package*",
    "Microsoft-Windows-QuickAssist-Package*",
    "Microsoft-Windows-PowerShell-ISE-FOD-Package*",
    "Microsoft-Windows-Printing-PMCPPC-FoD-Package*",
    "Microsoft-Windows-Printing-WFS-FoD-Package*",
    # "Microsoft-Windows-Notepad-FoD-Package*",     # Win10 only, harmless if missing
    # "Microsoft-Windows-MSPaint-FoD-Package*",      # Win10 only, harmless if missing
    "Microsoft-Windows-Hello-Face-Package*",
    "Microsoft-Windows-Xps-Xps-Viewer-Package*",
    "Microsoft-Windows-Print-Fax-Scan-Feature-Package*",
    "Microsoft-Windows-VBSCRIPT*",
    "Microsoft-Windows-Legacy-Components-OC-WOW64-Package*",
    "OpenSSH-Client-Package*",
    "Microsoft-Windows-SimpleTCP-Package*",
    "Microsoft-Windows-SMB1Deprecation-Package*",
    "Microsoft-Windows-DirectoryServices-ADAM-Client-Package*"
)

function Remove-Packages {
    param( [string[]]$Patterns, [string]$SectionTitle, [string]$PackageType, [string]$MountPath, [int]$StartIndex = 1, [int]$TotalCount, [int]$StatusColumn )

    # Package configurations
    $config = @{
        'AppX' = @{
            GetCommand = { Get-ProvisionedAppxPackage -Path $MountPath }
            FilterProperty = 'PackageName'
            RemoveCommand = { param($item) Remove-ProvisionedAppxPackage -Path $MountPath -PackageName $item.PackageName }
            LogPrefix = 'AppX package'
        }
        'Capability' = @{
            GetCommand = { Get-WindowsCapability -Path $MountPath }
            FilterProperty = 'Name'
            RemoveCommand = { param($item) Remove-WindowsCapability -Path $MountPath -Name $item.Name }
            LogPrefix = 'capability'
        }
        'WindowsPackage' = @{
            GetCommand = { Get-WindowsPackage -Path $MountPath }
            FilterProperty = 'PackageName'
            RemoveCommand = { param($item) Remove-WindowsPackage -Path $MountPath -PackageName $item.PackageName }
            LogPrefix = 'Windows package'
        }
    }
    if ($SectionTitle) {
        Write-Host "`n$SectionTitle" -ForegroundColor Cyan
        Write-Log -msg $SectionTitle
        Write-Host "  Press [S] at any time to skip remaining items in this section" -ForegroundColor DarkGray
    }

    # Validate Package Type
    $cfg = $config[$PackageType]
    $filterProp = $cfg.FilterProperty

    Start-SkipWatcher "$SectionTitle package removal"
    $script:SkipRequested = $false
    $totalProcessed = 0

    for ($i = 0; $i -lt $Patterns.Count; $i++) {
        if ((Should-Skip)) {
            Write-Host "  [SKIPPED] Remaining $($Patterns.Count - $i) $PackageType items" -ForegroundColor Yellow
            Write-Log -msg "SKIPPED: $($Patterns.Count - $i) $PackageType items (user requested)"
            Write-ErrorLog -Message "$PackageType removal: $($Patterns.Count - $i) items skipped by user" -Level "SKIP" -Source $PackageType
            break
        }
        $pattern = $Patterns[$i]
        $displayName = $pattern.TrimEnd('*')
        $counter = "[{0}/{1}]" -f ($StartIndex + $i), $TotalCount
        $initialOutput = "  $counter $displayName"
        $percent = [math]::Floor(($i / $Patterns.Count) * 100)

        # Progress bar
        Write-Progress -Activity "Removing $PackageType" -Status "$displayName ($($i+1)/$($Patterns.Count))" -PercentComplete $percent

        Write-Host $initialOutput -NoNewline
        try {
            $items = & $cfg.GetCommand | Where-Object { $_.$filterProp -like $pattern }
            $itemsRemoved = 0
            foreach ($item in $items) {
                if ((Should-Skip)) { break }
                try {
                    & $cfg.RemoveCommand $item 2>&1 | Write-Log
                    $itemsRemoved++
                }
                catch {
                    $itemName = $item.$filterProp
                    Write-Log -msg "Removing $($cfg.LogPrefix) $itemName failed: $_"
                    Write-ErrorLog -Message "Removing $($cfg.LogPrefix) $itemName failed: $_" -Level "WARN" -Source $PackageType
                }
            }

            # Show status
            $padding = $StatusColumn - $initialOutput.Length
            $spaces = ' ' * $padding
            if ($itemsRemoved -gt 0) { Write-Host "$spaces[REMOVED]" -ForegroundColor Green }
            else { Write-Host "$spaces[NOT FOUND]" -ForegroundColor Yellow }
        }
        catch {
            Write-Log -msg "Failed to remove $PackageType matching '$pattern': $_"
            Write-ErrorLog -Message "Failed to process $PackageType '$pattern': $_" -Level "ERROR" -Source "Remove-$PackageType"
            $padding = $StatusColumn - $initialOutput.Length
            Write-Host "$(' ' * $padding)[ERROR]" -ForegroundColor Red
        }
        $totalProcessed++
    }
    Write-Progress -Activity "Removing $PackageType" -Completed
    Stop-SkipWatcher
}

$allPatterns = $appxPatternsToRemove + $capabilitiesToRemove + $windowsPackagesToRemove
$maxLength = ($allPatterns | ForEach-Object { $_.TrimEnd('*').Length } | Measure-Object -Maximum).Maximum
$statusColumn = $maxLength + 18

# Remove AppX Packages
if ($DoAppxRemove) {
    Remove-Packages -Patterns $appxPatternsToRemove -SectionTitle "Removing provisioned Packages:" -PackageType "AppX" -MountPath $installMountDir -TotalCount $appxPatternsToRemove.Count -StatusColumn $statusColumn
} else {
    Write-Log -msg "Skipped Package Removal"
}

# Remove Capabilities and Windows Packages
if ($DoCapabilitiesRemove) {
    $capabilitiesAndPackagesTotal = $capabilitiesToRemove.Count + $windowsPackagesToRemove.Count
    Remove-Packages -Patterns $capabilitiesToRemove -SectionTitle "Removing Unnecessary Windows Features:" -PackageType "Capability" -MountPath $installMountDir -TotalCount $capabilitiesAndPackagesTotal -StatusColumn $statusColumn
    Remove-Packages -Patterns $windowsPackagesToRemove -SectionTitle "" -PackageType "WindowsPackage" -MountPath $installMountDir -StartIndex ($capabilitiesToRemove.Count + 1) -TotalCount $capabilitiesAndPackagesTotal -StatusColumn $statusColumn
} else {
    Write-Log -msg "Skipped Features Removal"
}

# # Remove Recall (Have conflict with Explorer)
# Write-Host "`nRemoving Recall..."
# Write-Log -msg "Removing Recall"
# dism /image:$installMountDir /Disable-Feature /FeatureName:'Recall' /Remove 2>&1 | Write-Log
# Write-Host "Done"

# # Remove OutlookPWA
# Write-Host "`nRemoving Outlook..." -ForegroundColor Cyan
# Write-Log -msg "Removing OutlookPWA"
# Get-ChildItem "$installMountDir\Windows\WinSxS\amd64_microsoft-windows-outlookpwa*" -Directory | ForEach-Object { Set-OwnAndRemove -Path $_.FullName } 2>&1 | Write-Log
# Write-Host "Done" -ForegroundColor Green

# Setting Permissions
function Enable-Privilege {
    param([ValidateSet('SeAssignPrimaryTokenPrivilege', 'SeAuditPrivilege', 'SeBackupPrivilege', 'SeChangeNotifyPrivilege', 'SeCreateGlobalPrivilege', 'SeCreatePagefilePrivilege', 'SeCreatePermanentPrivilege', 'SeCreateSymbolicLinkPrivilege', 'SeCreateTokenPrivilege', 'SeDebugPrivilege', 'SeEnableDelegationPrivilege', 'SeImpersonatePrivilege', 'SeIncreaseBasePriorityPrivilege', 'SeIncreaseQuotaPrivilege', 'SeIncreaseWorkingSetPrivilege', 'SeLoadDriverPrivilege', 'SeLockMemoryPrivilege', 'SeMachineAccountPrivilege', 'SeManageVolumePrivilege', 'SeProfileSingleProcessPrivilege', 'SeRelabelPrivilege', 'SeRemoteShutdownPrivilege', 'SeRestorePrivilege', 'SeSecurityPrivilege', 'SeShutdownPrivilege', 'SeSyncAgentPrivilege', 'SeSystemEnvironmentPrivilege', 'SeSystemProfilePrivilege', 'SeSystemtimePrivilege', 'SeTakeOwnershipPrivilege', 'SeTcbPrivilege', 'SeTimeZonePrivilege', 'SeTrustedCredManAccessPrivilege', 'SeUndockPrivilege', 'SeUnsolicitedInputPrivilege')]$Privilege, $ProcessId = $pid, [Switch]$Disable)
    $def = @'
    using System;using System.Runtime.InteropServices;public class AdjPriv{[DllImport("advapi32.dll",ExactSpelling=true,SetLastError=true)]internal static extern bool AdjustTokenPrivileges(IntPtr htok,bool disall,ref TokPriv1Luid newst,int len,IntPtr prev,IntPtr relen);[DllImport("advapi32.dll",ExactSpelling=true,SetLastError=true)]internal static extern bool OpenProcessToken(IntPtr h,int acc,ref IntPtr phtok);[DllImport("advapi32.dll",SetLastError=true)]internal static extern bool LookupPrivilegeValue(string host,string name,ref long pluid);[StructLayout(LayoutKind.Sequential,Pack=1)]internal struct TokPriv1Luid{public int Count;public long Luid;public int Attr;}public static bool EnablePrivilege(long processHandle,string privilege,bool disable){var tp=new TokPriv1Luid();tp.Count=1;tp.Attr=disable?0:2;IntPtr htok=IntPtr.Zero;if(!OpenProcessToken(new IntPtr(processHandle),0x28,ref htok))return false;if(!LookupPrivilegeValue(null,privilege,ref tp.Luid))return false;return AdjustTokenPrivileges(htok,false,ref tp,0,IntPtr.Zero,IntPtr.Zero);}}
'@
    (Add-Type $def -PassThru -EA SilentlyContinue)[0]::EnablePrivilege((Get-Process -id $ProcessId).Handle, $Privilege, $Disable)
}
Enable-Privilege SeTakeOwnershipPrivilege | Out-Null

# Remove OneDrive
if ($DoOnedriveRemove) {
    Write-Host ("`n[INFO] Removing OneDrive...") -ForegroundColor Cyan
    Write-Log -msg "Defining OneDrive Setup file paths"
    # $oneDriveSetupPath1 = Join-Path -Path $installMountDir -ChildPath 'Windows\System32\OneDriveSetup.exe'
    $oneDriveSetupPath2 = Join-Path -Path $installMountDir -ChildPath 'Windows\SysWOW64\OneDriveSetup.exe'
    # $oneDriveSetupPath3 = (Join-Path -Path $installMountDir -ChildPath 'Windows\WinSxS\*microsoft-windows-onedrive-setup*\OneDriveSetup.exe' | Get-Item -ErrorAction SilentlyContinue).FullName
    # $oneDriveSetupPath4 = (Get-ChildItem "$installMountDir\Windows\WinSxS\amd64_microsoft-windows-onedrive-setup*" -Directory).FullName
    $oneDriveShortcut = Join-Path -Path $installMountDir -ChildPath 'Users\Default\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk'

    Write-Log -msg "Removing OneDrive"
    Set-OwnAndRemove -Path $oneDriveSetupPath2 | Out-Null
    Set-OwnAndRemove -Path $oneDriveShortcut | Out-Null
    # Enhanced: Remove OneDrive WinSxS components
    Get-ChildItem "$installMountDir\Windows\WinSxS\*onedrive*" -Directory -ErrorAction SilentlyContinue | ForEach-Object { Set-OwnAndRemove -Path $_.FullName } 2>&1 | Write-Log
    Get-ChildItem "$installMountDir\Windows\WinSxS\*skydrive*" -Directory -ErrorAction SilentlyContinue | ForEach-Object { Set-OwnAndRemove -Path $_.FullName } 2>&1 | Write-Log
    # Remove OneDrive from System32/SysWOW64
    Set-OwnAndRemove -Path "$installMountDir\Windows\System32\OneDriveSetup.exe" | Out-Null
    Set-OwnAndRemove -Path "$installMountDir\Windows\System32\OneDrive.ico" | Out-Null
    # Remove OneDrive appdata folder
    Set-OwnAndRemove -Path "$installMountDir\Users\Default\OneDrive" | Out-Null
    Set-OwnAndRemove -Path "$installMountDir\Users\Default\AppData\Local\Microsoft\OneDrive" | Out-Null

    Write-Host ("[OK] OneDrive Removed") -ForegroundColor Green
    Write-Log -msg "OneDrive removed successfully"
} else {
    Write-Log -msg "OneDrive removal skipped"
}

# Remove EDGE
if ($DoEDGERemove) {
    Write-Host ("`n[INFO] Removing EDGE...") -ForegroundColor Cyan
    Write-Log -msg "Removing EDGE"

    # Remove Edge using DISM
    Write-Host "  - Executing DISM - Remove-Edge..." -ForegroundColor DarkGray
    Write-Log -msg "Executing DISM - Remove-Edge"
    dism /image:"$installMountDir" /Remove-Edge 2>&1 | Write-Log

    # Edge Patterns
    $EDGEpatterns = @(
        "Microsoft.MicrosoftEdge.Stable*",
        "Microsoft.MicrosoftEdgeDevToolsClient*",
        "Microsoft.Win32WebViewHost*",
        "MicrosoftWindows.Client.WebExperience*"        # Removing Breaks Widgets
    )

    # Remove Edge Packages
    foreach ($pattern in $EDGEpatterns) {
        $matchedPackages = Invoke-DismRetryGet { Get-ProvisionedAppxPackage -Path $installMountDir | Where-Object { $_.PackageName -like $pattern } }
        if ($matchedPackages) {
            foreach ($package in $matchedPackages) {
                Invoke-DismFailsafe {Remove-ProvisionedAppxPackage -Path $installMountDir -PackageName $package.PackageName} {dism /image:$installMountDir /Remove-ProvisionedAppxPackage /PackageName:$($package.PackageName)}
            }
        }
    }

    # Remove WebView2 if not already removed
    Get-WindowsCapability -Path $installMountDir | Where-Object { $_.Name -like "Edge.Webview2.Platform*" } |
        ForEach-Object { Invoke-DismFailsafe {Remove-WindowsCapability -Path $installMountDir -Name $_.Name} {dism /image:$installMountDir /Remove-Capability /CapabilityName:$($_.Name)} }

    Get-WindowsPackage -Path $installMountDir | Where-Object { $_.PackageName -like "Microsoft-Edge-WebView-FOD-Package*" } |
        ForEach-Object { Invoke-DismFailsafe {Remove-WindowsPackage -Path $installMountDir -PackageName $_.PackageName} {dism /image:$installMountDir /Remove-Package /PackageName:$($_.PackageName)} }

    # Modifying reg keys
    Write-Host "  - Tweaking registry..." -ForegroundColor DarkGray
    Write-Log -msg "Registry tweaks for EDGE"
    try {
        reg load HKLM\zSOFTWARE "$installMountDir\Windows\System32\config\SOFTWARE" 2>&1 | Write-Log
        reg load HKLM\zSYSTEM "$installMountDir\Windows\System32\config\SYSTEM" 2>&1 | Write-Log
        reg load HKLM\zNTUSER "$installMountDir\Users\Default\ntuser.dat" 2>&1 | Write-Log
        reg load HKLM\zDEFAULT "$installMountDir\Windows\System32\config\default" 2>&1 | Write-Log

        # Registry operations
        reg delete "HKLM\zSOFTWARE\Microsoft\EdgeUpdate" /f 2>&1 | Write-Log
        reg delete "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Edge" /f 2>&1 | Write-Log
        reg delete "HKLM\zDEFAULT\Software\Microsoft\EdgeUpdate" /f 2>&1 | Write-Log
        reg delete "HKLM\zNTUSER\Software\Microsoft\EdgeUpdate" /f 2>&1 | Write-Log
        reg delete "HKLM\zSOFTWARE\Microsoft\Active Setup\Installed Components\{9459C573-B17A-45AE-9F64-1857B5D58CEE}" /f 2>&1 | Write-Log
        reg delete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\Edge" /f 2>&1 | Write-Log
        reg delete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\EdgeUpdate" /f 2>&1 | Write-Log
        reg delete "HKLM\zSYSTEM\CurrentControlSet\Services\edgeupdate" /f 2>&1 | Write-Log
        reg delete "HKLM\zSYSTEM\ControlSet001\Services\edgeupdate" /f 2>&1 | Write-Log
        reg delete "HKLM\zSYSTEM\CurrentControlSet\Services\edgeupdatem" /f 2>&1 | Write-Log
        reg delete "HKLM\zSYSTEM\ControlSet001\Services\edgeupdatem" /f 2>&1 | Write-Log
        reg delete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Edge" /f 2>&1 | Write-Log
        reg delete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Edge Update" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\MicrosoftEdge\Main" /v "AllowPrelaunch" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" /v "AllowPrelaunch" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zNTUSER\Software\Microsoft\MicrosoftEdge\Main" /v "AllowPrelaunch" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zNTUSER\Software\Policies\Microsoft\MicrosoftEdge\Main" /v "AllowPrelaunch" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\MicrosoftEdge\TabPreloader" /v "AllowTabPreloading" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Policies\Microsoft\MicrosoftEdge\TabPreloader" /v "AllowTabPreloading" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zNTUSER\Software\Microsoft\MicrosoftEdge\TabPreloader" /v "AllowTabPreloading" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zNTUSER\Software\Policies\Microsoft\MicrosoftEdge\TabPreloader" /v "AllowTabPreloading" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Policies\Microsoft\EdgeUpdate" /v "UpdateDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log

        # Disable Edge updates and installation
        $registryKeys = @(
            "HKLM\zSOFTWARE\Microsoft\EdgeUpdate",
            "HKLM\zSOFTWARE\Policies\Microsoft\EdgeUpdate",
            "HKLM\zSOFTWARE\WOW6432Node\Microsoft\EdgeUpdate",
            "HKLM\zNTUSER\Software\Microsoft\EdgeUpdate",
            "HKLM\zNTUSER\Software\Policies\Microsoft\EdgeUpdate"
        )
        foreach ($key in $registryKeys) {
            reg add "$key" /v "DoNotUpdateToEdgeWithChromium" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "$key" /v "UpdaterExperimentationAndConfigurationServiceControl" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "$key" /v "InstallDefault" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        }
    }
    catch {
        Write-Log -msg "Error modifying registry: $_"
    }
    finally {
        # Always unload registry hives regardless of errors
        reg unload HKLM\zSOFTWARE 2>&1 | Write-Log
        reg unload HKLM\zSYSTEM 2>&1 | Write-Log
        reg unload HKLM\zNTUSER 2>&1 | Write-Log
        reg unload HKLM\zDEFAULT 2>&1 | Write-Log
    }

    # Remove EDGE files
    Write-Host "  - Cleaning up shortcuts..." -ForegroundColor DarkGray
    Write-Log -msg "Removing EDGE related files"
    Remove-Item -Path "$installMountDir\Program Files\Microsoft\Edge" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files\Microsoft\EdgeCore" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files\Microsoft\EdgeUpdate" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files\Microsoft\EdgeWebView" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files (x86)\Microsoft\Edge" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files (x86)\Microsoft\EdgeCore" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files (x86)\Microsoft\EdgeUpdate" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\Program Files (x86)\Microsoft\EdgeWebView" -Recurse -Force 2>&1 | Write-Log
    Remove-Item -Path "$installMountDir\ProgramData\Microsoft\EdgeUpdate" -Recurse -Force 2>&1 | Write-Log
    Get-ChildItem "$installMountDir\ProgramData\Microsoft\Windows\AppRepository\Packages\Microsoft.MicrosoftEdge.Stable*" -Directory | ForEach-Object { Set-OwnAndRemove -Path $_.FullName } 2>&1 | Write-Log
    Get-ChildItem "$installMountDir\ProgramData\Microsoft\Windows\AppRepository\Packages\Microsoft.MicrosoftEdgeDevToolsClient*" -Directory | ForEach-Object { Set-OwnAndRemove -Path $_.FullName } 2>&1 | Write-Log
    # Edge WinSxS cleanup is handled by the main conservative WinSxS pass
    # Remove Edge temp and cache dirs (safe file-level cleanup only)
    Set-OwnAndRemove -Path "$installMountDir\ProgramData\Microsoft\Edge" | Out-Null
    Set-OwnAndRemove -Path "$installMountDir\Users\Default\AppData\Local\Microsoft\Edge" | Out-Null
    Set-OwnAndRemove -Path (Join-Path -Path $installMountDir -ChildPath 'Windows\System32\Microsoft-Edge-WebView') | Out-Null

    # Removing EDGE-Task
    Get-ChildItem -Path "$installMountDir\Windows\System32\Tasks\MicrosoftEdge*" | Where-Object { $_ } | ForEach-Object { Set-OwnAndRemove -Path $_ } 2>&1 | Write-Log

    # For Windows 10 (Legacy EDGE)
    if ($buildNumber -lt 22000) {
        Get-ChildItem -Path "$installMountDir\Windows\SystemApps\Microsoft.MicrosoftEdge*" | Where-Object { $_ } | ForEach-Object { Set-OwnAndRemove -Path $_ } 2>&1 | Write-Log
    }

    Write-Host ("[OK] EDGE has been removed") -ForegroundColor Green
    Write-Log -msg "Microsoft Edge removal completed"
} else {
    Write-Log -msg "Edge removal cancelled"
}

# Remove AI components
if ($buildNumber -ge 22000) {
    if ($DoAIRemove) {
        Write-Host ("`n[INFO] Removing AI components...") -ForegroundColor Cyan
        Write-Log -msg "Removing AI components"

        # Remove AI Packages
        $AIpatterns = @(
            "Microsoft.Windows.Copilot*",
            "Microsoft.Copilot*",
            "MicrosoftWindows.Client.AIX*",
            "MicrosoftWindows.Client.CoPilot*",
            "MicrosoftWindows.Client.CoreAI*",
            "Microsoft.Windows.Ai.Copilot.Provider*",
            "Microsoft.Edge.GameAssist*",
            "Microsoft.Office.ActionsServer*",
            "Microsoft.WritingAssistant*"
        )
        Write-Host "  - Removing Provisioned AI packages..." -ForegroundColor DarkGray
        Write-Log -msg "Removing Provisioned AI packages"
        foreach ($pattern in $AIpatterns) {
            $matchedPackages = Invoke-DismRetryGet { Get-ProvisionedAppxPackage -Path $installMountDir | Where-Object { $_.PackageName -like $pattern } }
            if ($matchedPackages) {
                foreach ($package in $matchedPackages) {
                    Invoke-DismFailsafe {Remove-ProvisionedAppxPackage -Path $installMountDir -PackageName $package.PackageName} {dism /image:$installMountDir /Remove-ProvisionedAppxPackage /PackageName:$($package.PackageName)}
                }
            }
        }

        # Removing hidden CBS packages
        Write-Host "  - Removing hidden AI packages..." -ForegroundColor DarkGray
        Write-Log -msg "Removing hidden CBS AI packages"
        try {
            reg load HKLM\zCBS_SOFTWARE "$installMountDir\Windows\System32\config\SOFTWARE" 2>&1 | Write-Log
            $cbsPackagePath = "HKLM\zCBS_SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages"
            reg query $cbsPackagePath 2>$null | Where-Object { $_ -and $_ -ne $cbsPackagePath } | ForEach-Object {
                $pkgName = Split-Path $_.Trim() -Leaf
                if ($pkgName -match 'AIX|Recall|Copilot|CoreAI') {
                    reg add "$cbsPackagePath\$pkgName" /v "Visibility" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
                    reg add "$cbsPackagePath\$pkgName" /v "DefVis" /t REG_DWORD /d "2" /f 2>&1 | Write-Log
                    reg delete "$cbsPackagePath\$pkgName\Owners" /f 2>&1 | Write-Log
                    reg delete "$cbsPackagePath\$pkgName\Updates" /f 2>&1 | Write-Log
                    Write-Log -msg "Unhid CBS package: $pkgName"
                }
            }
            reg unload HKLM\zCBS_SOFTWARE 2>&1 | Write-Log
            $packages = dism /image:"$installMountDir" /Get-Packages /english 2>$null
            $packages | Where-Object { $_ -match "Package Identity\s*:\s*(.+)" } | ForEach-Object {
                $pkgId = $matches[1].Trim()
                if ($pkgId -match 'AIX|Recall|Copilot|CoreAI') {
                    Invoke-DismFailsafe {Remove-WindowsPackage -Path $installMountDir -PackageName $pkgId -NoRestart} {dism /image:$installMountDir /Remove-Package /PackageName:$pkgId /NoRestart}
                    Write-Log -msg "Removed CBS AI package: $pkgId"
                }
            }
        }
        catch { Write-Log -msg "CBS AI package removal error: $_" }
        finally { reg unload HKLM\zCBS_SOFTWARE 2>&1 | Out-Null }   # If try block fails

        # Modifying reg keys
        Write-Host "  - Tweaking registry..." -ForegroundColor DarkGray
        Write-Log -msg "Registry tweaks for RemoveAI"
        try {
            reg load HKLM\zSOFTWARE "$installMountDir\Windows\System32\config\SOFTWARE" 2>&1 | Write-Log
            reg load HKLM\zSYSTEM "$installMountDir\Windows\System32\config\SYSTEM" 2>&1 | Write-Log
            reg load HKLM\zNTUSER "$installMountDir\Users\Default\ntuser.dat" 2>&1 | Write-Log

            # Registry operations
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Disable AI in Notepad
            reg add "HKLM\zSOFTWARE\Policies\WindowsNotepad" /v "DisableAIFeatures" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Disable AI in Paint
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableCocreator" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableImageCreator" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableGenerativeFill" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableGenerativeErase" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableRemoveBackground" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Disable AI in other apps
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessSystemAIModels" /t REG_DWORD /d "2" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessGenerativeAI" /t REG_DWORD /d "2" /f 2>&1 | Write-Log
            # Disable AI access
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\generativeAI" /v "Value" /t REG_SZ /d "Deny" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "Value" /t REG_SZ /d "Deny" /f 2>&1 | Write-Log
            # Disable AI in Edge
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "HubsSidebarEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "CopilotPageContext" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "CopilotCDPPageContext" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "EdgeHistoryAISearchEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "BuiltInAIAPIsEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "AIGenThemesEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Edge" /v "ShareBrowsingHistoryWithCopilotSearchAllowed" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            # Disable AI in Search
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Disable WSAIFabricSvc Service on first logon
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "DisableWSAIFabricSvc" /t REG_SZ /d 'reg add "HKLM\SYSTEM\CurrentControlSet\Services\WSAIFabricSvc" /v "Start" /t REG_DWORD /d "4" /f' 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "StopWSAIFabricSvc" /t REG_SZ /d "net stop WSAIFabricSvc" 2>&1 | Write-Log
            # Hide AI components from Settings
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "SettingsPageVisibility" /t REG_SZ /d "hide:aicomponents" /f 2>&1 | Write-Log
            # Disable AI from Explorer
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\WindowsCopilot" /v "AllowCopilotRuntime" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowCopilotButton" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband\AuxilliaryPins" /v "CopilotPWAPin" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband\AuxilliaryPins" /v "RecallPin" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            # Prevent Copilot PWA from auto-reinstalling
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoInstalledPWAs" /v "CopilotPWAPreinstallCompleted" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Block Copilot background access
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications\Microsoft.Copilot_8wekyb3d8bbwe" /v "Disabled" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications\Microsoft.Copilot_8wekyb3d8bbwe" /v "DisabledByUser" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Remove Ask Copilot from right-click context menu
            reg add "HKLM\zNTUSER\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" /v "{CB3B0003-8088-4EDE-8769-8B354AB2FF8C}" /t REG_SZ /d "Ask Copilot" /f 2>&1 | Write-Log
            # Prevent Copilot from auto-opening on large screens
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings" /v "AutoOpenCopilotLargeScreens" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            # Prevent Copilot Appx from reinstalling via store policy
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Appx\RemoveDefaultMicrosoftStorePackages" /v "Enabled" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Appx\RemoveDefaultMicrosoftStorePackages\Microsoft.Copilot_8wekyb3d8bbwe" /v "RemovePackage" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            # Disable Copilot in Microsoft Office apps
            reg add "HKLM\zNTUSER\Software\Microsoft\Office\16.0\Word\Options" /v "EnableCopilot" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Office\16.0\Excel\Options" /v "EnableCopilot" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Office\16.0\OneNote\Options\Copilot" /v "CopilotEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\office\16.0\common\privacy" /v "controllerconnectedservicesenabled" /t REG_DWORD /d "2" /f 2>&1 | Write-Log
            # Disable Copilot and Recall system-wide
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAIDataAnalysis" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowRecallEnablement" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "TurnOffSavingSnapshots" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableSettingsAgent" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\Shell\Copilot" /v "IsCopilotAvailable" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\Shell\Copilot" /v "CopilotDisabledReason" /t REG_SZ /d "FeatureIsDisabled" /f 2>&1 | Write-Log
            # Disable Copilot and Recall for New Users
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\Windows\WindowsAI" /v "DisableAIDataAnalysis" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\Windows\WindowsAI" /v "AllowRecallEnablement" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\Windows\WindowsAI" /v "TurnOffSavingSnapshots" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\Windows\WindowsAI" /v "DisableSettingsAgent" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowCopilotButton" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" /v "{CB3B0003-8088-4EDE-8769-8B354AB2FF8C}" /t REG_SZ /d "Ask Copilot" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\Shell\Copilot" /v "IsCopilotAvailable" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
            reg add "HKLM\zNTUSER\Software\Microsoft\Windows\Shell\Copilot" /v "CopilotDisabledReason" /t REG_SZ /d "FeatureIsDisabled" /f 2>&1 | Write-Log
            # Remove AI Tasks
            reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\WindowsAI" /f 2>&1 | Write-Log
            Set-OwnAndRemove -Path "$installMountDir\Windows\System32\Tasks\Microsoft\Windows\WindowsAI" | Out-Null
            # Disable Recall on first logon
            reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "DisableRecall" /t REG_SZ /d "dism.exe /online /disable-feature /FeatureName:recall" /f 2>&1 | Write-Log
        }
        catch {
            Write-Log -msg "Error modifying registry: $_"
        }
        finally {
            # Always unload registry hives regardless of errors
            reg unload HKLM\zSOFTWARE 2>&1 | Write-Log
            reg unload HKLM\zSYSTEM 2>&1 | Write-Log
            reg unload HKLM\zNTUSER 2>&1 | Write-Log
        }
        # Note: Skipping AI WinSxS file cleanup to avoid installer corruption.
        # AI removal is handled via DISM package removal and registry policy above.
        Write-Host ("[OK] AI Components removed") -ForegroundColor Green
        Write-Log -msg "AI Components removal completed"
    } else {
        Write-Log -msg "AI Components removal skipped"
    }
}

# Registry Tweaks
Write-Host ("`n[INFO] Loading Registry...") -ForegroundColor Cyan
Write-Log -msg "Loading registry"
reg load HKLM\zCOMPONENTS "$installMountDir\Windows\System32\config\COMPONENTS" 2>&1 | Write-Log
reg load HKLM\zDEFAULT "$installMountDir\Windows\System32\config\default" 2>&1 | Write-Log
reg load HKLM\zNTUSER "$installMountDir\Users\Default\ntuser.dat" 2>&1 | Write-Log
reg load HKLM\zSOFTWARE "$installMountDir\Windows\System32\config\SOFTWARE" 2>&1 | Write-Log
reg load HKLM\zSYSTEM "$installMountDir\Windows\System32\config\SYSTEM" 2>&1 | Write-Log

# Setting Permissions
Set-Ownership -Registry @("zSOFTWARE\Microsoft\Windows\CurrentVersion\Communications", "zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks", "zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows", "zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\WindowsAI", "zSOFTWARE\Microsoft\WindowsRuntime\Server\Windows.Gaming.GameBar.Internal.PresenceWriterServer") | Out-Null

Write-Host ("[OK] Registry loaded") -ForegroundColor Green

# Modify registry settings
Write-Host ("`n[INFO] Performing Registry Tweaks...") -ForegroundColor Cyan
Write-Log -msg "Performing Registry Tweaks"

# Disable Sponsored Apps
Write-Host -NoNewline ("  Disabling Sponsored Apps".PadRight($statusColumn))
Write-Log -msg "Disabling Sponsored Apps"
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "OemPreInstalledAppsEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "PreInstalledAppsEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SilentInstalledAppsEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Microsoft\PolicyManager\current\device\Start" /v "ConfigureStartPins" /t REG_SZ /d '{\"pinnedList\": [{}]}' /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContentEnabled" /t REG_SZ /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContentEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310093Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338388Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338393Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353694Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353696Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338387Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "ContentDeliveryAllowed" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "PreInstalledAppsEverEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SoftLandingEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg delete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager\Subscriptions" /f 2>&1 | Write-Log
reg delete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager\SuggestedApps" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable Telemetry
Write-Host -NoNewline ("  Disabling Telemetry".PadRight($statusColumn))
Write-Log -msg "Disabling Telemetry"
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Personalization\Settings" /v "AcceptedPrivacyPolicy" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Privacy" /v "TailoredExperiencesWithDiagnosticDataEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy" /v "HasAccepted" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\InputPersonalization" /v "RestrictImplicitInkCollection" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\InputPersonalization" /v "RestrictImplicitTextCollection" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\InputPersonalization\TrainedDataStore" /v "HarvestContacts" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zSYSTEM\ControlSet001\Services\dmwappushservice" /v "Start" /t REG_DWORD /d "4" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable Mouse Acceleration
Write-Host -NoNewline ("  Disabling Mouse Acceleration".PadRight($statusColumn))
Write-Log -msg "Disabling Mouse Acceleration"
reg add "HKLM\zNTUSER\Control Panel\Mouse" /v "MouseSpeed" /t REG_SZ /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Control Panel\Mouse" /v "MouseThreshold1" /t REG_SZ /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\Control Panel\Mouse" /v "MouseThreshold2" /t REG_SZ /d "0" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable Meet Now icon
Write-Host -NoNewline ("  Disabling Meet".PadRight($statusColumn))
Write-Log -msg "Disabling Meet"
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAMeetNow" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "AllowOnlineTips" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable Ads and Stuffs
Write-Host -NoNewline ("  Disabling Ads and Stuffs".PadRight($statusColumn))
Write-Log -msg "Disabling Ads and Stuffs"
# Disable ad tailoring
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
# Disable cloud-based content
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableConsumerAccountStateContent" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableCloudOptimizedContent" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
# Disable Start Menu Suggestions
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_IrisRecommendations" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
# Disable News and Interest
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Feeds" /v "EnableFeeds" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
# Remove Spotlight icon from Desktop
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{2cc5ca98-6485-489a-920e-b3e88a6ccce3}" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
# Disable Cortana
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCortana" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
# Changes MenuShowDelay from 400 to 200
reg add "HKLM\zNTUSER\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "200" /f 2>&1 | Write-Log
# Disable everytime MRT download through Win Update
reg add "HKLM\zSOFTWARE\Policies\Microsoft\MRT" /v "DontOfferThroughWUAU" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
# Disable Teams Auto installation
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Teams" /v "DisableInstallation" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
# Disable Outlook
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Mail" /v "PreventRun" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable Bitlocker
Write-Host -NoNewline ("  Disabling Bitlocker Encryption".PadRight($statusColumn))
Write-Log -msg "Disabling Bitlocker Encryption"
reg add "HKLM\zSYSTEM\ControlSet001\Control\BitLocker" /v "PreventDeviceEncryption" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable OneDrive Stuffs
Write-Host -NoNewline ("  Removing OneDrive Junks".PadRight($statusColumn))
Write-Log -msg "Removing OneDrive Junks"
reg delete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableLibrariesDefaultSaveToOneDrive" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSyncNGSC" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\OneDrive" /v "KFMBlockOptIn" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable GameDVR
Write-Host -NoNewline ("  Disabling GameDVR and Components".PadRight($statusColumn))
Write-Log -msg "Disabling GameDVR and Components"
reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zNTUSER\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSYSTEM\ControlSet001\Services\BcastDVRUserService" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
reg add "HKLM\zSYSTEM\ControlSet001\Services\GameBarPresenceWriter" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Remove Gamebar Popup
# Courtesy: https://pastebin.com/EAABLssA by aveyo
Write-Host -NoNewline ("  Removing Gamebar Popup".PadRight($statusColumn))
Write-Log -msg "Removing Gamebar Popup"
reg add "HKLM\zNTUSER\Software\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
# Rest added as post install script. Somehow, implementing it directly on the image was causing corruption
Write-Host "[DONE]" -ForegroundColor Green

# # Configure GameBarFTServer (NA)
# $packageKey = "HKLM\zSOFTWARE\Classes\PackagedCom\ClassIndex\{FD06603A-2BDF-4BB1-B7DF-5DC68F353601}"
# $app = (Get-Item "Registry::$packageKey").PSChildName
# reg add "HKLM\zSOFTWARE\Classes\PackagedCom\Package\$app\Server\0" /v "Executable" /t REG_SZ /d "systray.exe" /f 2>&1 | Write-Log

# Enabling Local Account Creation
Write-Host -NoNewline ("  Tweaking OOBE Settings".PadRight($statusColumn))
Write-Log -msg "Tweaking OOBE Settings"
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OOBE" /v "DisablePrivacyExperience" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v "BypassNRO" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v "BypassNROGatherOptions" /t REG_DWORD /d "1" /f 2>&1 | Write-Log

# Check if Autounattend.xml exists before copying
if (Test-Path -Path $autounattendXmlPath) {
    Write-Log -msg "Copying Autounattend.xml"
    Copy-Item -Path $autounattendXmlPath -Destination $destinationPath -Force
} else {
    Write-Warning "Autounattend.xml not found at $autounattendXmlPath"
    Write-Log -msg "Warning: Autounattend.xml not found at $autounattendXmlPath"
}
Write-Host "[DONE]" -ForegroundColor Green

# Prevents Dev Home Installation
Write-Host -NoNewline ("  Disabling useless junks".PadRight($statusColumn))
Write-Log -msg "Disabling DevHomeUpdate, OutlookUpdate, ChatAutoInstall"
reg delete "HKLM\zSOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\DevHomeUpdate" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator\UScheduler\DevHomeUpdate" /v "workCompleted" /t REG_DWORD /d "1" /f 2>&1 | Write-Log

# Prevents New Outlook for Windows Installation
reg delete "HKLM\zSOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\OutlookUpdate" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator\UScheduler\OutlookUpdate" /v "workCompleted" /t REG_DWORD /d "1" /f 2>&1 | Write-Log

# Prevents Chat Auto Installation
reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Communications" /v "ConfigureChatAutoInstall" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Chat" /v "ChatIcon" /t REG_DWORD /d "3" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green

# Disable Scheduled Tasks
if ($DoTaskCleanup) {
Write-Host -NoNewline ("  Disabling Scheduled Tasks".PadRight($statusColumn))
Write-Log -msg "Disabling Scheduled Tasks"
$win24H2 = (Get-ItemProperty -Path 'Registry::HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name DisplayVersion -ErrorAction SilentlyContinue).DisplayVersion -eq '24H2'
if ($win24H2) {
    # Customer Experience Improvement Program
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{780E487D-C62F-4B55-AF84-0E38116AFE07}" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{FD607F42-4541-418A-B812-05C32EBA8626}" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{E4FED5BC-D567-4044-9642-2EDADF7DE108}" /f 2>&1 | Write-Log
    # Program Data Updater
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{E292525C-72F1-482C-8F35-C513FAA98DAE}" /f 2>&1 | Write-Log
    # Application Compatibility Appraiser
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{3047C197-66F1-4523-BA92-6C955FEF9E4E}" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{A0C71CB8-E8F0-498A-901D-4EDA09E07FF4}" /f 2>&1 | Write-Log
}
else {
    # Customer Experience Improvement Program
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{4738DE7A-BCC1-4E2D-B1B0-CADB044BFA81}" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{6FAC31FA-4A85-4E64-BFD5-2154FF4594B3}" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{FC931F16-B50A-472E-B061-B6F79A71EF59}" /f 2>&1 | Write-Log
    # Program Data Updater
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{0671EB05-7D95-4153-A32B-1426B9FE61DB}" /f 2>&1 | Write-Log
    # Application Compatibility Appraiser
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{0600DD45-FAF2-4131-A006-0B17509B9F78}" /f 2>&1 | Write-Log
}
Write-Log -msg "Cleaning up Scheduled Task registry entries (TaskCache\Tree)"
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Application Experience\PcaPatchDbTask" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Application Experience\MareBackup" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Application Experience\ProgramDataUpdater" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser Exp" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Autochk\Proxy" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Customer Experience Improvement Program" /f 2>&1 | Write-Log
Write-Host "[DONE]" -ForegroundColor Green
} else {
    Write-Log -msg "Scheduled task cleanup skipped"
    Write-Host "[SKIPPED]" -ForegroundColor Yellow
}

# Disable TPM CHeck
if ($DoTPMBypass) {
    Write-Host ("`n[INFO] Disabling TPM Check...") -ForegroundColor Cyan
    Write-Host ("  This may take some time") -ForegroundColor DarkGray
    Write-Log -msg "Disabling TPM Check"
    reg add "HKLM\zSYSTEM\Setup\LabConfig" /v "BypassTPMCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\Setup\LabConfig" /v "BypassSecureBootCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\Setup\LabConfig" /v "BypassStorageCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\Setup\LabConfig" /v "BypassCPUCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\Setup\LabConfig" /v "BypassRAMCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\Setup\LabConfig" /v "BypassDiskCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\Setup\MoSetup" /v "AllowUpgradesWithUnsupportedTPMOrCPU" /t REG_DWORD /d "1" /f 2>&1 | Write-Log

    # Disable Unsupported Hardware Watermark
    reg add "HKLM\zDEFAULT\Control Panel\UnsupportedHardwareNotificationCache" /v "SV1" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
    reg add "HKLM\zDEFAULT\Control Panel\UnsupportedHardwareNotificationCache" /v "SV2" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Control Panel\UnsupportedHardwareNotificationCache" /v "SV1" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Control Panel\UnsupportedHardwareNotificationCache" /v "SV2" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "HideUnsupportedHardwareNotifications" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
    # Clear upgrade failure records
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\CompatMarkers" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Shared" /f 2>&1 | Write-Log
    reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\TargetVersionUpgradeExperienceIndicators" /f 2>&1 | Write-Log
    # Simulate meeting requirements
    reg add "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\HwReqChk" /v "HwReqChkVars" /t REG_MULTI_SZ /d "SQ_SecureBootCapable=TRUE\0SQ_SecureBootEnabled=TRUE\0SQ_TpmVersion=2\0SQ_RamMB=8192" /f 2>&1 | Write-Log
    # Set Upgrade Eligibility
    reg add "HKLM\zNTUSER\Software\Microsoft\PCHC" /v "UpgradeEligibility" /t REG_DWORD /d "1" /f 2>&1 | Write-Log

    # Remove appraiserres.dll and replace with blank file
    $apprdllPath = Join-Path -Path $destinationPath -ChildPath "sources\appraiserres.dll"
    Set-OwnAndRemove -Path "$apprdllPath" | Out-Null
    New-Item -Path $apprdllPath -ItemType File -Force 2>&1 | Write-Log
    try {
        $ProgressPreference = 'SilentlyContinue'
        $bootWimPath = Join-Path $destinationPath "sources\boot.wim"
        $bootMountDir = "$env:SystemDrive\WIDTemp\mountdir\bootWIM"
        New-Item -ItemType Directory -Path $bootMountDir 2>&1 | Write-Log
        Invoke-DismFailsafe {Mount-WindowsImage -ImagePath $bootWimPath -Index 2 -Path $bootMountDir} {dism /mount-image /imagefile:$bootWimPath /index:2 /mountdir:$bootMountDir}

        reg load HKLM\xDEFAULT "$bootMountDir\Windows\System32\config\default" 2>&1 | Write-Log
        reg load HKLM\xNTUSER "$bootMountDir\Users\Default\ntuser.dat" 2>&1 | Write-Log
        reg load HKLM\xSYSTEM "$bootMountDir\Windows\System32\config\SYSTEM" 2>&1 | Write-Log
        reg load HKLM\xSOFTWARE "$bootMountDir\Windows\System32\config\SOFTWARE" 2>&1 | Write-Log

        reg add "HKLM\xSYSTEM\Setup\LabConfig" /v "BypassTPMCheck" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
        reg add "HKLM\xSYSTEM\Setup\LabConfig" /v "BypassSecureBootCheck" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
        reg add "HKLM\xSYSTEM\Setup\LabConfig" /v "BypassStorageCheck" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
        reg add "HKLM\xSYSTEM\Setup\LabConfig" /v "BypassCPUCheck" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
        reg add "HKLM\xSYSTEM\Setup\LabConfig" /v "BypassRAMCheck" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
        reg add "HKLM\xSYSTEM\Setup\LabConfig" /v "BypassDiskCheck" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\xSYSTEM\Setup\MoSetup" /v "AllowUpgradesWithUnsupportedTPMOrCPU" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
        reg add "HKLM\xDEFAULT\Control Panel\UnsupportedHardwareNotificationCache" /v "SV1" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\xDEFAULT\Control Panel\UnsupportedHardwareNotificationCache" /v "SV2" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\xSOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "HideUnsupportedHardwareNotifications" /t REG_DWORD /d "1" /f 2>&1 | Write-Log
        reg add "HKLM\xSOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\HwReqChk" /v "HwReqChkVars" /t REG_MULTI_SZ /d "SQ_SecureBootCapable=TRUE\0SQ_SecureBootEnabled=TRUE\0SQ_TpmVersion=2\0SQ_RamMB=8192" /f 2>&1 | Write-Log
        reg add "HKLM\xNTUSER\Software\Microsoft\PCHC" /v "UpgradeEligibility" /t REG_DWORD /d "1" /f 2>&1 | Write-Log

        reg unload HKLM\xDEFAULT 2>&1 | Write-Log
        reg unload HKLM\xNTUSER 2>&1 | Write-Log
        reg unload HKLM\xSYSTEM 2>&1 | Write-Log
        reg unload HKLM\xSOFTWARE 2>&1 | Write-Log

        Invoke-DismFailsafe {Dismount-WindowsImage -Path $bootMountDir -Save} {dism /unmount-image /mountdir:$bootMountDir /commit}
        Write-Host ("[OK] TPM Bypass Successful") -ForegroundColor Green
        Write-Log -msg "Successfully modified boot.wim for TPM Bypass"
    }
    catch {
        Write-Log -msg "Failed to mount boot.wim: $_"
    }
    finally {
        $ProgressPreference = 'Continue'
        Remove-Item -Path $bootMountDir -Recurse -Force -ErrorAction SilentlyContinue 2>&1 | Write-Log
    }
}
else {
    Write-Log -msg "TPM Bypass cancelled"
}

# Bring back user folders
if ($buildNumber -ge 22000) {
    if ($DoUserFoldersEnable) {
        Write-Host ("`n[INFO] Restoring User Folders...") -ForegroundColor Cyan

        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" /f 2>&1 | Write-Log

        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" /v "HideIfEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" /v "HideIfEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" /v "HideIfEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" /v "HideIfEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" /v "HideIfEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" /v "HideIfEnabled" /t REG_DWORD /d "0" /f 2>&1 | Write-Log

        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" /v "HiddenByDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" /v "HiddenByDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" /v "HiddenByDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" /v "HiddenByDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" /v "HiddenByDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log
        reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" /v "HiddenByDefault" /t REG_DWORD /d "0" /f 2>&1 | Write-Log

        Write-Host ("[OK] User Folders Restored") -ForegroundColor Green
        Write-Log -msg "User folders restored successfully"
    } else {
        Write-Log -msg "User folders restoration cancelled"
    }
}

# ============================================================
# ENHANCED DEBLOAT: Service Disabling
# ============================================================
if ($DoServicesDisable) {
    Write-Host ("`n[INFO] Disabling unnecessary services...") -ForegroundColor Cyan
    Write-Log -msg "Disabling unnecessary services"
    Write-Host "  Press [S] to skip remaining services" -ForegroundColor DarkGray
    Start-SkipWatcher "Service disabling"

    $servicesToDisable = @(
        @{Name="DiagTrack"; Start=4},
        @{Name="dmwappushservice"; Start=4},
        @{Name="diagnosticshub.standardcollector.service"; Start=4},
        @{Name="WpcMonSvc"; Start=4},
        @{Name="WMPNetworkSvc"; Start=4},
        @{Name="wlidsvc"; Start=4},
        @{Name="WSearch"; Start=4},
        @{Name="SysMain"; Start=4},
        @{Name="MapsBroker"; Start=4},
        @{Name="lfsvc"; Start=4},
        @{Name="PhoneSvc"; Start=4},
        @{Name="MessagingService"; Start=4},
        @{Name="PimIndexMaintenanceSvc"; Start=4},
        @{Name="UnistoreSvc"; Start=4},
        @{Name="UserDataSvc"; Start=4},
        @{Name="OneSyncSvc"; Start=4},
        @{Name="BcastDVRUserService"; Start=4},
        @{Name="XblAuthManager"; Start=4},
        @{Name="XblGameSave"; Start=4},
        @{Name="XboxNetApiSvc"; Start=4},
        @{Name="XboxGipSvc"; Start=4},
        @{Name="WalletService"; Start=4},
        @{Name="PrintNotify"; Start=4},
        @{Name="LicenseManager"; Start=4},
        @{Name="WaaSMedicSvc"; Start=4},
        @{Name="WbioSrvc"; Start=4},
        @{Name="FrameServer"; Start=4},
        @{Name="CaptureService"; Start=4},
        @{Name="SensorService"; Start=4},
        @{Name="SensorDataService"; Start=4},
        @{Name="SensrSvc"; Start=4},
        @{Name="TabletInputService"; Start=4},
        @{Name="TrkWks"; Start=4},
        @{Name="FontCache"; Start=4},
        @{Name="DusmSvc"; Start=4},
        @{Name="WpnService"; Start=4},
        @{Name="StiSvc"; Start=4},
        @{Name="wisvc"; Start=4},
        @{Name="RetailDemo"; Start=4},
        @{Name="tzautoupdate"; Start=4},
        @{Name="UsoSvc"; Start=3},
        @{Name="W32Time"; Start=3},
        @{Name="wcncsvc"; Start=4},
        @{Name="WerSvc"; Start=3},
        @{Name="WiaRpc"; Start=4}
    )

    # Extreme debloat: disable even more services
    if ($DoExtremeDebloat) {
        $servicesToDisable += @(
            @{Name="Spooler"; Start=4},
            @{Name="LanmanServer"; Start=4},
            @{Name="LanmanWorkstation"; Start=3},
            @{Name="fdPHost"; Start=4},
            @{Name="FDResPub"; Start=4},
            @{Name="SSDPSRV"; Start=4},
            @{Name="upnphost"; Start=4},
            @{Name="SCardSvr"; Start=4},
            @{Name="ScDeviceEnum"; Start=4},
            @{Name="SmsRouter"; Start=4},
            @{Name="BTAGService"; Start=4},
            @{Name="bthserv"; Start=4},
            @{Name="Fax"; Start=4},
            @{Name="hidserv"; Start=4}
        )
    }

    $svcTotal = $servicesToDisable.Count
    $svcIdx = 0
    foreach ($svc in $servicesToDisable) {
        $svcIdx++
        $svcPercent = [math]::Floor(($svcIdx / $svcTotal) * 100)
        Write-Progress -Activity "Disabling Services" -Status "$($svc.Name) ($svcIdx/$svcTotal)" -PercentComplete $svcPercent
        if ((Should-Skip)) {
            Write-Host "  [SKIPPED] Remaining $($svcTotal - $svcIdx + 1) services" -ForegroundColor Yellow
            Write-Log -msg "SKIPPED: $($svcTotal - $svcIdx + 1) services (user requested)"
            Write-ErrorLog -Message "Service disabling: $($svcTotal - $svcIdx + 1) services skipped by user" -Level "SKIP" -Source "Services"
            break
        }
        $svcPath = "HKLM\zSYSTEM\ControlSet001\Services\$($svc.Name)"
        reg add $svcPath /v "Start" /t REG_DWORD /d $svc.Start /f 2>&1 | Write-Log
    }
    Write-Progress -Activity "Disabling Services" -Completed
    Write-Log -msg "Disabled $($servicesToDisable.Count) unnecessary services"

    # Disable Widgets service
    if ($DoWidgetsRemove) {
        reg add "HKLM\zSYSTEM\ControlSet001\Services\WidgetService" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
        reg add "HKLM\zSYSTEM\ControlSet001\Services\WSearchIdxPi" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
        Write-Log -msg "Disabled Widgets service"
    }
    Stop-SkipWatcher

    Write-Host ("[OK] Services disabled") -ForegroundColor Green
}

# ============================================================
# ENHANCED DEBLOAT: Performance Tweaks
# ============================================================
if ($DoPerformanceTweaks) {
    Write-Host ("`n[INFO] Applying performance tweaks...") -ForegroundColor Cyan
    Write-Log -msg "Applying performance tweaks"

    # Disable visual effects for performance
    reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v "VisualFXSetting" /t REG_DWORD /d 3 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Control Panel\Desktop\WindowMetrics" /v "MinAnimate" /t REG_SZ /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Control Panel\Desktop" /v "UserPreferencesMask" /t REG_BINARY /d 9012038010000000 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "0" /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarAnimations" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "IconsOnly" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

    # CPU / Memory performance
    reg add "HKLM\zSYSTEM\ControlSet001\Control\PriorityControl" /v "Win32PrioritySeparation" /t REG_DWORD /d 38 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Control\Session Manager\Memory Management" /v "LargeSystemCache" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Control\Session Manager\Memory Management" /v "DisablePagingExecutive" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Control\Session Manager\Memory Management\PrefetchParameters" /v "EnablePrefetcher" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Control\Session Manager\Memory Management\PrefetchParameters" /v "EnableSuperfetch" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

    # Disable hibernation
    reg add "HKLM\zSYSTEM\ControlSet001\Control\Power" /v "HibernateEnabled" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Control\Power" /v "HibernateEnabledDefault" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

    # Network optimizations
    reg add "HKLM\zSYSTEM\ControlSet001\Services\Tcpip\Parameters" /v "DisableTaskOffload" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 4294967295 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Psched" /v "NonBestEffortLimit" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\Tcpip\Parameters" /v "EnableICMPRedirect" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

    # Disable Game Mode
    reg add "HKLM\zNTUSER\Software\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Software\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

    Write-Host ("[OK] Performance tweaks applied") -ForegroundColor Green
    Write-Log -msg "Performance tweaks applied"
}

# ============================================================
# ENHANCED DEBLOAT: Disable Windows Update
# ============================================================
if ($DoWinUpdateDisable) {
    Write-Host ("`n[INFO] Disabling Windows Update...") -ForegroundColor Cyan
    Write-Log -msg "Disabling Windows Update"

    # Disable WU service
    reg add "HKLM\zSYSTEM\ControlSet001\Services\wuauserv" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\WaaSMedicSvc" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\UsoSvc" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log

    # Disable automatic updates via policy
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "NoAutoUpdate" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "AUOptions" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DoNotConnectToWindowsUpdateInternetLocations" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DisableWindowsUpdateAccess" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "SetDisableUXWUAccess" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

    Write-Host ("[OK] Windows Update disabled") -ForegroundColor Green
}

# ============================================================
# ENHANCED DEBLOAT: Remove Widgets
# ============================================================
if ($DoWidgetsRemove) {
    Write-Host ("`n[INFO] Removing Widgets...") -ForegroundColor Cyan
    Start-Sleep -Seconds 3  # Let DISM release locks from prior operations
    Write-Log -msg "Removing Widgets"

    # Remove Widgets AppX packages
    $widgetPatterns = @(
        "MicrosoftWindows.Client.WebExperience*",
        "Microsoft.WindowsWidgets*",
        "Microsoft.Widgets*"
    )
    foreach ($pattern in $widgetPatterns) {
        $matchedPackages = Invoke-DismRetryGet { Get-ProvisionedAppxPackage -Path $installMountDir | Where-Object { $_.PackageName -like $pattern } }
        if ($matchedPackages) {
            foreach ($package in $matchedPackages) {
                Invoke-DismFailsafe {Remove-ProvisionedAppxPackage -Path $installMountDir -PackageName $package.PackageName} {dism /image:$installMountDir /Remove-ProvisionedAppxPackage /PackageName:$($package.PackageName)}
            }
        }
    }

    # Disable Widgets via policy
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Dsh" /v "AllowNewsAndInterests" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\PolicyManager\default\NewsAndInterests\AllowNewsAndInterests" /v "value" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Feeds" /v "ShellFeedsTaskbarViewMode" /t REG_DWORD /d 2 /f 2>&1 | Write-Log

    # Remove Widgets scheduled tasks
    Set-OwnAndRemove -Path "$installMountDir\Windows\System32\Tasks\Microsoft\Windows\Windows Feeds" | Out-Null

    # Remove Widgets files
    Set-OwnAndRemove -Path "$installMountDir\Program Files\WindowsApps\MicrosoftWindows.Client.WebExperience*" | Out-Null
    Get-ChildItem "$installMountDir\Windows\WinSxS\*webexperience*" -Directory -ErrorAction SilentlyContinue | ForEach-Object { Set-OwnAndRemove -Path $_.FullName } 2>&1 | Write-Log

    Write-Host ("[OK] Widgets removed") -ForegroundColor Green
}

# ============================================================
# ENHANCED DEBLOAT: Remove Hyper-V
# ============================================================
if ($DoHyperVRemove) {
    Write-Host ("`n[INFO] Removing Hyper-V components...") -ForegroundColor Cyan
    Start-Sleep -Seconds 3  # Let DISM release locks
    Write-Log -msg "Removing Hyper-V"

    # Disable Hyper-V features via DISM
    dism /image:"$installMountDir" /Disable-Feature /FeatureName:Microsoft-Hyper-V-All /Remove /Quiet 2>&1 | Write-Log
    dism /image:"$installMountDir" /Disable-Feature /FeatureName:Microsoft-Hyper-V /Remove /Quiet 2>&1 | Write-Log
    dism /image:"$installMountDir" /Disable-Feature /FeatureName:Microsoft-Hyper-V-Management-Clients /Remove /Quiet 2>&1 | Write-Log
    dism /image:"$installMountDir" /Disable-Feature /FeatureName:Microsoft-Hyper-V-Offline /Remove /Quiet 2>&1 | Write-Log
    dism /image:"$installMountDir" /Disable-Feature /FeatureName:Microsoft-Hyper-V-Online /Remove /Quiet 2>&1 | Write-Log

    # Disable Hyper-V services
    reg add "HKLM\zSYSTEM\ControlSet001\Services\HvHost" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmickvpexchange" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmicguestinterface" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmicshutdown" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmicheartbeat" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmicvmsession" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmicrdv" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmictimesync" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    reg add "HKLM\zSYSTEM\ControlSet001\Services\vmicvss" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log

    # Remove Hyper-V packages
    $hvPkgs = Invoke-DismRetryGet { Get-WindowsPackage -Path $installMountDir | Where-Object { $_.PackageName -like "*Hyper-V*" -or $_.PackageName -like "*HyperV*" } }
    if ($hvPkgs) {
        $hvPkgs | ForEach-Object {
            Invoke-DismFailsafe {Remove-WindowsPackage -Path $installMountDir -PackageName $_.PackageName} {dism /image:$installMountDir /Remove-Package /PackageName:$($_.PackageName) /NoRestart}
        }
    }

    Write-Host ("[OK] Hyper-V removed") -ForegroundColor Green
}

# ============================================================
# ENHANCED DEBLOAT: Remove Windows Defender
# ============================================================
if ($DoDefenderRemove) {
    Write-Host ("`n[INFO] Removing Windows Defender/Security...") -ForegroundColor Cyan
    Start-Sleep -Seconds 3  # Let DISM release locks
    Write-Log -msg "Removing Windows Defender"

    # Disable Defender services
    $defenderServices = @(
        "WinDefend", "WdNisSvc", "Sense", "WdFilter",
        "SecurityHealthService", "wscsvc", "mpssvc",
        "WdBoot", "WdNisDrv", "WdFilter"
    )
    foreach ($svc in $defenderServices) {
        reg add "HKLM\zSYSTEM\ControlSet001\Services\$svc" /v "Start" /t REG_DWORD /d 4 /f 2>&1 | Write-Log
    }

    # Disable Defender via policies
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableRoutinelyTakingAction" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableBehaviorMonitoring" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableOnAccessProtection" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableScanOnRealtimeEnable" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v "SpyNetReporting" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v "SubmitSamplesConsent" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "ForceUpdateFromMU" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\UX Configuration" /v "Notification_Suppress" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

    # Disable SmartScreen
    reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "EnableSmartScreen" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "SmartScreenEnabled" /t REG_SZ /d "Off" /f 2>&1 | Write-Log
    reg add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

    # Set post-install Defender removal tasks
    reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "DefenderRemove1" /t REG_SZ /d 'cmd.exe /c sc config WinDefend start= disabled' /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "DefenderRemove2" /t REG_SZ /d 'cmd.exe /c sc stop WinDefend' /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "DefenderRemove3" /t REG_SZ /d 'cmd.exe /c sc config SecurityHealthService start= disabled' /f 2>&1 | Write-Log
    reg add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "DefenderRemove4" /t REG_SZ /d 'cmd.exe /c sc stop SecurityHealthService' /f 2>&1 | Write-Log

    # Remove Defender AppX packages
    $defenderAppx = @("Microsoft.SecHealthUI*", "Microsoft.Windows.SecureHealthUI*", "Microsoft.Windows.SecurityHealth*")
    foreach ($pattern in $defenderAppx) {
        $matchedPackages = Invoke-DismRetryGet { Get-ProvisionedAppxPackage -Path $installMountDir | Where-Object { $_.PackageName -like $pattern } }
        if ($matchedPackages) {
            foreach ($package in $matchedPackages) {
                Invoke-DismFailsafe {Remove-ProvisionedAppxPackage -Path $installMountDir -PackageName $package.PackageName} {dism /image:$installMountDir /Remove-ProvisionedAppxPackage /PackageName:$($package.PackageName)}
            }
        }
    }

    # SAFE: Only remove Defender AppX and set registry policies. File-level removal
    # of WinSxS defender components corrupts the installer - skip it.
    Write-Log -msg "Defender: AppX removal and registry policy only (file removal skipped for stability)"

    Write-Host ("[OK] Windows Defender disabled (safe mode)") -ForegroundColor Green
}

# ============================================================
# ENHANCED DEBLOAT: More Scheduled Tasks (guarded)
# ============================================================
if ($DoTaskCleanup) {
Write-Host ("`n[INFO] Disabling additional scheduled tasks...") -ForegroundColor Cyan
Write-Host "  Press [S] to skip remaining tasks" -ForegroundColor DarkGray
Write-Log -msg "Disabling additional scheduled tasks"
Start-SkipWatcher "Scheduled task cleanup"

$extraTasks = @(
    "Microsoft\Windows\Application Experience\StartupAppTask",
    "Microsoft\Windows\Application Experience\MareBackup",
    "Microsoft\Windows\Application Experience\AitAgent",
    "Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
    "Microsoft\Windows\Application Experience\ProgramDataUpdater",
    "Microsoft\Windows\Autochk\Proxy",
    "Microsoft\Windows\CloudExperienceHost\CreateObjectTask",
    "Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
    "Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask",
    "Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
    "Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
    "Microsoft\Windows\DiskFootprint\Diagnostics",
    "Microsoft\Windows\FileHistory\File History (maintenance mode)",
    "Microsoft\Windows\Application Experience\PcaPatchDbTask",
    "Microsoft\Windows\Flighting\FeatureConfig\ReconcileFeatures",
    "Microsoft\Windows\LanguageComponentsInstaller\Installation",
    "Microsoft\Windows\Location\Notifications",
    "Microsoft\Windows\Maintenance\WinSAT",
    "Microsoft\Windows\Maps\MapsUpdateTask",
    "Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents",
    "Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic",
    "Microsoft\Windows\Mobile Broadband Accounts\MNO Metadata Parser",
    "Microsoft\Windows\PI\Sqm-Tasks",
    "Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem",
    "Microsoft\Windows\Registry\RegIdleBackup",
    "Microsoft\Windows\Speech\SpeechModelDownloadTask",
    "Microsoft\Windows\Sysmain\HybridDriveCachePrepopulate",
    "Microsoft\Windows\Sysmain\ResPriStaticDbSync",
    "Microsoft\Windows\Sysmain\WsSwapAssessmentTask",
    "Microsoft\Windows\Task Manager\Interactive",
    "Microsoft\Windows\Time Zone\SynchronizeTimeZone",
    "Microsoft\Windows\Time Synchronization\SynchronizeTime",
    "Microsoft\Windows\UPnP\UPnPHostConfig",
    "Microsoft\Windows\USB\Usb-Notifications",
    "Microsoft\Windows\WCM\WiFiTask",
    "Microsoft\Windows\Windows Error Reporting\QueueReporting",
    "Microsoft\Windows\Windows Filtering Platform\BfeOnServiceStartTypeChange",
    "Microsoft\Windows\Windows Media Sharing\UpdateLibrary",
    "Microsoft\Windows\WindowsColorSystem\Calibration Loader",
    "Microsoft\Windows\WindowsUpdate\Scheduled Start",
    "Microsoft\Windows\WlanSvc\WlanTask",
    "Microsoft\Windows\Work Folders\Work Folders Logon Synchronization",
    "Microsoft\Windows\Work Folders\Work Folders Maintenance Work"
)

$taskTotal = $extraTasks.Count
$taskIdx = 0
foreach ($taskPath in $extraTasks) {
    $taskIdx++
    $taskPercent = [math]::Floor(($taskIdx / $taskTotal) * 100)
    Write-Progress -Activity "Disabling Scheduled Tasks" -Status "Task $taskIdx/$taskTotal" -PercentComplete $taskPercent
    if ((Should-Skip)) {
        Write-Host "  [SKIPPED] Remaining $($taskTotal - $taskIdx + 1) tasks" -ForegroundColor Yellow
        Write-Log -msg "SKIPPED: $($taskTotal - $taskIdx + 1) tasks (user requested)"
        Write-ErrorLog -Message "Scheduled tasks: $($taskTotal - $taskIdx + 1) tasks skipped by user" -Level "SKIP" -Source "Tasks"
        break
    }
    $taskRegPath = "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\$taskPath"
    reg delete $taskRegPath /f 2>&1 | Write-Log
}
Write-Progress -Activity "Disabling Scheduled Tasks" -Completed

# Additional Widgets and WebExperience tasks
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\Windows Feeds" /f 2>&1 | Write-Log
reg delete "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\WebExperience" /f 2>&1 | Write-Log
Stop-SkipWatcher

Write-Host ("[OK] Additional tasks disabled") -ForegroundColor Green
} else {
    Write-Log -msg "Additional scheduled task cleanup skipped"
}

# ============================================================
# ENHANCED DEBLOAT: Deep WinSxS Cleanup
# ============================================================
if ($DoWinSxSCleanup) {
Write-Host ("`n[INFO] Performing conservative WinSxS cleanup...") -ForegroundColor Cyan
Write-Host "  Press [S] to skip remaining patterns" -ForegroundColor DarkGray
Write-Log -msg "Conservative WinSxS cleanup"
Start-SkipWatcher "WinSxS cleanup"

# SAFE patterns only - anchored to avoid matching system-critical components
$winSxSPatterns = @(
    "*_microsoft-windows-onedrive*",
    "*_microsoft-windows-microsoftedge*",
    "*_microsoft-windows-edgeupdate*",
    "*_microsoft-windows-edge-webview*",
    "*_microsoft-windows-webexperience*",
    # Removing *_microsoft-windows-xbox* and *_microsoft-windows-gaming* can break
    # the GameInput service which some display drivers depend on for boot.
    # Xbox AppX packages are already removed separately.
    "*_microsoft-windows-cortana*",
    "*_microsoft-windows-skype*",
    "*_microsoft-windows-zune*",
    "*_microsoft-windows-solitaire*",
    "*_microsoft-windows-bing*",
    "*_microsoft-windows-gethelp*",
    "*_microsoft-windows-getstarted*",
    "*_microsoft-windows-maps*",
    "*_microsoft-windows-3dviewer*",
    "*_microsoft-windows-print3d*",
    "*_microsoft-windows-wordpad*",
    "*_microsoft-windows-mediaplayer*",
    "*_microsoft-windows-clipchamp*",
    "*_microsoft-windows-officehub*",
    "*_microsoft-windows-onenote*",
    "*_microsoft-windows-powerautomate*",
    "*_microsoft-windows-todos*",
    "*_microsoft-windows-sticky*",
    "*_microsoft-windows-widget*",
    "*_microsoft-windows-quickassist*",
    "*_microsoft-windows-teams*",
    "*_microsoft-windows-people*",
    "*_microsoft-windows-mixedreality*",
    "*_microsoft-windows-feedback*",
    "*_clipchamp*",
    "*_skype*",
    "*_candycrush*",
    "*_spotify*",
    "*_netflix*",
    "*_disney*",
    "*_facebook*",
    "*_twitter*",
    "*_tiktok*",
    "*_instagram*"
)

$cleanedCount = 0
$sxsTotal = $winSxSPatterns.Count
$sxsIdx = 0
foreach ($pattern in $winSxSPatterns) {
    $sxsIdx++
    $sxsPercent = [math]::Floor(($sxsIdx / $sxsTotal) * 100)
    Write-Progress -Activity "Deep WinSxS Cleanup" -Status "Pattern: $pattern ($sxsIdx/$sxsTotal)" -PercentComplete $sxsPercent
    if ((Should-Skip)) {
        Write-Host "  [SKIPPED] Remaining $($sxsTotal - $sxsIdx + 1) patterns" -ForegroundColor Yellow
        Write-Log -msg "SKIPPED: WinSxS cleanup partial ($sxsIdx/$sxsTotal processed)"
        Write-ErrorLog -Message "WinSxS cleanup: $($sxsTotal - $sxsIdx + 1) patterns skipped by user" -Level "SKIP" -Source "WinSxS"
        break
    }
    $found = Get-ChildItem "$installMountDir\Windows\WinSxS" -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like $pattern }
    foreach ($item in $found) {
        Set-OwnAndRemove -Path $item.FullName | Out-Null
        $cleanedCount++
    }
}
Write-Progress -Activity "Deep WinSxS Cleanup" -Completed
Stop-SkipWatcher
Write-Log -msg "WinSxS cleanup: removed $cleanedCount component directories"

Write-Host ("[OK] WinSxS cleanup completed") -ForegroundColor Green
} else {
    Write-Log -msg "WinSxS cleanup skipped"
}

# ============================================================
# ENHANCED DEBLOAT: Additional Privacy & Bloat Tweaks
# ============================================================
Write-Host ("`n[INFO] Applying additional privacy tweaks...") -ForegroundColor Cyan
Write-Log -msg "Additional privacy tweaks"

# Disable Activity History
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "EnableActivityFeed" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "PublishUserActivities" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "UploadUserActivities" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable location tracking
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocation" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocationScripting" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

# Disable Find My Device
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\FindMyDevice" /v "AllowFindMyDevice" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable Windows Tips
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableSoftLanding" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightFeatures" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableThirdPartySuggestions" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableTailoredExperiencesWithDiagnosticData" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

# Disable background apps
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground" /t REG_DWORD /d 2 /f 2>&1 | Write-Log

# Disable Cortana completely
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCortana" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCortanaAboveLock" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowSearchToUseLocation" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "DisableWebSearch" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "ConnectedSearchUseWeb" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable Windows Error Reporting
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting" /v "Disabled" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting" /v "DontSendAdditionalData" /t REG_DWORD /d 1 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting" /v "LoggingDisabled" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

# Disable Delivery Optimization (P2P updates)
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" /v "DODownloadMode" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable advertising ID
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

# Remove 'Recently Added' apps list
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Explorer" /v "HideRecentlyAddedApps" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

# Disable Windows Ink Workspace
reg add "HKLM\zSOFTWARE\Policies\Microsoft\WindowsInkWorkspace" /v "AllowWindowsInkWorkspace" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable Clipboard History
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "AllowClipboardHistory" /t REG_DWORD /d 0 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "AllowCrossDeviceClipboard" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable Timeline
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\System" /v "EnableActivityFeed" /t REG_DWORD /d 0 /f 2>&1 | Write-Log

# Disable lock screen suggestions
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableLockScreenSpotlightFeatures" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

# Disable sync provider notifications
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\SettingSync" /v "DisableSettingSync" /t REG_DWORD /d 2 /f 2>&1 | Write-Log
reg add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\SettingSync" /v "DisableSettingSyncUserOverride" /t REG_DWORD /d 1 /f 2>&1 | Write-Log

Write-Host ("[OK] Privacy tweaks applied") -ForegroundColor Green
Write-Log -msg "Privacy tweaks applied"

Write-Host ("`n[INFO] Unloading Registry...") -ForegroundColor Cyan
Write-Log -msg "Unloading registry"
reg unload HKLM\zCOMPONENTS 2>&1 | Write-Log
reg unload HKLM\zDEFAULT 2>&1 | Write-Log
reg unload HKLM\zNTUSER 2>&1 | Write-Log
reg unload HKLM\zSOFTWARE 2>&1 | Write-Log
reg unload HKLM\zSYSTEM 2>&1 | Write-Log
Write-Host ("[OK] Success") -ForegroundColor Green

# Integrate Intel RST/VMD Drivers
if ($DoDriverIntegrate) {
    Write-Host ("`n[INFO] Integrating Intel RST/VMD Drivers...") -ForegroundColor Cyan
    Write-Host ("  This may take some time") -ForegroundColor DarkGray
    Write-Log -msg "Starting Intel RST/VMD driver integration"

    Test-InternetConnection | Out-Null

    $driverTempPath = "$env:SystemDrive\WIDTemp\drivers"
    $driverZipPath = "$driverTempPath\drivers.zip"
    $driverExtractPath = "$driverTempPath\extracted"
    $DriverURL = "https://github.com/itsNileshHere/Windows-ISO-Debloater/archive/refs/heads/main.zip"

    try {
        # Create temp directories
        New-Item -ItemType Directory -Path $driverTempPath -Force 2>&1 | Write-Log
        New-Item -ItemType Directory -Path $driverExtractPath -Force 2>&1 | Write-Log

        # Download drivers
        Write-Host "  - Downloading drivers..."  -ForegroundColor DarkGray
        $ProgressPreference = 'SilentlyContinue'
        try {
            Invoke-WebRequest -Uri $DriverURL -OutFile $driverZipPath -UseBasicParsing -ErrorAction Stop
        }
        catch {
            Write-Host "Failed to download drivers" -ForegroundColor Red
            Write-Log -msg "Driver download failed: $_"
            return
        }
        finally {
            $ProgressPreference = 'Continue'
        }

        # Verify download
        if (-not (Test-Path $driverZipPath)) {
            Write-Host "Driver download failed - file not found" -ForegroundColor Red
            Write-Log -msg "Driver zip file not found at: $driverZipPath"
            return
        }
        Write-Log -msg "Drivers downloaded to $driverZipPath"

        # Extract drivers
        Write-Host "  - Extracting drivers..." -ForegroundColor DarkGray
        try {
            Expand-Archive -Path $driverZipPath -DestinationPath $driverExtractPath -Force -ErrorAction Stop
        }
        catch {
            Write-Host "Failed to extract drivers" -ForegroundColor Red
            Write-Log -msg "Driver extraction failed: $_"
            return
        }
        Write-Log -msg "Drivers extracted to $driverExtractPath"

        # Get and verify driver path
        $driverSourcePath = Join-Path $driverExtractPath "Windows-ISO-Debloater-main\Drivers"
        if (-not (Test-Path $driverSourcePath)) {
            Write-Host "Driver folder not found in extracted files" -ForegroundColor Red
            Write-Log -msg "Driver folder not found at: $driverSourcePath"
            return
        }
        Write-Log -msg "Driver source path verified: $driverSourcePath"

        # Add drivers to install.wim
        Write-Host "  - Adding drivers to install.wim..." -ForegroundColor DarkGray
        Invoke-DismFailsafe {Add-WindowsDriver -Path $installMountDir -Driver $driverSourcePath -Recurse -ForceUnsigned} {dism /image:$installMountDir /Add-Driver /driver:$driverSourcePath /recurse /ForceUnsigned}
        Write-Log -msg "Drivers added to install.wim"

        # Add drivers to boot.wim
        Write-Host "  - Adding drivers to boot.wim..." -ForegroundColor DarkGray
        $bootWimPath = Join-Path $destinationPath "sources\boot.wim"
        $bootMountDir = "$env:SystemDrive\WIDTemp\mountdir\bootWIM"
        New-Item -ItemType Directory -Path $bootMountDir -Force 2>&1 | Write-Log

        # Mount boot.wim, Add drivers, and unmount
        Invoke-DismFailsafe {Mount-WindowsImage -ImagePath $bootWimPath -Index 2 -Path $bootMountDir} {dism /mount-image /imagefile:$bootWimPath /index:2 /mountdir:$bootMountDir}
        Invoke-DismFailsafe {Add-WindowsDriver -Path $bootMountDir -Driver $driverSourcePath -Recurse -ForceUnsigned} {dism /image:$bootMountDir /Add-Driver /driver:$driverSourcePath /recurse /ForceUnsigned}
        Invoke-DismFailsafe {Dismount-WindowsImage -Path $bootMountDir -Save} {dism /unmount-image /mountdir:$bootMountDir /commit}

        Write-Log -msg "Drivers added to boot.wim"

        Write-Host ("[OK] Driver integration completed") -ForegroundColor Green
        Write-Log -msg "Driver integration completed"
    }
    catch {
        Write-Host "Driver integration failed - skipping" -ForegroundColor Red
        Write-Log -msg "Driver integration failed: $_"
    }
    finally {
        Remove-Item -Path $driverTempPath -Recurse -Force -ErrorAction SilentlyContinue 2>&1 | Write-Log
    }
}
else {
    Write-Log -msg "Driver integration skipped"
}

# Unmounting and cleaning up the image
Write-Host ("`n[INFO] Cleaning up image...") -ForegroundColor Cyan
Write-Progress -Activity "Image Cleanup" -Status "Running component cleanup (this may take a while)..." -PercentComplete 10
Write-Log -msg "Cleaning up image"
# Aggressive component cleanup (timeout 15 min, allow skip)
Invoke-DismWithTimeout -Description "Component cleanup" -PowerShellCmd {dism /image:$installMountDir /Cleanup-Image /StartComponentCleanup /ResetBase} -DismCmd {dism /image:$installMountDir /Cleanup-Image /StartComponentCleanup /ResetBase} -TimeoutSeconds 900
# NOTE: Skipping WinSxS backup/manifest deletion to avoid installer corruption.
# DISM's StartComponentCleanup /ResetBase already handles safe cleanup.
Write-Progress -Activity "Image Cleanup" -Completed
Write-Log -msg "Deep image cleanup completed"

# ============================================================
# ISO HEALTH CHECK & REPAIR
# ============================================================
Write-Host ("`n[INFO] Running ISO health check...") -ForegroundColor Cyan
Write-Log -msg "ISO health check started"

$healthIssues = @()
$healthPassed = @()

# 1. Check mounted image health via DISM
Write-Host "  - Scanning component store..." -ForegroundColor DarkGray
Write-Progress -Activity "Health Check" -Status "Checking component store health..." -PercentComplete 20
$checkOut = dism /image:"$installMountDir" /Cleanup-Image /CheckHealth /English 2>&1 | Out-String
Write-Log -msg "CheckHealth output: $($checkOut -replace '\s+', ' ')"

# Parse the CheckHealth result line
$healthLine = ($checkOut -split '\n' | Where-Object { $_ -match 'health|corrupt|repair|error' } | Select-Object -First 1).Trim()
if (-not $healthLine) { $healthLine = $checkOut.Trim() }

if ($checkOut -match 'repairable|corrupted|error|not (healthy|found)') {
    Write-Host "  [!] BEFORE: $healthLine" -ForegroundColor Yellow
    Write-ErrorLog -Message "Component store before repair: $healthLine" -Level "WARN" -Source "Health"
    Write-Progress -Activity "Health Check" -Status "Attempting repair..." -PercentComplete 40

    # Try repair with backup ISO as source if available
    $repairArgs = @("/image:$installMountDir", "/Cleanup-Image", "/RestoreHealth", "/LimitAccess")
    $repairSource = "Windows Update / built-in"
    if ($isoBackupPath -and (Test-Path $isoBackupPath)) {
        Write-Host "    Mounting backup ISO for repair source..." -ForegroundColor DarkGray
        $backupMountDir = "$env:SystemDrive\WIDTemp\mountdir\backupWIM"
        New-Item -ItemType Directory -Path $backupMountDir -Force | Out-Null
        try {
            $backupMnt = Mount-DiskImage -ImagePath $isoBackupPath -PassThru
            $backupDrive = ($backupMnt | Get-Volume).DriveLetter
            $backupWimPath = "${backupDrive}:\sources\install.wim"
            if (Test-Path $backupWimPath) {
                dism /mount-image /imagefile:$backupWimPath /index:1 /mountdir:$backupMountDir /readonly 2>&1 | Write-Log
                if (Test-Path "$backupMountDir\Windows") {
                    $repairSource = "backup ISO"
                    $repairArgs += "/Source:$backupMountDir\Windows"
                    Write-Host "    [OK] Using backup ISO as repair source" -ForegroundColor Green
                } else { Write-Host "    [!] Backup mount failed, using built-in repair" -ForegroundColor Yellow }
            }
        } catch { Write-Log -msg "Could not mount backup ISO for repair: $_" }
    } else {
        Write-Host "    No backup ISO found, using built-in repair source" -ForegroundColor DarkGray
    }

    Write-Host "    Running RestoreHealth (source: $repairSource)..." -ForegroundColor DarkGray
    $scanOut = & dism $repairArgs 2>&1 | Out-String
    Write-Log -msg "RestoreHealth output: $($scanOut -replace '\s+', ' ')"
    $repairLine = ($scanOut -split '\n' | Where-Object { $_ -match 'success|completed|failed|error|restored' } | Select-Object -First 1).Trim()

    # Cleanup backup mount
    if ($backupMountDir -and (Test-Path "$backupMountDir\Windows")) {
        try { dism /unmount-image /mountdir:$backupMountDir /discard 2>&1 | Write-Log } catch {}
    }
    if ($backupMnt) { try { Dismount-DiskImage -ImagePath $isoBackupPath | Out-Null } catch {} }
    Remove-Item -Path $backupMountDir -Recurse -Force -ErrorAction SilentlyContinue | Out-Null

    # Re-check after repair
    Write-Host "    Verifying repair..." -ForegroundColor DarkGray
    $recheck = dism /image:"$installMountDir" /Cleanup-Image /CheckHealth /English 2>&1 | Out-String
    $recheckLine = ($recheck -split '\n' | Where-Object { $_ -match 'health|corrupt|repair|error' } | Select-Object -First 1).Trim()
    if (-not $recheckLine) { $recheckLine = $recheck.Trim() }

    if ($recheck -match 'healthy|No component|restored successfully') {
        Write-Host "  [REPAIRED] AFTER: $recheckLine" -ForegroundColor Green
        $healthPassed += "Component store: REPAIRED (source: $repairSource)"
    } else {
        Write-Host "  [STILL DAMAGED] AFTER: $recheckLine" -ForegroundColor Red
        Write-Host "    Repair attempt did not fully fix the component store." -ForegroundColor Red
        Write-Host "    The ISO may still install but could have stability issues." -ForegroundColor Red
        $healthIssues += "Component store: STILL DAMAGED after repair (source: $repairSource) - $recheckLine"
        Write-ErrorLog -Message "Component store not fully repairable: $recheckLine" -Level "WARN" -Source "Health"
    }
} else {
    $healthPassed += "Component store: healthy"
    Write-Host "  [OK] Component store is healthy - no repair needed" -ForegroundColor Green
    Write-Host "    $healthLine" -ForegroundColor DarkGray
}

# 2. Check critical ISO files exist
Write-Host "  - Checking ISO file structure..." -ForegroundColor DarkGray
Write-Progress -Activity "Health Check" -Status "Verifying ISO file structure..." -PercentComplete 60
# ISO-root files (in $destinationPath)
$isoRootFiles = @(
    @{Path="sources\install.wim"; Desc="install.wim (ISO root)"},
    @{Path="sources\boot.wim"; Desc="boot.wim (ISO root)"},
    @{Path="boot\bcd"; Desc="Boot BCD (ISO root)"},
    @{Path="boot\boot.sdi"; Desc="Boot SDI (ISO root)"},
    @{Path="bootmgr"; Desc="Boot Manager (ISO root)"},
    @{Path="bootmgr.efi"; Desc="EFI Boot Manager (ISO root)"},
    @{Path="efi\microsoft\boot\efisys.bin"; Desc="EFI boot image (ISO root)"},
    @{Path="setup.exe"; Desc="Setup.exe (ISO root)"},
    @{Path="sources\setup.exe"; Desc="Setup sources (ISO root)"}
)
# Windows-internal files (in $installMountDir)
$winFiles = @(
    @{Path="Windows\System32\config\SOFTWARE"; Desc="SOFTWARE hive"},
    @{Path="Windows\System32\config\SYSTEM"; Desc="SYSTEM hive"},
    @{Path="Windows\explorer.exe"; Desc="Explorer"}
)

$missingCount = 0
foreach ($cf in $isoRootFiles) {
    $fp = Join-Path $destinationPath $cf.Path
    if (Test-Path $fp) {
        $healthPassed += "Present: $($cf.Desc)"
    } else {
        $missingCount++
        $healthIssues += "MISSING: $($cf.Desc)"
        Write-ErrorLog -Message "Missing critical file: $($cf.Desc) at $fp" -Level "ERROR" -Source "Health"
    }
}
foreach ($cf in $winFiles) {
    $fp = Join-Path $installMountDir $cf.Path
    if (Test-Path $fp) {
        $healthPassed += "Present: $($cf.Desc)"
    } else {
        $missingCount++
        $healthIssues += "MISSING: $($cf.Desc)"
        Write-ErrorLog -Message "Missing critical file: $($cf.Desc) at $fp" -Level "ERROR" -Source "Health"
    }
}
if ($missingCount -eq 0) {
    Write-Host "  [OK] All critical files present" -ForegroundColor Green
} else {
    Write-Host "  [!] $missingCount critical files missing!" -ForegroundColor Red
}

# 3. Verify registry hives are loadable
Write-Host "  - Checking registry hives..." -ForegroundColor DarkGray
Write-Progress -Activity "Health Check" -Status "Verifying registry hives..." -PercentComplete 80
$regHives = @("SOFTWARE","SYSTEM","DEFAULT","COMPONENTS","SAM","SECURITY")
$regFailCount = 0
foreach ($hive in $regHives) {
    $hivePath = Join-Path $installMountDir "Windows\System32\config\$hive"
    if (Test-Path $hivePath) {
        try {
            $testKey = "HKLM\zHEALTH_$hive"
            reg load $testKey $hivePath 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                reg unload $testKey 2>&1 | Out-Null
                $healthPassed += "Registry ${hive}: loadable"
            } else {
                $regFailCount++
                $healthIssues += "Registry ${hive}: failed to load (exit $LASTEXITCODE)"
            }
        } catch {
            $regFailCount++
            $healthIssues += "Registry ${hive}: exception during load"
            reg unload $testKey 2>&1 | Out-Null
        }
    } else {
        $regFailCount++
        $healthIssues += "Registry ${hive}: file not found"
    }
}
if ($regFailCount -eq 0) {
    Write-Host "  [OK] All registry hives healthy" -ForegroundColor Green
} else {
    Write-Host "  [!] $regFailCount registry hives have issues" -ForegroundColor Red
}

# 4. Health summary
Write-Progress -Activity "Health Check" -Completed
Write-Host "`n  --- Health Check Results ---" -ForegroundColor Cyan
Write-Host "  Passed: $($healthPassed.Count) checks" -ForegroundColor Green
if ($healthIssues.Count -gt 0) {
    Write-Host "  Issues: $($healthIssues.Count)" -ForegroundColor Red
    foreach ($issue in $healthIssues) {
        Write-Host "    - $issue" -ForegroundColor Yellow
        Write-ErrorLog -Message "Health issue: $issue" -Level "WARN" -Source "Health"
    }
    Write-Host "`n  WARNING: ISO has issues. Installation may be affected." -ForegroundColor Red
    Write-Log -msg "ISO health check: $($healthIssues.Count) issues found. $($healthPassed.Count) checks passed."
} else {
    Write-Host "  [OK] ISO is healthy - no issues found" -ForegroundColor Green
    Write-Log -msg "ISO health check: All $($healthPassed.Count) checks passed. No issues."
}

Write-Host ("`n[INFO] Unmounting and Exporting image...") -ForegroundColor Cyan
Write-Log -msg "Unmounting image"
try {
    Write-Progress -Activity "Saving Image" -Status "Unmounting image (committing changes)..." -PercentComplete 30
    Invoke-DismFailsafe {Dismount-WindowsImage -Path $installMountDir -Save} {dism /unmount-image /mountdir:$installMountDir /commit}
    Write-Log -msg "Image unmounted successfully"
}
catch {
    Write-Host "`n`nFailed to Unmount the Image. Check Logs for more info." -ForegroundColor Red
    Write-ErrorLog -Message "Failed to unmount image: $_" -Level "ERROR" -Source "Unmount"
    Write-Host "Close all the Folders opened in the mountdir to complete the Script."
    Write-Host "Run the following code in Powershell(as admin) to unmount the broken image: "
    Write-Host "Dismount-WindowsImage -Path $installMountDir -Discard" -ForegroundColor Yellow
    Write-Log -msg "Failed to unmount image: $_"
    Pause
    Exit
}

Write-Log -msg "Exporting image"
$tempWimPath = "$destinationPath\sources\install_temp.wim"
$exportSuccess = $false

if ($DoESDConvert) {
    Write-Host ("`n[INFO] Compressing image to esd...") -ForegroundColor Cyan
    Write-Host "  This may take 15-45 minutes depending on ISO size" -ForegroundColor DarkGray
    Write-Log -msg "Compressing image to esd"
    Write-Progress -Activity "Exporting Image" -Status "Compressing to ESD (recovery compression)..." -PercentComplete 50
    try {
        $result = Invoke-DismWithTimeout -Description "ESD compress & export" -PowerShellCmd {Start-Process -FilePath "dism.exe" -ArgumentList "/Export-Image /SourceImageFile:`"$destinationPath\sources\install.wim`" /SourceIndex:$sourceIndex /DestinationImageFile:`"$tempWimPath`" /Compress:Recovery /CheckIntegrity" -Wait -NoNewWindow -PassThru} -DismCmd {Start-Process -FilePath "dism.exe" -ArgumentList "/Export-Image /SourceImageFile:`"$destinationPath\sources\install.wim`" /SourceIndex:$sourceIndex /DestinationImageFile:`"$tempWimPath`" /Compress:Recovery /CheckIntegrity" -Wait -NoNewWindow -PassThru} -TimeoutSeconds 3600
        if (Test-Path $tempWimPath) {
            $exportSuccess = $true
            Write-Host ("[OK] Compression completed") -ForegroundColor Green
            Write-Log -msg "Compression completed"
        } else {
            Write-Host "Compression failed - output not found" -ForegroundColor Red
            Write-Log -msg "Compression failed - output not found"
        }
    } catch {
        Write-Host "Compression failed with error: $_" -ForegroundColor Red
        Write-Log -msg "Compression failed with error: $_"
    }
}
else {
    Write-Host ("`n[INFO] Exporting image to wim...") -ForegroundColor Cyan
    Write-Host "  This may take 10-20 minutes" -ForegroundColor DarkGray
    Write-Log -msg "Exporting image to wim"
    Write-Progress -Activity "Exporting Image" -Status "Exporting to WIM (max compression)..." -PercentComplete 50
    try {
        Invoke-DismWithTimeout -Description "WIM export" -PowerShellCmd {Export-WindowsImage -SourceImagePath "$destinationPath\sources\install.wim" -SourceIndex $sourceIndex -DestinationImagePath $tempWimPath -CompressionType Maximum -CheckIntegrity} -DismCmd {dism /Export-Image /SourceImageFile:$destinationPath\sources\install.wim /SourceIndex:$sourceIndex /DestinationImageFile:$tempWimPath /compress:max} -TimeoutSeconds 1800 -AllowSkip $false
        if (Test-Path $tempWimPath) {
            $exportSuccess = $true
            Write-Host ("[OK] Export completed successfully") -ForegroundColor Green
            Write-Log -msg "Export completed successfully"
        } else {
            Write-Host "Export failed - temp WIM not found" -ForegroundColor Red
            Write-Log -msg "Export failed - temp WIM not found"
        }
    } catch {
        Write-Host "Export failed with error: $_" -ForegroundColor Red
        Write-Log -msg "Export failed with error: $_"
    }
}
Write-Progress -Activity "Exporting Image" -Completed

if ($exportSuccess) {
    Remove-Item -Path "$destinationPath\sources\install.wim" -Force
    Move-Item -Path $tempWimPath -Destination "$destinationPath\sources\install.wim" -Force

    if (-not (Test-Path "$destinationPath\sources\install.wim")) {
        Write-Host "Error: Unable to create the WIM file. Check logs for details." -ForegroundColor Red
        Write-Log -msg "Final install.wim missing"
        Pause
        Exit
    } else {
        Write-Log -msg "WIM file successfully replaced"
    }
} else {
    Write-Host "Error: Unable to export modified WIM file. Check logs for details." -ForegroundColor Red
    Write-Log -msg "WIM export failed, original WIM file preserved"
    Write-ErrorLog -Message "WIM export failed, original WIM preserved" -Level "ERROR" -Source "Export"
    Pause
    Exit
}

# Verify the WIM file is accessible and valid
try {
    $wimPath = Get-WindowsImage -ImagePath "$destinationPath\sources\install.wim" -ErrorAction Stop
    if ($wimPath) {
        Write-Host ("[OK] WIM file validation successful: $($wimPath.Count) images found") -ForegroundColor Green
        Write-Log -msg "WIM validation passed: $($wimPath.Count) images found"

        # Force a filesystem sync to ensure all changes are written to disk
        [System.IO.File]::OpenWrite("$destinationPath\sources\install.wim").Close()
        # Add a small delay to ensure file operations are complete
        Start-Sleep -Seconds 3
    } else {
        Write-Warning "WIM file validation returned no images"
        Write-Log -msg "WIM validation warning: No images returned"
    }
} catch {
    Write-Host "Error: WIM file validation failed - $($_)" -ForegroundColor Red
    Write-Log -msg "WIM validation failed: $_"
}

Write-Log -msg "Checking required files"
if ($outputISO) {
    $ISOFileName = [System.IO.Path]::GetFileNameWithoutExtension($outputISO)
    $ISOFileName = ($ISOFileName -replace '[<>:"/\\|?*\x00-\x1F\s]', '').Trim()
} else {
    do {
        $ISOFileName = Read-Host -Prompt "`nEnter the name for the ISO file (without extension)"

        # Remove invalid characters
        $ISOFileName = ($ISOFileName -replace '[<>:"/\\|?*\x00-\x1F\s]', '').Trim()
        if ([string]::IsNullOrWhiteSpace($ISOFileName)) {
            Write-Warning "Filename is empty or invalid. Please enter a valid name."
        }
    } while ([string]::IsNullOrWhiteSpace($ISOFileName))
}
$ISOFile = Join-Path -Path $scriptDirectory -ChildPath "$ISOFileName.iso"
Write-Log -msg "ISO file name set to: $ISOFileName.iso"

if ($DoUseOscdimg) {
    if (-not (Test-Path -Path $Oscdimg)) {
        Write-Log -msg "Oscdimg.exe not found at '$Oscdimg'"
        Write-Host "`nOscdimg.exe not found at '$Oscdimg'." -ForegroundColor Red
        Write-Host "`nTrying to Download oscdimg.exe..." -ForegroundColor Cyan

        Test-InternetConnection | Out-Null

        # Downloading Oscdimg.exe
        # Courtesy: https://github.com/p0w3rsh3ll/ADK
        $ADKfolder = "$scriptDirectory\ADKDownload"
        $CabFileName = "5d984200acbde182fd99cbfbe9bad133.cab"
        $ExtractedFileName = "fil720cc132fbb53f3bed2e525eb77bdbc1"

        New-Item -ItemType Directory -Path $OscdimgPath -Force 2>&1 | Write-Log
        New-Item -ItemType Directory -Path $ADKfolder -Force 2>&1 | Write-Log

        # Resolve the URL
        $RedirectResponse = Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/?linkid=2290227" -MaximumRedirection 0 -UseBasicParsing -ErrorAction SilentlyContinue
        if ($RedirectResponse.StatusCode -eq 302) {
            $BaseURL = $RedirectResponse.Headers.Location.TrimEnd('/') + "/"
            $CabURL = "$BaseURL`Installers/$CabFileName"
            $CabFilePath = "$ADKfolder\$CabFileName"

            Write-Log -msg "Downloading CAB file from: $CabURL"
            Invoke-WebRequest -Uri $CabURL -OutFile $CabFilePath -UseBasicParsing

            # Extract the CAB file
            Write-Log -msg "Extracting CAB file..."
            expand.exe -F:* $CabFilePath $ADKfolder 2>&1 | Write-Log

            # Move the required file
            $ExtractedFilePath = "$ADKfolder\$ExtractedFileName"
            $FinalFilePath = "$OscdimgPath\oscdimg.exe"

            if (Test-Path $ExtractedFilePath) {
                Move-Item -Path $ExtractedFilePath -Destination $FinalFilePath -Force 2>&1 | Write-Log
                Write-Host "Oscdimg.exe downloaded successfully" -ForegroundColor Green
                Write-Log -msg "Oscdimg.exe successfully placed in: $OscdimgPath"
            }
            else {
                Write-Log -msg "Error: Extracted file not found!"
            }
        }
        else {
            Write-Host "Error: Failed to download Oscdimg.exe" -ForegroundColor Red
            Write-Log -msg "Failed to resolve ADK download link. HTTP Status: $($RedirectResponse.StatusCode)"
            Remove-TempFiles
            Pause
            Exit
        }
    }

    # Generate ISO
    Write-Host ("`n[INFO] Generating ISO...") -ForegroundColor Cyan
    Write-Host "  This may take a few minutes" -ForegroundColor DarkGray
    Write-Log -msg "Generating ISO using OSCDIMG"
    Write-Progress -Activity "Creating ISO" -Status "Building ISO with oscdimg... (press S to keep processing, cannot skip ISO creation)" -PercentComplete 60
    try {
        $etfsbootPath = "$destinationPath\boot\etfsboot.com"
        $efisysPath = "$destinationPath\efi\Microsoft\boot\efisys.bin"
        $bootData = "2#p0,e,b`"$etfsbootPath`"#pEF,e,b`"$efisysPath`""
        Write-Log -msg "Boot data set: $bootData"

        $oscdimgArgs = @(
            "-bootdata:$bootData",
            "-m",               # Ignore maximum size limit
            "-o",               # Optimize for space
            "-h",               # Show hidden files
            "-u2",              # UDF 2.0
            "-udfver102",       # UDF version 1.02
            "-l$ISOFileName",   # Set volume label
            "`"$destinationPath`"",
            "`"$ISOFile`""
        )

        Write-Log -msg "OSCDIMG command: $Oscdimg $($oscdimgArgs -join ' ')"
        $oscdimgProcess = Start-Process -FilePath "$Oscdimg" -ArgumentList $oscdimgArgs -PassThru -Wait -NoNewWindow

        if ($oscdimgProcess.ExitCode -eq 0) {
            Write-Host ("[OK] ISO creation successful") -ForegroundColor Green
            Write-Log -msg "ISO successfully created with exit code 0"
            Write-Progress -Activity "Creating ISO" -Status "ISO created successfully" -PercentComplete 100
        } else {
            Write-Warning "ISO creation finished with errors"
            Write-Log -msg "OSCDIMG exited with code: $($oscdimgProcess.ExitCode)"
            Write-Progress -Activity "Creating ISO" -Status "ISO created with warnings" -PercentComplete 100
        }
    }
    catch {
        Write-Log -msg "Failed to generate ISO with exit code: $_"
    }
}
else {
    Write-Host "`n[INFO] Preparing ISO creation..." -ForegroundColor Cyan
    Write-Log -msg "Preparing ISO creation"

    # ISOWriter class
    # More Here: https://learn.microsoft.com/en-us/windows/win32/api/_imapi/
    if (!('ISOWriter' -as [Type])) {
        Add-Type -TypeDefinition @'
        using System;
        using System.Runtime.InteropServices;
        using System.Runtime.InteropServices.ComTypes;

        public class ISOWriter {
            [DllImport("shlwapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, PreserveSig = false)]
            private static extern void SHCreateStreamOnFileEx(string fileName, uint mode, uint attributes, bool create, IStream streamNull, out IStream stream);
            public static bool Create(string filePath, ref object imageStream, int blockSize, int totalBlocks) {IStream resultStream = (IStream)imageStream, imageFile; SHCreateStreamOnFileEx(filePath, 0x1001, 0x80, true, null, out imageFile); const int bufferSize = 1024; int remainingBlocks = totalBlocks;
                while (remainingBlocks > 0) { int blocksToWrite = Math.Min(remainingBlocks, bufferSize); resultStream.CopyTo(imageFile, blocksToWrite * blockSize, IntPtr.Zero, IntPtr.Zero); remainingBlocks -= blocksToWrite;}
                imageFile.Commit(0);
                return true;}
        }
'@
    }

    try {
        $comObjects = @()

        # Initialize boot configuration
        $bootStream = New-Object -ComObject ADODB.Stream -Property @{ Type = 1 }
        $comObjects += $bootStream
        $bootStream.Open()
        $bootStream.LoadFromFile("$destinationPath\efi\Microsoft\boot\efisys.bin")
        # $bootStream.LoadFromFile("$destinationPath\efi\Microsoft\boot\efisys_noprompt.bin")

        # Configure boot and filesystem
        $bootOptions = New-Object -ComObject IMAPI2FS.BootOptions -Property @{
            PlatformId = 0xEF
            Manufacturer = "Microsoft"
            Emulation = 0
        }
        $comObjects += $bootOptions
        $bootOptions.AssignBootImage($bootStream)

        $FSImage = New-Object -ComObject IMAPI2FS.MsftFileSystemImage -Property @{
            FileSystemsToCreate = 4
            UDFRevision = 0x102
            FreeMediaBlocks = 0
            VolumeName = $ISOFileName
        }
        $comObjects += $FSImage

        Write-Log -msg "Creating ISO structure"
        $FSImage.Root.AddTree($destinationPath, $false)
        $FSImage.BootImageOptions = $bootOptions

        Write-Host "[INFO] Generating ISO..." -ForegroundColor Cyan
        Write-Log -msg "Generating ISO using ISOWriter"
        Write-Progress -Activity "Creating ISO" -Status "Building ISO with IMAPI2FS..." -PercentComplete 60
        $resultImage = $FSImage.CreateResultImage()
        $comObjects += $resultImage

        [ISOWriter]::Create($ISOFile, [ref]$resultImage.ImageStream, $resultImage.BlockSize, $resultImage.TotalBlocks) | Out-Null

        if ((Get-Item $ISOFile).Length -eq ($resultImage.BlockSize * $resultImage.TotalBlocks)) {
            Write-Log -msg "ISO successfully created at: $ISOFile"
        }
    }
    catch {
        Write-Log -msg "ISO creation failed: $_" -Type Error
    }
    finally {
        foreach ($obj in $comObjects) {
            if ($obj) {
                while ([Runtime.InteropServices.Marshal]::ReleaseComObject($obj) -gt 0) { }
            }
        }
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
        Write-Host "[OK] ISO creation successful" -ForegroundColor Green
    }
}

# ISO verification
if (Test-Path -Path $ISOFile) {
    try {
        $verifyMntResult = Mount-DiskImage -ImagePath "$ISOFile" -PassThru
        $verifyDrive = ($verifyMntResult | Get-Volume).DriveLetter
        $isoMountPoint = "${verifyDrive}:\"
        $reqFiles = @("sources\install.wim", "sources\boot.wim", "boot\bcd", "boot\boot.sdi", "bootmgr", "bootmgr.efi", "efi\microsoft\boot\efisys.bin")
        $missingFiles = $reqFiles | Where-Object { -not (Test-Path (Join-Path $isoMountPoint $_)) }

        Dismount-DiskImage -ImagePath "$ISOFile" 2>&1 | Write-Log

        if ($missingFiles) {
            Write-Host "`nError: Created ISO is missing critical files" -ForegroundColor Red
            Write-Log -msg "ISO verification failed - missing files: $($missingFiles -join ', ')"
        }
        else {
            Write-Host "`nScript Completed. Can find the ISO in `"$scriptDirectory`"" -ForegroundColor Green
            Write-Log -msg "ISO verification successful"
            Write-Progress -Activity "Creating ISO" -Completed
        }
    }
    catch {
        Write-Warning "`nUnable to verify ISO integrity"
        Write-Log -msg "Failed to verify ISO: $_"
    }
} else {
    Write-Host "`nError: ISO file wasn't created" -ForegroundColor Red
    Write-Log -msg "ISO file wasn't created"
}

# Write error summary before cleanup
Write-ErrorSummary

# Remove temporary files
Write-Log -msg "Removing temporary files"
try {
    Remove-TempFiles
}
catch {
    Write-Log -msg "Failed to remove temporary files: $_"
}
finally {
    Write-Log -msg "Script completed"
}

Write-Host
Pause